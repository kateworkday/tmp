/* 开盘啦盯盘助手 - 市场情绪 */
(function () {
  'use strict';

  const V = window.Views = window.Views || {};
  const today = () => K.todayStr();
  const currentDate = () => K.state.date || today();
  const isHistory = () => currentDate() !== today();

  const num = (value, fallback = 0) => {
    const n = Number(value);
    return Number.isFinite(n) ? n : fallback;
  };
  const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
  const round = (value, digits = 2) => {
    const p = 10 ** digits;
    return Math.round(num(value) * p) / p;
  };
  const addDays = (date, n) => {
    const d = new Date(`${date}T12:00:00`);
    d.setDate(d.getDate() + n);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  };
  const firstNum = (...values) => {
    for (const value of values) {
      if (value !== undefined && value !== null && value !== '') return num(value);
    }
    return null;
  };
  const inlineError = (label, res) => {
    if (!res || res.ok) return '';
    return `<div class="inline-error"><b>${K.esc(label)}</b> ${K.esc(res.error || '')}</div>`;
  };

  function heightFromDaily(d) {
    if (num(d.fourthPlus) > 0) return 5;
    if (num(d.thirdBoard) > 0) return 3;
    if (num(d.secondBoard) > 0) return 2;
    if (num(d.firstBoard) > 0) return 1;
    return 0;
  }

  function scoreModel(m) {
    const breadth = m.up + m.down > 0 ? m.up / (m.up + m.down) * 100 : 50;
    const limitBalance = m.zt + m.dt > 0 ? m.zt / (m.zt + m.dt) * 100 : 50;
    const heightScore = clamp(m.height / 7 * 100, 0, 100);
    const yestScore = m.yest == null ? 50 : clamp(50 + m.yest * 8, 0, 100);
    const sealScore = m.broken == null ? 50 : clamp(100 - m.broken, 0, 100);
    const sharpScore = clamp(100 - m.sharpCount * 2, 0, 100);
    const score = clamp(
      breadth * 0.25 + limitBalance * 0.25 + heightScore * 0.15 +
      yestScore * 0.20 + sealScore * 0.10 + sharpScore * 0.05,
      0, 100
    );
    return {
      score: round(score, 1), breadth, limitBalance, heightScore,
      yestScore, sealScore, sharpScore, zt: m.zt, dt: m.dt,
      up: m.up, down: m.down, height: m.height, yest: m.yest,
      broken: m.broken, sharpCount: m.sharpCount
    };
  }

  function modelFromDaily(row) {
    return scoreModel({
      up: firstNum(row.up, 0),
      down: firstNum(row.down, 0),
      zt: firstNum(row.actualLimitUp, row.limitUp, 0),
      dt: firstNum(row.actualLimitDown, row.limitDown, 0),
      height: heightFromDaily(row),
      yest: firstNum(row.yesterdayLimitPerformance, null),
      broken: firstNum(row.brokenRate, row.blownRate, null),
      sharpCount: firstNum(row.sharpCount, 0)
    });
  }

  function stageOf(score) {
    if (score >= 80) return { label: '高潮', cls: 'up', note: '赚钱效应强，注意高位分歧与兑现风险。' };
    if (score >= 65) return { label: '升温', cls: 'up', note: '情绪升温，连板接力与题材扩散较好。' };
    if (score >= 50) return { label: '修复', cls: 'flat', note: '情绪修复，关注赚钱效应能否持续。' };
    if (score >= 35) return { label: '分歧', cls: 'flat', note: '多空分歧，控制仓位并观察高标反馈。' };
    if (score >= 20) return { label: '退潮', cls: 'down', note: '亏钱效应扩散，谨慎追高与接力。' };
    return { label: '冰点', cls: 'down', note: '情绪冰点，等待修复信号与新的主线。' };
  }

  function kpi(label, value, sub, cls = '') {
    return `<div class="hero-card sentiment-kpi ${cls}">
      <div class="hero-label">${K.esc(label)}</div>
      <div class="kpi-value">${value}</div>
      <div class="kpi-sub">${sub}</div>
    </div>`;
  }

  function stockNameMap(data) {
    return new Map((data.items || []).map(x => [x.code, x.name || '']));
  }

  function sentimentChip(code, name) {
    return `<button type="button" class="stock-chip" data-code="${K.escAttr(code)}" data-name="${K.escAttr(name || '')}">
      <b>${K.esc(name || code)}</b>${name ? `<span>${K.esc(code)}</span>` : ''}
    </button>`;
  }

  function trendHtml(trend) {
    if (!trend || !trend.rows || !trend.rows.length) return K.empty('暂无趋势数据');
    const rows = trend.rows;
    return `<div class="chart-wrap" style="height:260px"><canvas id="sentimentTrendChart"></canvas></div>
      ${K.table([
        { key: 'date', label: '日期' },
        { key: 'score', label: '情绪温度', align: 'right', render: r => `<span class="strong">${K.fmtNum(r.score, 1)}</span>` },
        { key: 'limitUp', label: '涨停', align: 'right', render: r => `<span class="num up">${K.fmtInt(r.limitUp)}</span>` },
        { key: 'limitDown', label: '跌停', align: 'right', render: r => `<span class="num down">${K.fmtInt(r.limitDown)}</span>` },
        { key: 'up', label: '上涨', align: 'right', render: r => `<span class="num up">${K.fmtInt(r.up)}</span>` },
        { key: 'down', label: '下跌', align: 'right', render: r => `<span class="num down">${K.fmtInt(r.down)}</span>` },
        { key: 'consecutiveRate', label: '连板率', align: 'right', render: r => K.fmtRate(r.consecutiveRate) },
        { key: 'yest', label: '昨日涨停表现', align: 'right', render: r => r.yest == null ? '<span class="muted">-</span>' : K.pctCell(r.yest) },
        { key: 'broken', label: '炸板率', align: 'right', render: r => r.broken == null ? '<span class="muted">-</span>' : K.fmtRate(r.broken) }
      ], rows, { emptyText: '暂无趋势数据' })}`;
  }

  function drawTrendChart() {
    const canvas = document.getElementById('sentimentTrendChart');
    const trend = K.state.viewState.sentiment && K.state.viewState.sentiment.trend;
    if (!canvas || !trend || !trend.rows || !trend.rows.length) return;
    window.Charts.line(
      canvas,
      trend.rows.map(x => String(x.date).slice(5)),
      trend.rows.map(x => x.score),
      { height: 260, color: '#f0b90b', fill: false }
    );
  }

  V.sentiment = async function () {
    const d = currentDate();
    const hist = isHistory();
    const vs = K.state.viewState.sentiment = K.state.viewState.sentiment || { trend: null, trendDate: '' };
    const oldTrend = vs.trend && vs.trend.date === d ? vs.trend : null;
    K.setPage('市场情绪', `${hist ? '历史交易日' : '实时'} ${d} · 情绪温度、赚钱效应与连板周期`, 'KAI PAN LA · MARKET SENTIMENT');
    K.render(K.loading('正在汇总市场情绪…'));

    let data;
    if (!hist) {
      const [mood, limit, indexes, boards, rise, sent, sharp, sectors] = await K.parallel([
        () => K.api('realtimeMood'),
        () => K.api('realtimeLimit'),
        () => K.api('realtimeIndexList'),
        () => K.api('realtimeAllBoards'),
        () => K.api('riseFall'),
        () => K.api('sentimentIndicator', { plateId: '801225' }),
        () => K.api('sharpWithdrawal', { date: d }),
        () => K.api('sectorRanking', { date: d, index: 0 })
      ]);
      const moodData = mood.ok ? mood.data : {};
      const limitData = limit.ok ? limit.data : {};
      const boardsData = boards.ok ? boards.data : {};
      const riseData = rise.ok ? rise.data : {};
      const sharpData = sharp.ok ? sharp.data : { items: [], count: 0 };
      const sectorData = sectors.ok ? sectors.data : {};
      let maxConsecutive = 0, totalBoards = 0, firstBoard = 0;
      for (const group of boardsData.groups || []) {
        const list = group.items || [];
        totalBoards += list.length;
        if (num(group.type) === 1) firstBoard = list.length;
        for (const stock of list) maxConsecutive = Math.max(maxConsecutive, num(stock.consecutive) || num(group.type) || 1);
      }
      data = {
        realtime: true,
        date: d,
        up: firstNum(moodData.up, 0),
        down: firstNum(moodData.down, 0),
        zt: (firstNum(limitData.actualLimitUp, 0) > 0 ? firstNum(limitData.actualLimitUp, 0) : firstNum(moodData.limitUp, 0)),
        dt: (firstNum(limitData.actualLimitDown, 0) > 0 ? firstNum(limitData.actualLimitDown, 0) : firstNum(moodData.limitDown, 0)),
        limitUp: firstNum(moodData.limitUp, 0),
        limitDown: firstNum(moodData.limitDown, 0),
        yest: firstNum(riseData.yesterdayLimitPerformance, null),
        yestConsecutive: null,
        broken: firstNum(riseData.blownRate, null),
        consecutiveRate: firstNum(boardsData.statistics && boardsData.statistics.consecutiveRate, null),
        sharpCount: firstNum(sharpData.count, 0),
        height: maxConsecutive,
        totalBoards,
        firstBoard,
        comment: '实时盘面',
        indexItems: indexes.ok ? (indexes.data.items || []) : [],
        sectors: sectorData.sectors || [],
        sentData: sent.ok ? sent.data : null,
        sharpData,
        errors: { mood, limit, indexes, boards, rise, sharp, sectors }
      };
    } else {
      const [daily, ml, sectors, indexes, sharp] = await K.parallel([
        () => K.api('daily', { date: d }),
        () => K.api('marketLadder', { date: d }),
        () => K.api('sectorRanking', { date: d, index: 0 }),
        () => K.api('marketIndex', { date: d }),
        () => K.api('sharpWithdrawal', { date: d })
      ]);
      const dailyData = daily.ok ? daily.data : {};
      const mlData = ml.ok ? ml.data : {};
      const sectorData = sectors.ok ? sectors.data : {};
      const sharpData = sharp.ok ? sharp.data : { items: [], count: 0 };
      data = {
        realtime: false,
        date: d,
        up: firstNum(dailyData.up, 0),
        down: firstNum(dailyData.down, 0),
        zt: firstNum(dailyData.actualLimitUp, dailyData.limitUp, 0),
        dt: firstNum(dailyData.actualLimitDown, dailyData.limitDown, 0),
        limitUp: firstNum(dailyData.limitUp, 0),
        limitDown: firstNum(dailyData.limitDown, 0),
        yest: firstNum(dailyData.yesterdayLimitPerformance, null),
        yestConsecutive: firstNum(dailyData.yesterdayConsecutivePerformance, null),
        broken: firstNum(dailyData.brokenRate, null),
        consecutiveRate: firstNum(dailyData.consecutiveRate, null),
        sharpCount: firstNum(dailyData.sharpCount, sharpData.count, 0),
        height: firstNum(mlData.stats && mlData.stats.maxConsecutive, heightFromDaily(dailyData), 0),
        totalBoards: firstNum(mlData.stats && mlData.stats.total, 0),
        firstBoard: firstNum(dailyData.firstBoard, 0),
        comment: dailyData.comment || '',
        indexItems: indexes.ok ? (indexes.data.items || []) : [],
        sectors: sectorData.sectors || [],
        sentData: null,
        sharpData,
        errors: { daily, ml, sectors, indexes, sharp }
      };
    }

    const up = data.up;
    const down = data.down;
    const zt = data.zt;
    const dt = data.dt;
    const limitUp = data.limitUp;
    const limitDown = data.limitDown;
    const yest = data.yest;
    const yestConsecutive = data.yestConsecutive;
    const broken = data.broken;
    const consecutiveRate = data.consecutiveRate;
    const sharpCount = data.sharpCount;
    const height = data.height;
    const totalBoards = data.totalBoards;
    const firstBoard = data.firstBoard;
    const consecutiveBoards = Math.max(0, totalBoards - firstBoard);
    const comment = data.comment;
    const indexItems = data.indexItems;
    const sentData = data.sentData;
    const sharpData = data.sharpData;
    const sh = indexItems.find(v => v.code === 'SH000001') || indexItems[0] || {};
    const sz = indexItems.find(v => v.code === 'SZ399001') || indexItems[1] || {};
    const totalTurnover = firstNum(sh.turnover, 0) + firstNum(sz.turnover, 0) || firstNum(data.index && data.index.turnover, 0);

    const m = scoreModel({ up, down, zt, dt, height, yest, broken, sharpCount });
    const stage = stageOf(m.score);
    const sealRate = broken == null ? null : clamp(100 - broken, 0, 100);
    const ringColor = m.score >= 65 ? 'var(--up)' : m.score >= 45 ? 'var(--accent)' : 'var(--down)';
    const badgeClass = stage.cls === 'up' ? 'tag-red' : stage.cls === 'down' ? 'tag-green' : 'tag-blue';

    const kpis = [
      kpi('涨停 / 跌停', `<span class="up">${K.fmtInt(zt)}</span><span class="hero-divider">/</span><span class="down">${K.fmtInt(dt)}</span>`, `含一字 ${K.fmtInt(limitUp)} / ${K.fmtInt(limitDown)}`),
      kpi('上涨 / 下跌', `<span class="up">${K.fmtInt(up)}</span><span class="hero-divider">/</span><span class="down">${K.fmtInt(down)}</span>`, `涨跌比 ${down > 0 ? K.fmtNum(up / down) : '-'}`),
      kpi('连板高度', `${K.fmtInt(height)} 板`, `涨停 ${K.fmtInt(totalBoards)} · 连板 ${K.fmtInt(consecutiveBoards)} · 晋级 ${consecutiveRate == null ? '-' : K.fmtRate(consecutiveRate)}`),
      kpi('两市成交额', totalTurnover > 0 ? K.fmtBig(totalTurnover) : '-', `${K.esc(sh.name || '沪市')} + ${K.esc(sz.name || '深市')}`),
      kpi('昨日涨停表现', yest == null ? '-' : K.fmtPct(yest), yestConsecutive == null ? '赚钱效应参考' : `昨日连板 ${K.fmtPct(yestConsecutive)}`, yest == null ? '' : K.pctClass(yest)),
      kpi('昨日炸板率', broken == null ? '-' : K.fmtRate(broken), sealRate == null ? '上一交易日风险指标' : `封板率 ${K.fmtRate(sealRate)}`)
    ].join('');

    const metricRows = [
      ['上涨 / 下跌', `<span class="up">${K.fmtInt(up)}</span> / <span class="down">${K.fmtInt(down)}</span>`, `市场宽度 ${K.fmtRate(m.breadth)}`],
      ['涨停 / 跌停', `<span class="up">${K.fmtInt(zt)}</span> / <span class="down">${K.fmtInt(dt)}</span>`, `涨停占比 ${K.fmtRate(m.limitBalance)}`],
      ['连板高度', `${K.fmtInt(height)} 板`, `涨停 ${K.fmtInt(totalBoards)} 家 · 连板 ${K.fmtInt(consecutiveBoards)} 家`],
      ['昨日涨停表现', yest == null ? '-' : K.fmtPct(yest), '赚钱效应'],
      ['炸板率', broken == null ? '-' : K.fmtRate(broken), sealRate == null ? '风险指标' : `封板率 ${K.fmtRate(sealRate)}`],
      ['大幅回撤', K.fmtInt(sharpCount), '风险扩散参考'],
      ['两市成交额', totalTurnover > 0 ? K.fmtBig(totalTurnover) : '-', '沪市 + 深市'],
      ['市场评价', K.esc(comment || '-'), '开盘啦盘面评价']
    ].map(([label, value, sub]) => `<div><span>${K.esc(label)}</span><b>${value}<small class="muted"> ${K.esc(sub)}</small></b></div>`).join('');

    const topSectors = (data.sectors || []).slice(0, 8);
    const sectorRows = topSectors.map(sec => `<div class="sector-row">
      <button class="sector-name link-btn" data-sector="${K.escAttr(sec.code)}" data-sector-name="${K.escAttr(sec.name)}">${K.esc(sec.name || sec.code)}</button>
      <span class="tag">${K.fmtInt(sec.count)} 只涨停</span>
      <div class="chip-row">${(sec.stocks || []).slice(0, 4).map(st => K.stockChip(st)).join('')}</div>
    </div>`).join('');

    let sentBody = '';
    if (hist) {
      sentBody = K.empty('历史日期暂不提供实时多空风向标');
    } else if (!sentData) {
      sentBody = K.empty('多空风向标暂不可用');
    } else {
      const names = stockNameMap(sentData);
      const bullish = (sentData.bullishCodes || []).map(code => sentimentChip(code, names.get(code))).join('');
      const bearish = (sentData.bearishCodes || []).map(code => sentimentChip(code, names.get(code))).join('');
      sentBody = `<div class="metric-list compact">
        <div><span>多头风向标</span><b class="up">${K.fmtInt((sentData.bullishCodes || []).length)} 只</b></div>
        <div><span>空头风向标</span><b class="down">${K.fmtInt((sentData.bearishCodes || []).length)} 只</b></div>
      </div>
      <div class="sentiment-subtitle">多头样本</div><div class="chip-row">${bullish || '<span class="muted">暂无</span>'}</div>
      <div class="sentiment-subtitle">空头样本</div><div class="chip-row">${bearish || '<span class="muted">暂无</span>'}</div>`;
    }

    const sharpRows = (sharpData.items || []).slice(0, 10);
    const sharpBody = sharpRows.length ? K.table([
      { key: 'code', label: '代码', render: r => `<button class="link-btn mono" data-code="${K.escAttr(r.code)}">${K.esc(r.code)}</button>` },
      { key: 'name', label: '名称' },
      { key: 'changePct', label: '涨跌幅', align: 'right', render: r => K.pctCell(r.changePct) },
      { key: 'drawdownPct', label: '回撤', align: 'right', render: r => K.pctCell(r.drawdownPct) },
      { key: 'price', label: '最新价', align: 'right', render: r => `<span class="num">${K.fmtPrice(r.price)}</span>` }
    ], sharpRows) : K.empty('当日无大幅回撤数据');

    const trendBody = `<div class="form-row">
      <button class="btn" id="sentimentTrendLoad">${oldTrend ? '重新加载' : '加载近 10 日趋势'}</button>
      <span class="muted small">按交易日计算情绪温度，最多 10 个交易日</span>
    </div>
    <div id="sentimentTrendBox">${oldTrend ? trendHtml(oldTrend) : K.empty('点击按钮加载近 10 日情绪趋势')}</div>`;

    K.render(`
      ${inlineError('实时情绪', (data.errors || {}).mood)}${inlineError('涨跌停', (data.errors || {}).limit)}${inlineError('单日数据', (data.errors || {}).daily)}${inlineError('市场梯队', (data.errors || {}).boards || (data.errors || {}).ml)}${inlineError('指数行情', (data.errors || {}).indexes)}${inlineError('昨日情绪', (data.errors || {}).rise)}${inlineError('领涨板块', (data.errors || {}).sectors)}${inlineError('大幅回撤', (data.errors || {}).sharp)}
      <div class="sentiment-hero">
        <div class="hero-card sentiment-score-card">
          <div class="sentiment-card-head">
            <span class="hero-label">情绪温度</span>
            <span class="tag ${badgeClass}">${hist ? '历史' : '实时'}</span>
          </div>
          <div class="score-ring" style="--score:${m.score};--ring-color:${ringColor}">
            <div class="score-ring-inner">
              <strong>${K.fmtNum(m.score, 1)}</strong>
              <span class="${stage.cls}">${stage.label}</span>
            </div>
          </div>
          <div class="score-note">${K.esc(stage.note)}</div>
          <div class="sentiment-gauge">
            <div class="sentiment-gauge-track"><span style="width:${m.score}%"></span><i style="left:calc(${m.score}% - 4px)"></i></div>
            <div class="sentiment-gauge-labels"><span>0 冰点</span><span>50 平衡</span><span>100 高潮</span></div>
          </div>
        </div>
        <div class="sentiment-kpis">${kpis}</div>
      </div>

      <div class="two-col">
        ${K.section('情绪拆解', '涨跌家数、涨跌停、连板与风险指标', `<div class="metric-list sentiment-metric-list">${metricRows}</div>`)}
        ${K.section('周期定位', `${stage.label}阶段 · 关键信号`, `
          <div class="cycle-steps">
            ${['冰点', '修复', '升温', '高潮', '分歧', '退潮'].map(s => `<span class="cycle-step ${stage.label === s ? 'active' : ''}">${s}</span>`).join('<i>→</i>')}
          </div>
          <div class="signal-grid">
            <div class="signal-card"><span>赚钱效应</span><b class="${yest == null ? '' : K.pctClass(yest)}">${yest == null ? '-' : K.fmtPct(yest)}</b><em>昨日涨停股今日表现</em></div>
            <div class="signal-card"><span>封板率</span><b>${sealRate == null ? '-' : K.fmtRate(sealRate)}</b><em>炸板率越低越好</em></div>
            <div class="signal-card"><span>连板晋级率</span><b>${consecutiveRate == null ? '-' : K.fmtRate(consecutiveRate)}</b><em>连板接力强度</em></div>
            <div class="signal-card"><span>风险信号</span><b class="${sharpCount > 0 ? 'down' : ''}">${K.fmtInt(sharpCount)}</b><em>大幅回撤家数</em></div>
          </div>
          <div class="cycle-comment">${K.esc(comment || stage.note)}</div>`)}
      </div>

      ${K.section('领涨板块', topSectors.length ? `${topSectors.length} 个板块 · 点击板块查看行情` : '暂无板块数据', sectorRows || K.empty('暂无领涨板块'), `<button class="btn btn-ghost" data-goto="sectors">全部涨停原因</button>`) }

      <div class="two-col">
        ${K.section('多空风向标', hist ? '历史日期' : '开盘啦样本股 · 前 3 多头 / 后 3 空头', sentBody)}
        ${K.section('大幅回撤', `共 ${K.fmtInt(sharpCount)} 只 · 风险监控`, sharpBody)}
      </div>

      ${K.section('近 10 日情绪趋势', '历史情绪温度与核心指标', trendBody)}
      <div class="callout">情绪温度 = 市场宽度 25% + 涨停/跌停平衡 25% + 连板高度 15% + 昨日涨停表现 20% + 封板率 10% + 大幅回撤 5%。仅用于盘面研究，不构成投资建议。</div>
    `);

    bindCommon();
    if (oldTrend) requestAnimationFrame(drawTrendChart);

    document.getElementById('sentimentTrendLoad')?.addEventListener('click', async () => {
      const btn = document.getElementById('sentimentTrendLoad');
      const box = document.getElementById('sentimentTrendBox');
      if (!btn || !box) return;
      btn.disabled = true;
      btn.textContent = '加载中…';
      box.innerHTML = K.loading('正在计算近 10 日情绪温度…');
      try {
        const res = await K.apiSafe('dailyRange', { startDate: addDays(d, -14), endDate: d });
        if (!res.ok) throw new Error(res.error);
        const rows = (res.data.rows || []).slice(-10).map(row => {
          const sm = modelFromDaily(row);
          return {
            date: row.date,
            score: sm.score,
            limitUp: firstNum(row.actualLimitUp, row.limitUp, 0),
            limitDown: firstNum(row.actualLimitDown, row.limitDown, 0),
            up: firstNum(row.up, 0),
            down: firstNum(row.down, 0),
            consecutiveRate: firstNum(row.consecutiveRate, null),
            yest: firstNum(row.yesterdayLimitPerformance, null),
            broken: firstNum(row.brokenRate, row.blownRate, null)
          };
        });
        if (!rows.length) throw new Error('该区间暂无交易日数据');
        vs.trend = { date: d, rows };
        box.innerHTML = trendHtml(vs.trend);
        requestAnimationFrame(drawTrendChart);
      } catch (err) {
        box.innerHTML = K.errorBox(err, '情绪趋势加载失败');
      } finally {
        if (btn) { btn.disabled = false; btn.textContent = '重新加载'; }
      }
    });
  };
})();
