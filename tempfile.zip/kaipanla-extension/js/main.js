/* 开盘啦盯盘助手 - 导航与启动 */
(function () {
  'use strict';

  const NAV = [
    {
      group: '热门',
      items: [
        { id: 'featured', label: '精选板块', icon: '◆' },
        { id: 'mainline', label: '主线追踪', icon: '线' },
        { id: 'hot', label: '人气排行榜', icon: '榜' }
      ]
    },
    {
      group: '盘面',
      items: [
        { id: 'overview', label: '市场总览', icon: '◎' },
        { id: 'sentiment', label: '市场情绪', icon: '温' },
        { id: 'market', label: '涨跌统计', icon: '▤' },
        { id: 'ladder', label: '连板梯队', icon: '▥' },
        { id: 'sectors', label: '涨停原因', icon: '▧' },
        { id: 'sector', label: '板块行情', icon: '◫' }
      ]
    },
    {
      group: '行情',
      items: [
        { id: 'stock', label: '个股行情', icon: '◉' },
        { id: 'index', label: '指数行情', icon: '≈' },
        { id: 'monitor', label: '异动监控', icon: '⚡' }
      ]
    },
    {
      group: '数据',
      items: [
        { id: 'lhb', label: '龙虎榜', icon: '榜' },
        { id: 'etf', label: 'ETF 排行', icon: 'E' },
        { id: 'news', label: '板块资讯', icon: '✉' },
        { id: 'catalog', label: '接口目录', icon: '{}' }
      ]
    }
  ];

  const META = {
    featured: ['精选板块', '开盘啦精选板块 · 行业板块 / 地区板块排行', 'KAI PAN LA · FEATURED SECTORS'],
    mainline: ['主线追踪', '最近两周精选板块强度矩阵 · 点击板块跨日高亮', 'KAI PAN LA · MAINLINE TRACKER'],
    sectorStocks: ['板块个股', '板块成分股 · 默认按涨幅排序', 'SECTOR STOCKS'],
    hot: ['人气排行榜', '开盘啦人气榜 / 最强风口 + 同花顺热榜', 'POPULARITY RANKING'],
    overview: ['市场总览', '涨停、情绪、指数与热点板块一屏掌握', 'KAI PAN LA · MARKET OVERVIEW'],
    sentiment: ['市场情绪', '情绪温度、赚钱效应、连板周期与风险信号', 'KAI PAN LA · MARKET SENTIMENT'],
    market: ['涨跌统计', '单日市场数据、连板结构与百日新高', 'KAI PAN LA · MARKET STATS'],
    ladder: ['连板梯队', '全市场、板块、连板详情与炸板', 'KAI PAN LA · LIMIT-UP LADDER'],
    sectors: ['涨停原因', '按涨停原因分类的板块与个股明细', 'KAI PAN LA · LIMIT-UP SECTORS'],
    sector: ['板块行情', '资金、强度、分时、成交量、成分股与竞价', 'KAI PAN LA · SECTOR DETAIL'],
    stock: ['个股行情', '分时、K线、主力大单与集合竞价', 'KAI PAN LA · STOCK'],
    index: ['指数行情', '指数分时、K线与实时指数列表', 'KAI PAN LA · INDEX'],
    monitor: ['异动监控', '涨停板、大幅回撤、涨跌分析、炸板与竞价', 'KAI PAN LA · MONITOR'],
    lhb: ['龙虎榜', '每日龙虎榜个股与买卖席位明细', 'KAI PAN LA · DRAGON-TIGER'],
    etf: ['ETF 排行', '开盘啦 ETF 涨幅、成交额、区间收益与规模', 'KAI PAN LA · ETF'],
    news: ['板块资讯', '开盘啦板块新闻与快讯', 'KAI PAN LA · NEWS'],
    catalog: ['接口目录', '开盘啦 37 个原始接口 + 东方财富 K线/分时/行情', 'KAI PAN LA · API CATALOG']
  };

  let renderToken = 0;

  function renderNav() {
    const nav = document.getElementById('nav');
    nav.innerHTML = NAV.map(group => `
      <div class="nav-group">
        <div class="nav-group-label">${K.esc(group.group)}</div>
        ${group.items.map(item => `<button class="nav-item" data-route="${item.id}" title="${K.escAttr(item.label)}" aria-label="${K.escAttr(item.label)}">
          <span class="nav-icon">${K.esc(item.icon)}</span><span>${K.esc(item.label)}</span>
        </button>`).join('')}
      </div>`).join('');
    nav.querySelectorAll('[data-route]').forEach(btn => {
      btn.addEventListener('click', () => navigate(btn.getAttribute('data-route')));
    });
  }

  function markActive(route) {
    const activeRoute = route === 'sectorStocks' ? 'featured' : route;
    document.querySelectorAll('[data-route]').forEach(btn => {
      btn.classList.toggle('active', btn.getAttribute('data-route') === activeRoute);
    });
    renderRouteTabs(activeRoute);
  }

  function renderRouteTabs(route) {
    const tabs = document.getElementById('routeTabs');
    if (!tabs) return;
    const group = NAV.find(g => g.items.some(item => item.id === route)) || NAV[0];
    tabs.innerHTML = `<span class="route-tab-group">${K.esc(group.group)}</span>${group.items.map(item => `
      <button class="route-tab ${item.id === route ? 'active' : ''}" data-route-tab="${item.id}">
        <span class="route-tab-icon">${K.esc(item.icon)}</span>${K.esc(item.label)}
      </button>`).join('')}`;
    tabs.querySelectorAll('[data-route-tab]').forEach(btn => {
      if (btn.dataset.boundTab) return;
      btn.dataset.boundTab = '1';
      btn.addEventListener('click', () => navigate(btn.getAttribute('data-route-tab')));
    });
  }

  function routeLabel(route) {
    if (route === 'sectorStocks') {
      const name = K.state.viewState.sectorStocks && K.state.viewState.sectorStocks.name;
      if (name) return `${name} · 个股`;
    }
    return (META[route] && META[route][0]) || route;
  }

  K.goBack = function goBack() {
    const target = (K.state.navHistory || []).pop();
    if (!target) return false;
    navigate(target.route, { fromBack: true });
    return true;
  };

  window.navigate = async function navigate(route, options = {}) {
    if (!Views[route]) route = 'overview';
    const previous = K.state.route;
    if (!options.fromBack && K.state.navReady && previous && previous !== route) {
      K.state.navHistory = K.state.navHistory || [];
      K.state.navHistory.push({ route: previous, label: routeLabel(previous) });
      if (K.state.navHistory.length > 30) K.state.navHistory.shift();
    }
    K.state.navReady = true;
    K.state.route = route;
    try { localStorage.setItem('kpl.route', route); } catch (_) {}
    markActive(route);
    const meta = META[route] || META.overview;
    K.setPage(meta[0], meta[1], meta[2]);
    K.scrollTop();
    const token = ++renderToken;
    try {
      await Views[route]();
    } catch (err) {
      if (token !== renderToken) return;
      K.render(K.errorBox(err, `${meta[0]}加载失败`));
    }
  };

  window.bindCommon = function bindCommon() {
    document.querySelectorAll('[data-goto]').forEach(el => {
      if (el.dataset.boundGoto) return;
      el.dataset.boundGoto = '1';
      el.addEventListener('click', () => navigate(el.getAttribute('data-goto')));
    });
    document.querySelectorAll('[data-code]').forEach(el => {
      if (el.dataset.boundStock) return;
      el.dataset.boundStock = '1';
      el.addEventListener('click', e => {
        e.preventDefault();
        e.stopPropagation();
        K.openStock(el.getAttribute('data-code'), el.getAttribute('data-name') || '');
      });
    });
    document.querySelectorAll('[data-sector]').forEach(el => {
      if (el.dataset.boundSector) return;
      el.dataset.boundSector = '1';
      el.addEventListener('click', e => {
        e.preventDefault();
        e.stopPropagation();
        const code = el.getAttribute('data-sector');
        const name = el.getAttribute('data-sector-name') || '';
        if (el.getAttribute('data-sector-mode') === 'stocks') K.openSectorStocks(code, name);
        else K.openSector(code, name);
      });
    });
  };

  function resetDateSensitive() {
    const ladder = K.state.viewState.ladder;
    if (ladder) ladder.consecutive = null;
    const sector = K.state.viewState.sector;
    if (sector) { sector.strengthRows = null; sector.strengthNDays = null; sector.strengthStart = ''; sector.strengthEnd = ''; sector.all = false; }
    const news = K.state.viewState.news;
    if (news) { news.items = []; news.index = 0; news.loaded = false; }
    const featured = K.state.viewState.featured;
    if (featured) featured.all = false;
    const mainline = K.state.viewState.mainline;
    if (mainline) mainline.selectedCode = '';
    const sentiment = K.state.viewState.sentiment;
    if (sentiment) { sentiment.trend = null; sentiment.trendDate = ''; }
  }

  function setAuto(seconds) {
    K.state.auto = Number(seconds) || 0;
    if (K.state.timer) clearInterval(K.state.timer);
    K.state.timer = null;
    if (K.state.auto > 0) {
      K.state.timer = setInterval(() => {
        if (['featured', 'mainline', 'hot', 'overview', 'sentiment', 'monitor', 'stock', 'index'].includes(K.state.route)) {
          if (K.state.route === 'featured' && K.state.viewState.featured?.all) return;
          navigate(K.state.route);
        }
      }, K.state.auto * 1000);
    }
    try { localStorage.setItem('kpl.auto', String(K.state.auto)); } catch (_) {}
  }

  function updateClock() {
    const now = new Date();
    const text = `${K.pad2(now.getHours())}:${K.pad2(now.getMinutes())}:${K.pad2(now.getSeconds())}`;
    const clock = document.getElementById('marketClock');
    if (clock) clock.textContent = text;
    const dot = document.getElementById('moodDot');
    if (!dot) return;
    const day = now.getDay();
    const minutes = now.getHours() * 60 + now.getMinutes();
    const tradingDay = day >= 1 && day <= 5;
    const inMorning = minutes >= 570 && minutes <= 690;
    const inAfternoon = minutes >= 780 && minutes <= 900;
    const open = tradingDay && (inMorning || inAfternoon);
    dot.className = `mood-dot ${open ? 'open' : 'closed'}`;
    dot.title = open ? '交易时段' : '非交易时段';
  }

  function clampNumber(value, min, max, fallback) {
    if (value === null || value === undefined || value === '') return fallback;
    const n = Number(value);
    if (!Number.isFinite(n)) return fallback;
    return Math.max(min, Math.min(max, n));
  }

  function readAppearance() {
    let theme = 'light', opacity = 100, colorNum = 100, brightness = 100;
    try {
      const t = localStorage.getItem('kpl.theme');
      if (t === 'light' || t === 'dark' || t === 'gray') theme = t;
      opacity = clampNumber(localStorage.getItem('kpl.opacity'), 10, 100, 100);
      colorNum = clampNumber(localStorage.getItem('kpl.colorNum'), 0, 100, 100);
      brightness = clampNumber(localStorage.getItem('kpl.brightness'), 70, 130, 100);
    } catch (_) {}
    return { theme, opacity, colorNum, brightness };
  }

  function applyTheme(theme) {
    const next = theme === 'dark' || theme === 'gray' ? theme : 'light';
    document.documentElement.setAttribute('data-theme', next);
    try { localStorage.setItem('kpl.theme', next); } catch (_) {}
    document.querySelectorAll('[data-theme-choice]').forEach(btn => {
      btn.classList.toggle('active', btn.getAttribute('data-theme-choice') === next);
    });
  }

  function applyOpacity(value) {
    const opacity = clampNumber(value, 10, 100, 100);
    document.documentElement.style.setProperty('--surface-alpha', String(opacity / 100));
    document.documentElement.setAttribute('data-glass', opacity < 100 ? 'true' : 'false');
    try { localStorage.setItem('kpl.opacity', String(opacity)); } catch (_) {}
    const out = document.getElementById('themeOpacityValue');
    if (out) out.textContent = `${opacity}%`;
  }

  function applyColorNum(value) {
    const colorNum = clampNumber(value, 0, 100, 100);
    document.documentElement.style.setProperty('--ui-grayscale', `${100 - colorNum}%`);
    try { localStorage.setItem('kpl.colorNum', String(colorNum)); } catch (_) {}
    const out = document.getElementById('themeColorValue');
    if (out) out.textContent = `${colorNum}%`;
  }

  function applyBrightness(value) {
    const brightness = clampNumber(value, 70, 130, 100);
    document.documentElement.style.setProperty('--ui-brightness', String(brightness / 100));
    try { localStorage.setItem('kpl.brightness', String(brightness)); } catch (_) {}
    const out = document.getElementById('themeBrightnessValue');
    if (out) out.textContent = `${brightness}%`;
  }

  function applyAppearance(appearance = readAppearance()) {
    applyTheme(appearance.theme);
    applyOpacity(appearance.opacity);
    applyColorNum(appearance.colorNum);
    applyBrightness(appearance.brightness);
  }

  function openThemeSettings() {
    const appearance = readAppearance();
    const themeName = appearance.theme === 'dark' ? '深色' : appearance.theme === 'gray' ? '灰色' : '浅色';
    K.openDrawer('主题与外观', `当前：${themeName} · 透明度 ${appearance.opacity}% · 色彩度 ${appearance.colorNum}% · 亮度 ${appearance.brightness}%`, `
      <div class="theme-settings">
        <div class="theme-row">
          <div class="theme-label">主题</div>
          <div class="segmented theme-choice">
            <button class="seg-btn ${appearance.theme === 'light' ? 'active' : ''}" data-theme-choice="light">浅色</button>
            <button class="seg-btn ${appearance.theme === 'dark' ? 'active' : ''}" data-theme-choice="dark">深色</button>
            <button class="seg-btn ${appearance.theme === 'gray' ? 'active' : ''}" data-theme-choice="gray">灰色</button>
          </div>
        </div>
        <div class="theme-row">
          <div class="theme-label"><span>透明度</span><output id="themeOpacityValue">${appearance.opacity}%</output></div>
          <input type="range" id="themeOpacity" min="10" max="100" step="1" value="${appearance.opacity}">
          <div class="theme-hint">控制卡片/面板的透明度，越低越透明；文字保持可读。</div>
        </div>
        <div class="theme-row">
          <div class="theme-label"><span>色彩度</span><output id="themeColorValue">${appearance.colorNum}%</output></div>
          <input type="range" id="themeColor" min="0" max="100" step="1" value="${appearance.colorNum}">
          <div class="theme-hint">参考爱盯盘：100% 为全彩，0% 为灰度。</div>
        </div>
        <div class="theme-row">
          <div class="theme-label"><span>亮度</span><output id="themeBrightnessValue">${appearance.brightness}%</output></div>
          <input type="range" id="themeBrightness" min="70" max="130" step="1" value="${appearance.brightness}">
          <div class="theme-hint">整体调亮或调暗。</div>
        </div>
        <div class="theme-preview">
          <span class="tag tag-blue">预览</span>
          <span class="up">+3.59%</span>
          <span class="down">-2.18%</span>
          <span class="tag">强度 5568</span>
        </div>
        <div class="form-row">
          <button class="btn" id="themeReset">恢复默认</button>
          <span class="muted small">设置会保存在本机浏览器中。</span>
        </div>
      </div>
    `);
    document.querySelectorAll('[data-theme-choice]').forEach(btn => {
      btn.addEventListener('click', () => applyTheme(btn.getAttribute('data-theme-choice')));
    });
    document.getElementById('themeOpacity')?.addEventListener('input', e => applyOpacity(e.target.value));
    document.getElementById('themeColor')?.addEventListener('input', e => applyColorNum(e.target.value));
    document.getElementById('themeBrightness')?.addEventListener('input', e => applyBrightness(e.target.value));
    document.getElementById('themeReset')?.addEventListener('click', () => {
      applyTheme('light');
      applyOpacity(100);
      applyColorNum(100);
      applyBrightness(100);
      const opacity = document.getElementById('themeOpacity');
      const color = document.getElementById('themeColor');
      const brightness = document.getElementById('themeBrightness');
      if (opacity) opacity.value = '100';
      if (color) color.value = '100';
      if (brightness) brightness.value = '100';
      K.toast('已恢复默认外观', 'success', 1800);
    });
  }

  function boot() {
    applyAppearance();
    document.getElementById('themeBtn')?.addEventListener('click', openThemeSettings);
    renderNav();
    const dateInput = document.getElementById('globalDate');
    dateInput.value = K.state.date;
    dateInput.addEventListener('change', () => {
      K.state.date = dateInput.value || K.todayStr();
      resetDateSensitive();
      navigate(K.state.route);
    });

    const autoSelect = document.getElementById('autoRefresh');
    let savedAuto = 0;
    try { savedAuto = Number(localStorage.getItem('kpl.auto') || 0); } catch (_) {}
    if (![0, 10, 30, 60].includes(savedAuto)) savedAuto = 0;
    autoSelect.value = String(savedAuto);
    setAuto(savedAuto);
    autoSelect.addEventListener('change', () => {
      setAuto(autoSelect.value);
      K.toast(Number(autoSelect.value) ? `自动刷新已开启：${autoSelect.value} 秒` : '自动刷新已关闭');
    });

    document.getElementById('refreshBtn').addEventListener('click', async () => {
      const btn = document.getElementById('refreshBtn');
      btn.disabled = true;
      btn.classList.add('loading');
      try {
        await K.api('clearCache');
        resetDateSensitive();
        await navigate(K.state.route);
        K.toast('已刷新', 'success', 1800);
      } catch (err) {
        K.toast(err.message, 'error');
      } finally {
        btn.disabled = false;
        btn.classList.remove('loading');
      }
    });

    updateClock();
    setInterval(updateClock, 1000);

    let initial = 'featured';
    try {
      const styleVersion = localStorage.getItem('kpl.styleVersion');
      if (styleVersion === 'aidingpan') {
        initial = localStorage.getItem('kpl.route') || 'featured';
      } else {
        localStorage.setItem('kpl.styleVersion', 'aidingpan');
        initial = 'featured';
      }
    } catch (_) {}
    if (!META[initial]) initial = 'featured';
    navigate(initial);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
