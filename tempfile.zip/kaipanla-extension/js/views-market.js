/* 开盘啦盯盘助手 - 市场/板块视图 */
(function () {
  'use strict';

  const V = window.Views = window.Views || {};
  const today = () => K.todayStr();
  const currentDate = () => K.state.date || today();
  const isHistory = () => currentDate() !== today();
  const addDays = (date, n) => {
    const d = new Date(`${date}T12:00:00`);
    d.setDate(d.getDate() + n);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  };

  function inlineError(label, res) {
    if (!res || res.ok) return '';
    return `<div class="inline-error"><b>${K.esc(label)}</b> ${K.esc(res.error || '')}</div>`;
  }

  function indexTable(items) {
    return K.table([
      { key: 'name', label: '指数', render: r => `<span class="strong">${K.esc(r.name)}</span><span class="muted small"> ${K.esc(r.code)}</span>` },
      { key: 'price', label: '最新', align: 'right', render: r => `<span class="num">${K.fmtPrice(r.price)}</span>` },
      { key: 'changePct', label: '涨跌幅', align: 'right', render: r => K.pctCell(r.changePct) },
      { key: 'turnover', label: '成交额', align: 'right', render: r => K.bigCell(r.turnover) }
    ], items, { emptyText: '暂无指数数据' });
  }

  V.overview = async function () {
    K.setPage('市场总览', '涨停、情绪、指数与热点板块一屏掌握', 'KAI PAN LA · MARKET OVERVIEW');
    K.render(K.loading('正在汇总实时盘面…'));
    const [mood, limit, indexes, rise, sectors, ladder, volume, volumeHistory, marketCapacity, marketCapacityHistory] = await K.parallel([
      () => K.api('realtimeMood'),
      () => K.api('realtimeLimit'),
      () => K.api('realtimeIndexList'),
      () => K.api('riseFall'),
      () => K.api('sectorRanking', { date: currentDate(), index: 0 }),
      () => K.api('marketLadder', { date: '' }),
      () => K.api('marketVolume'),
      () => K.api('marketVolumeHistory', { type: '4', days: 10 }),
      () => K.api('marketCapacity', { date: currentDate() }),
      () => K.api('marketCapacityHistory', { date: currentDate(), days: 10 })
    ]);
    const m = mood.ok ? mood.data : {};
    const l = limit.ok ? limit.data : {};
    const idx = indexes.ok ? indexes.data.items : [];
    const rf = rise.ok ? rise.data : {};
    const sec = sectors.ok ? sectors.data : { summary: {}, sectors: [] };
    const ml = ladder.ok ? ladder.data : { stats: {}, ladder: [] };
    const vol = volume.ok ? (volume.data || {}) : {};
    const kv = marketCapacity.ok ? (marketCapacity.data || {}) : {};
    const volumeCurrent = Number(vol.turnover || 0) || Number(kv.turnover || 0);
    const volumePrev = Number(vol.prevTurnover || 0) || Number(kv.prevTurnover || 0);
    const volumeChange = vol.change != null ? Number(vol.change) : Number(kv.change || 0);
    const volumePredict = Number(vol.predictTurnover || 0);
    const volumePct = volumePredict > 0 ? Math.max(0, Math.min(100, volumeCurrent / volumePredict * 100)) : 0;
    const kplHistoryRows = marketCapacityHistory.ok
      ? ((marketCapacityHistory.data && marketCapacityHistory.data.rows) || []).filter(x => x.date !== kv.date).slice(-9)
      : [];
    const thsHistoryRows = volumeHistory.ok
      ? ((volumeHistory.data && volumeHistory.data.rows) || []).filter(x => x.date !== vol.date).slice(-9)
      : [];
    const historyRows = kplHistoryRows.length ? kplHistoryRows : thsHistoryRows;
    const historySource = kplHistoryRows.length ? '开盘啦 MarketCapacityKLine' : '开盘啦 MarketSCLNKLine';
    const volumeBars = [...historyRows];
    if (volumePredict > 0) volumeBars.push({ date: '今日预测', turnover: volumePredict, predicted: true });
    const maxVolumeBar = volumeBars.reduce((max, x) => Math.max(max, Number(x.turnover) || 0), 0) || 1;
    const hasVolume = volume.ok || Number(kv.turnover || 0) > 0;
    const sh = idx.find(x => x.code === 'SH000001') || {};
    const sz = idx.find(x => x.code === 'SZ399001') || {};
    const totalTurnover = Number(sh.turnover || 0) + Number(sz.turnover || 0);
    const up = Number(m.up || 0), down = Number(m.down || 0);
    const totalUD = up + down || 1;
    const upPct = up / totalUD * 100;
    const topSectors = (sec.sectors || []).slice(0, 8);
    const sectorRows = topSectors.map(s => `<div class="sector-row">
      <button class="sector-name link-btn" data-sector="${K.escAttr(s.code)}" data-sector-name="${K.escAttr(s.name)}">${K.esc(s.name)}</button>
      <span class="tag">${s.count} 只涨停</span>
      <div class="chip-row">${s.stocks.slice(0, 4).map(x => K.stockChip(x)).join('')}</div>
    </div>`).join('');

    K.render(`
      <div class="hero-grid">
        <div class="hero-card hero-primary">
          <div class="hero-label">上证指数 <span class="muted">${K.esc(sh.code || 'SH000001')}</span></div>
          <div class="hero-value ${K.pctClass(sh.changePct)}">${K.fmtPrice(sh.price)}</div>
          <div class="hero-change ${K.pctClass(sh.changePct)}">${K.fmtPct(sh.changePct)} <span class="muted">${K.esc(sh.change > 0 ? '+' : '')}${K.fmtNum(sh.change)}</span></div>
          <div class="hero-meta">两市成交额 <b>${K.fmtBig(totalTurnover)}</b> · ${K.esc(sec.summary.date || currentDate())}</div>
        </div>
        <div class="hero-card">
          <div class="hero-label">涨停 / 跌停</div>
          <div class="hero-value"><span class="up">${K.fmtInt(l.actualLimitUp ?? m.limitUp)}</span><span class="hero-divider">/</span><span class="down">${K.fmtInt(l.actualLimitDown ?? m.limitDown)}</span></div>
          <div class="hero-meta">含一字：${K.fmtInt(l.limitUp)} / ${K.fmtInt(l.limitDown)}</div>
          <div class="mini-bars"><span class="bar-up" style="width:${Math.min(100, Number(l.limitUp || 0) / Math.max(1, Number(l.limitUp || 0) + Number(l.limitDown || 0)) * 100)}%"></span><span class="bar-down" style="width:${Math.min(100, Number(l.limitDown || 0) / Math.max(1, Number(l.limitUp || 0) + Number(l.limitDown || 0)) * 100)}%"></span></div>
        </div>
        <div class="hero-card">
          <div class="hero-label">上涨 / 下跌</div>
          <div class="hero-value"><span class="up">${K.fmtInt(up)}</span><span class="hero-divider">/</span><span class="down">${K.fmtInt(down)}</span></div>
          <div class="hero-meta">涨跌比 <b class="${Number(m.ratio) >= 0 ? 'up' : 'down'}">${K.fmtNum(m.ratio, 2)}</b> · 全市场涨跌分布</div>
          <div class="ratio-bar"><span style="width:${upPct}%"></span></div>
        </div>
        <div class="hero-card">
          <div class="hero-label">昨日涨停表现</div>
          <div class="hero-value ${K.pctClass(rf.yesterdayLimitPerformance)}">${rf.yesterdayLimitPerformance == null ? '-' : K.fmtPct(rf.yesterdayLimitPerformance)}</div>
          <div class="hero-meta">昨日炸板率 ${K.fmtRate(rf.blownRate)} · 最高 ${ml.stats?.maxConsecutive || 0} 连板</div>
        </div>
      </div>

      ${hasVolume ? K.section('大盘量能预测', '同花顺量能预测 · 开盘啦 MarketCapacity 校验', `
        <div class="volume-forecast">
          <div class="volume-forecast-main">
            <span class="volume-forecast-label">预测全天成交额</span>
            <strong>${volumePredict > 0 ? K.fmtBig(volumePredict) : '-'}</strong>
            <em class="${K.pctClass(vol.predictChangeRate)}">${volumePredict > 0 ? `预测变化 ${vol.predictChangeRate == null ? '-' : K.fmtPct(vol.predictChangeRate)}` : '同花顺预测暂不可用'}</em>
          </div>
          <div class="volume-forecast-metrics">
            <div><span>当前成交额</span><b>${volumeCurrent > 0 ? K.fmtBig(volumeCurrent) : '-'}</b></div>
            <div><span>较昨日变动</span><b class="${K.pctClass(volumeChange)}">${volumeChange == null ? '-' : K.fmtBigSigned(volumeChange)}</b></div>
            <div><span>昨日成交额</span><b>${volumePrev > 0 ? K.fmtBig(volumePrev) : '-'}</b></div>
          </div>
        </div>
        ${volumePredict > 0 ? `<div class="volume-progress"><span style="width:${volumePct}%"></span></div>
        <div class="volume-progress-meta"><span>已完成预测量 ${K.fmtRate(volumePct)}</span><span>${K.esc(vol.time || '')}</span></div>` : ''}
        ${kv.turnover > 0 ? `<div class="volume-kpl">
          <div class="volume-kpl-head"><span>开盘啦量能</span><span>${K.esc(kv.time || '')}${kv.isFallback ? ` · ${K.esc(kv.date)}` : ''}</span></div>
          <div class="volume-kpl-grid">
            <div><span>当前成交额</span><b>${K.fmtBig(kv.turnover)}</b></div>
            <div><span>昨日全天</span><b>${kv.prevTurnover > 0 ? K.fmtBig(kv.prevTurnover) : '-'}</b></div>
            <div><span>较昨日</span><b class="${K.pctClass(kv.change)}">${K.fmtBigSigned(kv.change)}</b></div>
            <div><span>较昨日幅度</span><b class="${K.pctClass(kv.changeRate)}">${K.fmtPct(kv.changeRate)}</b></div>
          </div>
          ${kv.isFallback ? `<div class="volume-kpl-summary">当前日量能尚未生成，显示最近交易日 ${K.esc(kv.date)} 数据。</div>` : ''}
          ${kv.summary ? `<div class="volume-kpl-summary">${K.esc(kv.summary)}</div>` : ''}
        </div>` : ''}
        ${volumeBars.length ? `<div class="volume-history">
          <div class="volume-history-title"><span>近 10 日量能对比</span><span>${K.esc(historySource)} · 单位：亿元</span></div>
          <div class="volume-bars">${volumeBars.map(x => `<div class="volume-bar ${x.predicted ? 'predicted' : ''}" title="${K.escAttr(`${x.date} ${K.fmtBig(x.turnover)}`)}">
            <i style="height:${Math.max(4, Math.round(Number(x.turnover) / maxVolumeBar * 64))}px"></i>
            <span>${K.esc(x.predicted ? '预测' : String(x.date).slice(5))}</span>
          </div>`).join('')}</div>
        </div>` : ''}
        <div class="volume-source">数据来源：同花顺量能预测 + 开盘啦 MarketCapacity / MarketCapacityKLine · 预测值会随盘中成交额动态调整</div>
      `, '<span class="tag tag-blue">量能预测</span>') : ''}
      ${!hasVolume ? inlineError('大盘量能预测', volume) : ''}

      ${inlineError('实时情绪', mood)}${inlineError('涨跌停', limit)}${inlineError('指数', indexes)}${inlineError('涨跌分析', rise)}${inlineError('板块', sectors)}

      <div class="two-col">
        ${K.section('指数行情', indexes.ok ? '实时指数快照' : '指数数据暂不可用', indexTable(idx), `<button class="btn btn-ghost" data-goto="index">查看分时/K线</button>`)}
        ${K.section('市场情绪', '上涨/下跌家数与涨跌停对比', `
          <div class="sentiment-block">
            <div class="sentiment-line"><span class="up">上涨 ${K.fmtInt(up)}</span><span class="down">下跌 ${K.fmtInt(down)}</span></div>
            <div class="sentiment-bar"><span class="sentiment-up" style="width:${upPct}%"></span><span class="sentiment-down" style="width:${100 - upPct}%"></span></div>
            <div class="sentiment-grid">
              <div><span>涨停</span><b class="up">${K.fmtInt(l.limitUp ?? m.limitUp)}</b></div>
              <div><span>跌停</span><b class="down">${K.fmtInt(l.limitDown ?? m.limitDown)}</b></div>
              <div><span>连板高度</span><b>${ml.stats?.maxConsecutive || 0} 板</b></div>
              <div><span>连板家数</span><b>${ml.stats?.total || 0}</b></div>
            </div>
          </div>`, '')}
      </div>

      ${K.section('涨停板块 Top', sec.sectors.length ? '按涨停原因板块排序，点击板块名进入详情' : '暂无板块数据', sectorRows || K.empty('暂无板块数据'), `<button class="btn btn-ghost" data-goto="sectors">全部板块</button>`)}

      ${K.section('快捷入口', '常用功能一键直达', `
        <div class="quick-grid">
          <button class="quick-card" data-goto="ladder"><b>连板梯队</b><span>最高板 / 反包 / 板块梯队</span></button>
          <button class="quick-card" data-goto="stock"><b>个股行情</b><span>分时 / K线 / 主力大单</span></button>
          <button class="quick-card" data-goto="monitor"><b>异动监控</b><span>涨停板 / 大幅回撤 / 竞价</span></button>
          <button class="quick-card" data-goto="lhb"><b>龙虎榜</b><span>席位明细 / 买卖总额</span></button>
        </div>`)}
    `);
    bindCommon();
  };

  V.market = async function () {
    K.setPage('涨跌统计', `交易日 ${currentDate()} · 单日市场数据与百日新高`, 'KAI PAN LA · MARKET STATS');
    K.render(K.loading('正在加载历史市场数据…'));
    const d = currentDate();
    const [daily, indexes, ladder, sharp, newHigh] = await K.parallel([
      () => K.api('daily', { date: d }),
      () => K.api('marketIndex', { date: d }),
      () => K.api('ladderSummary', { date: d }),
      () => K.api('sharpWithdrawal', { date: d }),
      () => K.api('newHigh', { date: d })
    ]);
    const x = daily.ok ? daily.data : {};
    const l = ladder.ok ? ladder.data : {};
    const s = sharp.ok ? sharp.data : { items: [], count: 0 };
    const nh = newHigh.ok ? newHigh.data : { rows: [], single: null };

    K.render(`
      ${x.isRealtime ? `<div class="callout">${K.esc(x.note || '今日历史日线尚未生成，当前使用实时接口汇总；收盘后会切换为完整日线。')}</div>` : ''}
      ${inlineError('单日数据', daily)}${inlineError('指数', indexes)}${inlineError('连板统计', ladder)}${inlineError('大幅回撤', sharp)}${inlineError('百日新高', newHigh)}
      ${K.statsGrid([
        { label: '涨停数', value: K.fmtInt(x.limitUp), sub: `实际 ${K.fmtInt(x.actualLimitUp)}`, cls: 'up' },
        { label: '跌停数', value: K.fmtInt(x.limitDown), sub: `实际 ${K.fmtInt(x.actualLimitDown)}`, cls: 'down' },
        { label: '上涨家数', value: K.fmtInt(x.up), sub: `下跌 ${K.fmtInt(x.down)} · 平盘 ${K.fmtInt(x.flat)}` },
        { label: '连板率', value: K.fmtRate(x.consecutiveRate), sub: `首板 ${K.fmtInt(x.firstBoard)} · 2板 ${K.fmtInt(x.secondBoard)}` },
        { label: '大幅回撤', value: K.fmtInt(x.sharpCount), sub: '回撤幅度居前', cls: 'down' },
        { label: '百日新高', value: nh.single ? K.fmtInt(nh.single.newCount) : '-', sub: nh.single ? `总数 ${K.fmtInt(nh.single.total)}` : '无当日数据', cls: 'up' },
        { label: '昨日涨停表现', value: K.fmtPct(x.yesterdayLimitPerformance), sub: `连板 ${K.fmtPct(x.yesterdayConsecutivePerformance)}`, cls: K.pctClass(x.yesterdayLimitPerformance) },
        { label: '破板率', value: K.fmtRate(x.brokenRate), sub: `昨日破板 ${K.fmtPct(x.yesterdayBrokenPerformance)}`, cls: 'flat' }
      ])}

      <div class="two-col">
        ${K.section('指数数据', `交易日 ${d}`, indexTable(indexes.ok ? indexes.data.items : []))}
        ${K.section('连板结构', '来自 ZhangTingExpression', `
          <div class="metric-list">
            <div><span>首板</span><b>${K.fmtInt(l.firstBoard)}</b></div>
            <div><span>2 连板</span><b>${K.fmtInt(l.secondBoard)}</b></div>
            <div><span>3 连板</span><b>${K.fmtInt(l.thirdBoard)}</b></div>
            <div><span>4 连板以上</span><b>${K.fmtInt(l.fourthPlus)}</b></div>
            <div><span>连板率</span><b>${K.fmtRate(l.consecutiveRate)}</b></div>
            <div><span>今日破板率</span><b>${K.fmtRate(l.brokenRate)}</b></div>
            <div><span>昨日涨停今表现</span><b class="${K.pctClass(l.yesterdayLimitPerformance)}">${K.fmtPct(l.yesterdayLimitPerformance)}</b></div>
            <div><span>昨日连板今表现</span><b class="${K.pctClass(l.yesterdayConsecutivePerformance)}">${K.fmtPct(l.yesterdayConsecutivePerformance)}</b></div>
            <div><span>昨日破板今表现</span><b class="${K.pctClass(l.yesterdayBrokenPerformance)}">${K.fmtPct(l.yesterdayBrokenPerformance)}</b></div>
            <div><span>市场评价</span><b class="text">${K.esc(l.comment || '-')}</b></div>
          </div>`, '')}
      </div>

      ${K.section('大幅回撤', `共 ${K.fmtInt(s.count)} 只`, K.table([
        { key: 'code', label: '代码', render: r => `<button class="link-btn mono" data-code="${K.escAttr(r.code)}">${K.esc(r.code)}</button>` },
        { key: 'name', label: '名称', render: r => K.esc(r.name) },
        { key: 'changePct', label: '当日涨跌幅', align: 'right', render: r => K.pctCell(r.changePct) },
        { key: 'drawdownPct', label: '回撤幅度', align: 'right', render: r => K.pctCell(r.drawdownPct) },
        { key: 'price', label: '最新价', align: 'right', render: r => `<span class="num">${K.fmtPrice(r.price)}</span>` }
      ], s.items, { emptyText: '当日无大幅回撤数据' }))}

      ${K.section('区间统计', '按交易日循环单日接口，自动跳过周末与无数据日期', `
        <div class="form-row">
          <label class="inline-field"><span>开始</span><input type="date" id="dailyStart" value="${K.escAttr(addDays(d, -7))}"></label>
          <label class="inline-field"><span>结束</span><input type="date" id="dailyEnd" value="${K.escAttr(d)}"></label>
          <button class="btn" id="dailyRangeQuery">查询区间</button>
          <span class="muted small">最多 60 个交易日</span>
        </div>
        <div id="dailyRangeBox">${K.empty('选择日期区间后查询')}</div>
      `, '')}
      ${K.section('百日新高', '开盘啦百日新高数据，支持区间查询', `
        <div class="form-row">
          <label class="inline-field"><span>起始日期</span><input type="date" id="newHighStart" value="${K.escAttr(nh.rows[0]?.date || d)}"></label>
          <button class="btn" id="newHighQuery">查询区间</button>
          <span class="muted small">默认展示最近 20 个交易日</span>
        </div>
        <div id="newHighRange">${K.table([
          { key: 'date', label: '日期' },
          { key: 'newCount', label: '今日新增', align: 'right', render: r => `<span class="num up">${K.fmtInt(r.newCount)}</span>` },
          { key: 'total', label: '百日新高总数', align: 'right', render: r => `<span class="num">${K.fmtInt(r.total)}</span>` }
        ], nh.rows, { emptyText: '暂无新高数据' })}</div>
      `, '')}
    `);
    bindCommon();
    const btn = document.getElementById('newHighQuery');
    if (btn) {
      btn.addEventListener('click', async () => {
        const start = document.getElementById('newHighStart').value;
        const box = document.getElementById('newHighRange');
        if (!start) return;
        box.innerHTML = K.loading('正在查询区间…');
        try {
          const data = await K.api('newHigh', { date: d, startDate: start });
          box.innerHTML = K.table([
            { key: 'date', label: '日期' },
            { key: 'newCount', label: '今日新增', align: 'right', render: r => `<span class="num up">${K.fmtInt(r.newCount)}</span>` },
            { key: 'total', label: '百日新高总数', align: 'right', render: r => `<span class="num">${K.fmtInt(r.total)}</span>` }
          ], data.rows, { emptyText: '该区间无数据' });
        } catch (err) {
          box.innerHTML = K.errorBox(err, '新高区间查询失败');
        }
      });
    }

    document.getElementById('dailyRangeQuery')?.addEventListener('click', async () => {
      const start = document.getElementById('dailyStart').value;
      const end = document.getElementById('dailyEnd').value;
      const box = document.getElementById('dailyRangeBox');
      if (!start || !end) return;
      if (box) box.innerHTML = K.loading('正在按交易日循环查询…');
      try {
        const data = await K.api('dailyRange', { startDate: start, endDate: end });
        if (box) box.innerHTML = K.table([
          { key: 'date', label: '日期' },
          { key: 'limitUp', label: '涨停', align: 'right', render: r => `<span class="num up">${K.fmtInt(r.limitUp)}</span>` },
          { key: 'actualLimitUp', label: '实际涨停', align: 'right', render: r => `<span class="num up">${K.fmtInt(r.actualLimitUp)}</span>` },
          { key: 'limitDown', label: '跌停', align: 'right', render: r => `<span class="num down">${K.fmtInt(r.limitDown)}</span>` },
          { key: 'up', label: '上涨', align: 'right', render: r => `<span class="num up">${K.fmtInt(r.up)}</span>` },
          { key: 'down', label: '下跌', align: 'right', render: r => `<span class="num down">${K.fmtInt(r.down)}</span>` },
          { key: 'consecutiveRate', label: '连板率', align: 'right', render: r => `<span class="num">${K.fmtRate(r.consecutiveRate)}</span>` },
          { key: 'index', label: '上证涨跌', align: 'right', render: r => K.pctCell(r.index?.changePct) },
          { key: 'sharpCount', label: '大幅回撤', align: 'right', render: r => `<span class="num down">${K.fmtInt(r.sharpCount)}</span>` }
        ], data.rows, { emptyText: '区间内没有交易日数据' });
      } catch (err) {
        if (box) box.innerHTML = K.errorBox(err, '区间统计失败');
      }
    });
  };

  V.ladder = async function () {
    const vs = K.state.viewState.ladder = K.state.viewState.ladder || { tab: 'market', mode: 'realtime', consecutive: null, loading: false, full: false };
    K.setPage('连板梯队', '全市场 / 板块 / 连板详情 / 炸板', 'KAI PAN LA · LIMIT-UP LADDER');
    if (vs.loading || vs.tab !== 'consecutive') K.render(K.loading('正在加载梯队数据…'));
    const tab = vs.tab;
    const mode = vs.mode;
    const d = currentDate();
    let body = '';

    if (tab === 'consecutive') {
      if (vs.loading) body = K.loading('正在抓取连板详情（智能模式，只请求实际存在的连板高度）…');
      else if (!vs.consecutive) {
        body = `<div class="intro-box">
          <h3>连板详情</h3>
          <p>抓取每个连板高度的股票、题材与概念，输出最高板与完整梯队。</p>
          <p class="muted">默认智能模式：先读取全市场梯队，只请求实际存在的高度；完整模式会请求 2–20 板共 19 个接口。</p>
          <label class="inline-field"><input type="checkbox" id="consecutiveFull" ${vs.full ? 'checked' : ''}> 完整模式</label>
          <button class="btn btn-primary" id="loadConsecutive">加载连板详情</button>
        </div>`;
      } else {
        const c = vs.consecutive;
        body = `${K.statsGrid([
          { label: '最高板', value: `${c.maxConsecutive} 板`, sub: c.maxConsecutiveStocks || '-', cls: 'up' },
          { label: '最高板题材', value: c.maxConsecutiveConcepts || '-', sub: '按概念去重', cls: 'flat' },
          { label: '统计高度数', value: c.ladder.length, sub: c.ladder.map(x => `${x.days}板`).join(' / '), cls: '' }
        ])}
        ${K.section('连板梯队', `${c.date} · 最高 ${c.maxConsecutive} 板`, c.ladder.map(x => `
          <div class="ladder-row">
            <div class="ladder-title"><b>${x.days} 连板</b><span>${x.stocks.length} 只</span></div>
            <div class="chip-row">${x.stocks.map(s => K.stockChip({ ...s, tips: s.theme || s.concepts })).join('')}</div>
          </div>`).join('') || K.empty('暂无连板数据'))}
        ${K.section('重新加载', '数据会缓存 20 秒', `<label class="inline-field"><input type="checkbox" id="consecutiveFull" ${vs.full ? 'checked' : ''}> 完整模式</label> <button class="btn" id="reloadConsecutive">重新抓取</button>`)}`;
      }
    } else {
      let res;
      if (tab === 'market') {
        res = await K.apiSafe('marketLadder', { date: mode === 'history' ? d : '' });
      } else if (tab === 'sector') {
        res = await K.apiSafe('sectorLadder', { date: mode === 'history' ? d : '' });
      } else {
        res = await K.apiSafe('brokenLimitUp', { date: d });
      }
      if (!res.ok) body = K.errorBox(new Error(res.error), '梯队数据加载失败');
      else if (tab === 'market') {
        const ml = res.data;
        body = `${K.statsGrid([
          { label: '涨停家数', value: ml.stats.total, sub: '不含反包/打开高度', cls: 'up' },
          { label: '最高板', value: `${ml.stats.maxConsecutive} 板`, sub: ml.realtime ? (ml.stale ? `最新 ${ml.date}` : '实时') : '历史', cls: '' },
          { label: '连板分布', value: Object.entries(ml.stats.distribution).map(([k, v]) => `${k}板 ${v}`).join(' · ') || '-', sub: '按高度统计', cls: 'flat' }
        ])}
        ${K.section('全市场梯队', `${ml.date} · ${ml.realtime ? (ml.stale ? '最新' : '实时') : '历史'}`, ml.ladder.map(x => `
          <div class="ladder-row">
            <div class="ladder-title"><b>${x.days} 连板</b><span>${x.stocks.length} 只</span></div>
            <div class="chip-row">${x.stocks.map(s => K.stockChip(s)).join('')}</div>
          </div>`).join('') || K.empty('暂无连板梯队'))}
        <div class="two-col">
          ${K.section('反包板', `${ml.broken.length} 只`, ml.broken.length ? `<div class="chip-row">${ml.broken.map(s => K.stockChip({ ...s, tips: s.tips || '反包' }, 'broken')).join('')}</div>` : K.empty('暂无反包板'))}
          ${K.section('打开高度', `${ml.height.length} 只`, ml.height.length ? `<div class="chip-row">${ml.height.map(s => K.stockChip({ ...s, tips: s.tips || '打开高度' }, 'height')).join('')}</div>` : K.empty('暂无打开高度'))}
        </div>`;
      } else if (tab === 'sector') {
        const sl = res.data;
        body = `${K.statsGrid([
          { label: '板块数', value: sl.sectors.length, sub: sl.realtime ? (sl.stale ? `最新 ${sl.date}` : '实时') : '历史', cls: '' },
          { label: '涨停板块', value: sl.sectors.reduce((s, x) => s + x.count, 0), sub: '按板块 Count 汇总', cls: 'up' },
          { label: '最高板', value: `${Math.max(0, ...sl.sectors.flatMap(x => x.stocks.map(s => s.consecutiveDays)))} 板`, sub: '板块内最高', cls: '' }
        ])}
        ${sl.sectors.map(sec => K.details(`${sec.name} · ${sec.count} 只`, `<span class="muted">${K.esc(sec.code)}</span>`, `
          <div class="ladder-block">
            ${[...new Set(sec.stocks.map(s => s.consecutiveDays))].sort((a, b) => b - a).map(days => {
              const arr = sec.stocks.filter(s => s.consecutiveDays === days);
              if (!arr.length) return '';
              return `<div class="ladder-sub"><b>${days} 连板</b><div class="chip-row">${arr.map(s => K.stockChip(s)).join('')}</div></div>`;
            }).join('')}
            ${sec.broken.length ? `<div class="ladder-sub"><b class="down">反包</b><div class="chip-row">${sec.broken.map(s => K.stockChip({ ...s, tips: s.tips || '反包' }, 'broken')).join('')}</div></div>` : ''}
            ${sec.height.length ? `<div class="ladder-sub"><b>打开高度</b><div class="chip-row">${sec.height.map(s => K.stockChip({ ...s, tips: s.tips || '高度' }, 'height')).join('')}</div></div>` : ''}
          </div>`, sec.count >= 5)).join('') || K.empty('暂无板块梯队')}`;
      } else {
        const b = res.data;
        body = `${K.section('炸板列表', `${b.date} · 共 ${b.items.length} 只`, K.table([
          { key: 'code', label: '代码', render: r => `<button class="link-btn mono" data-code="${K.escAttr(r.code)}">${K.esc(r.code)}</button>` },
          { key: 'name', label: '名称' },
          { key: 'changePct', label: '涨跌幅', align: 'right', render: r => K.pctCell(r.changePct) },
          { key: 'limitUpTime', label: '涨停时间', align: 'right' },
          { key: 'openTime', label: '打开时间', align: 'right' },
          { key: 'yesterdayBoardText', label: '昨日连板', align: 'center' },
          { key: 'mainNet', label: '主力净额', align: 'right', render: r => K.moneyCell(r.mainNet) },
          { key: 'turnover', label: '成交额', align: 'right', render: r => K.bigCell(r.turnover) }
        ], b.items, { emptyText: '当日无炸板数据' }))}`;
      }
    }

    K.render(`
      <div class="toolbar">
        ${K.tabs([
          { id: 'market', label: '全市场' },
          { id: 'sector', label: '板块梯队' },
          { id: 'consecutive', label: '连板详情' },
          { id: 'broken', label: '炸板' }
        ], tab)}
        <div class="toolbar-right">
          ${tab !== 'consecutive' && tab !== 'broken' ? K.tabs([{ id: 'realtime', label: '实时' }, { id: 'history', label: '历史' }], mode, 'data-mode') : ''}
          <span class="muted small">${tab === 'broken' ? `日期 ${d}` : mode === 'history' ? `历史日期 ${d}` : '实时数据'}</span>
        </div>
      </div>
      <div class="view-body">${body}</div>
    `);
    bindCommon();
    document.querySelectorAll('#content [data-tab]').forEach(btn => {
      btn.addEventListener('click', () => {
        vs.tab = btn.getAttribute('data-tab');
        V.ladder();
      });
    });

    document.querySelectorAll('[data-mode]').forEach(btn => {
      btn.addEventListener('click', () => {
        vs.mode = btn.getAttribute('data-mode');
        if (tab === 'consecutive') vs.consecutive = null;
        V.ladder();
      });
    });
    const loadBtn = document.getElementById('loadConsecutive');
    if (loadBtn) {
      loadBtn.addEventListener('click', async () => {
        vs.full = !!document.getElementById('consecutiveFull')?.checked;
        vs.loading = true;
        V.ladder();
        try {
          vs.consecutive = await K.api('consecutive', { date: d, full: vs.full });
        } catch (err) {
          K.toast(err.message, 'error');
          vs.consecutive = null;
        } finally {
          vs.loading = false;
          V.ladder();
        }
      });
    }
    const reloadBtn = document.getElementById('reloadConsecutive');
    if (reloadBtn) {
      reloadBtn.addEventListener('click', async () => {
        vs.full = !!document.getElementById('consecutiveFull')?.checked;
        vs.consecutive = null;
        vs.loading = true;
        V.ladder();
        try { vs.consecutive = await K.api('consecutive', { date: d, full: vs.full }); }
        catch (err) { K.toast(err.message, 'error'); }
        finally { vs.loading = false; V.ladder(); }
      });
    }
  };

  V.sectors = async function () {
    const vs = K.state.viewState.sectors = K.state.viewState.sectors || { index: 0 };
    K.setPage('涨停原因', '按涨停原因分类的板块与个股明细', 'KAI PAN LA · LIMIT-UP SECTORS');
    K.render(K.loading('正在加载涨停原因板块…'));
    let res;
    try {
      res = await K.api('sectorRanking', { date: currentDate(), index: vs.index });
    } catch (err) {
      K.render(K.errorBox(err, '涨停原因板块加载失败'));
      return;
    }
    const data = res;
    const s = data.summary || {};
    const sectors = data.sectors || [];
    const sectorHtml = sectors.map((sec, idx) => {
      return K.details(`${sec.name} · ${sec.count} 只`, `<span class="muted mono">${K.esc(sec.code)}</span>`, `
        <div class="acc-tools"><button class="btn btn-ghost btn-sm" data-sector="${K.escAttr(sec.code)}" data-sector-name="${K.escAttr(sec.name)}">进入板块行情</button></div>
        ${K.table([
          { key: 'code', label: '代码', render: r => `<button class="link-btn mono" data-code="${K.escAttr(r.code)}">${K.esc(r.code)}</button>` },
          { key: 'name', label: '名称', render: r => `<span class="strong">${K.esc(r.name)}</span>` },
          { key: 'price', label: '价格', align: 'right', render: r => `<span class="num">${K.fmtPrice(r.price)}</span>` },
          { key: 'boardText', label: '连板', align: 'center', render: r => `<span class="tag ${/首板/.test(r.boardText) ? 'tag-blue' : 'tag-red'}">${K.esc(r.boardText || '-')}</span>` },
          { key: 'concepts', label: '概念', render: r => `<span class="ellipsis" title="${K.escAttr(r.concepts)}">${K.esc(r.concepts)}</span>` },
          { key: 'sealAmount', label: '封单额', align: 'right', render: r => K.bigCell(r.sealAmount) },
          { key: 'turnover', label: '成交额', align: 'right', render: r => K.bigCell(r.turnover) },
          { key: 'turnoverRate', label: '换手', align: 'right', render: r => `<span class="num">${K.fmtRate(r.turnoverRate)}</span>` },
          { key: 'floatCap', label: '流通市值', align: 'right', render: r => K.bigCell(r.floatCap) },
          { key: 'reason', label: '涨停原因', render: r => `<span class="ellipsis reason-cell" title="${K.escAttr(r.reason)}">${K.esc(r.reason || r.theme || '-')}</span>` }
        ], sec.stocks, { emptyText: '该板块暂无明细' })}`, idx < 2);
    }).join('');

    K.render(`
      ${K.statsGrid([
        { label: '上涨家数', value: K.fmtInt(s.up), sub: `下跌 ${K.fmtInt(s.down)}`, cls: 'up' },
        { label: '涨停数', value: K.fmtInt(s.limitUp), sub: `跌停 ${K.fmtInt(s.limitDown)}`, cls: 'up' },
        { label: '炸板率', value: K.fmtRate(s.ratio), sub: `昨日涨停表现 ${K.fmtPct(s.prevRatio)}`, cls: 'flat' },
        { label: '板块数', value: sectors.length, sub: `日期 ${data.date}`, cls: '' }
      ])}
      <div class="toolbar">
        <div class="muted small">第 ${vs.index / 100 + 1} 页 · 每页最多 100 个板块</div>
        <div class="toolbar-right">
          <button class="btn btn-ghost" id="sectorPrev" ${vs.index <= 0 ? 'disabled' : ''}>上一页</button>
          <button class="btn btn-ghost" id="sectorNext" ${sectors.length < 100 ? 'disabled' : ''}>下一页</button>
        </div>
      </div>
      ${sectorHtml || K.empty('当前页无板块数据', '可尝试上一页或切换交易日')}
    `);
    bindCommon();
    document.getElementById('sectorPrev')?.addEventListener('click', () => { vs.index = Math.max(0, vs.index - 100); V.sectors(); });
    document.getElementById('sectorNext')?.addEventListener('click', () => { vs.index += 100; V.sectors(); });
  };

  V.sector = async function () {
    const prefs = K.state.prefs;
    const vs = K.state.viewState.sector = K.state.viewState.sector || {
      code: prefs.sectorCode || '801346', tab: 'capital', mode: 'realtime', all: false,
      strengthRows: null, strengthStart: '', strengthEnd: ''
    };
    K.setPage('板块行情', '资金、强度、分时、成交量、成分股与竞价异动', 'KAI PAN LA · SECTOR DETAIL');
    K.render(K.loading('正在加载板块数据…'));
    const code = vs.code || '801346';
    const mode = vs.mode;
    const d = currentDate();
    const useDate = mode === 'history' ? d : '';
    let body = '';

    try {
      if (vs.tab === 'capital') {
        const data = await K.api('sectorCapital', { code, date: useDate });
        body = `${K.statsGrid([
          { label: '成交额', value: K.fmtBig(data.turnover), sub: `换手(计算) ${K.fmtRate(data.turnoverRateCalc)}`, cls: '' },
          { label: '涨跌幅', value: K.fmtPct(data.changePct), sub: `主力净额占比 ${K.fmtNum(data.mainNetPct)}%`, cls: K.pctClass(data.changePct) },
          { label: '主力净额', value: K.fmtBigSigned(data.mainNet), sub: `净额 ${K.fmtBigSigned(data.netAmount)}`, cls: data.mainNet >= 0 ? 'up' : 'down' },
          { label: '上涨/下跌', value: `${K.fmtInt(data.up)} / ${K.fmtInt(data.down)}`, sub: `平盘 ${K.fmtInt(data.flat)}`, cls: '' },
          { label: '流通市值', value: K.fmtBig(data.floatCap), sub: `总市值 ${K.fmtBig(data.totalCap)}`, cls: '' }
        ])}
        ${K.section('盘口原始字段', `板块 ${code} · ${mode === 'history' ? d : '实时'}`, K.table([
          { key: 'k', label: '字段' }, { key: 'v', label: '值', align: 'right' }
        ], [
          { k: '成交额', v: K.fmtBig(data.turnover) },
          { k: '涨跌幅', v: K.fmtPct(data.changePct) },
          { k: '主力净额', v: K.fmtBigSigned(data.mainNet) },
          { k: '主力卖出', v: K.fmtBigSigned(data.mainSell) },
          { k: '净额', v: K.fmtBigSigned(data.netAmount) },
          { k: '上涨 / 下跌 / 平盘', v: `${data.up} / ${data.down} / ${data.flat}` },
          { k: '流通市值', v: K.fmtBig(data.floatCap) },
          { k: '总市值', v: K.fmtBig(data.totalCap) },
          { k: '板块强度', v: K.fmtNum(data.strength) },
          { k: '换手率(计算)', v: K.fmtRate(data.turnoverRateCalc) },
          { k: '扩展字段', v: K.fmtNum(data.extra) }
        ]))}`;
      } else if (vs.tab === 'strength') {
        const single = await K.api('sectorStrength', { code, date: d });
        vs._strength = single;
        body = `${K.statsGrid([
          { label: '当前强度', value: single.strength == null ? '-' : K.fmtNum(single.strength, 2), sub: `${single.date} ${single.time}`, cls: single.strength > 0 ? 'up' : single.strength < 0 ? 'down' : '' },
          { label: '区间', value: `${single.min || '-'} ~ ${single.max || '-'}`, sub: `MinDay ${single.minDay || '-'}`, cls: '' },
          { label: '数据源', value: single.isRealtime ? '实时' : '历史', sub: 'GetPlate_Info_QJ', cls: 'flat' }
        ])}
        ${K.section('强度历史', '选择日期区间后查询（最多 120 天，自动跳过非交易日）', `
          <div class="form-row">
            <label class="inline-field"><span>开始</span><input type="date" id="strengthStart" value="${K.escAttr(vs.strengthStart || d)}"></label>
            <label class="inline-field"><span>结束</span><input type="date" id="strengthEnd" value="${K.escAttr(vs.strengthEnd || d)}"></label>
            <button class="btn" id="strengthQuery">查询强度历史</button>
          </div>
          <div class="chart-wrap" style="height:280px"><canvas id="strengthChart"></canvas></div>
          <div id="strengthTable">${vs.strengthRows ? K.table([
            { key: 'date', label: '日期' },
            { key: 'strength', label: '强度', align: 'right', render: r => `<span class="num">${K.fmtNum(r.strength, 2)}</span>` },
            { key: 'time', label: '时间', align: 'right' }
          ], vs.strengthRows.slice(-20).reverse()) : K.empty('尚未查询历史强度')}</div>
        `, '')}
        ${K.section('N 日板块强度', '按交易日汇总涨停原因板块（组合接口）', `
          <div class="form-row">
            <label class="inline-field"><span>交易日数</span><input type="number" id="strengthNDays" min="1" max="15" value="${K.escAttr(vs.strengthNDaysNum || 7)}"></label>
            <button class="btn" id="strengthNDaysQuery">查询</button>
            <span class="muted small">最多 15 个交易日</span>
          </div>
          <div id="strengthNDaysBox">${vs.strengthNDays ? K.table([
            { key: 'date', label: '日期' },
            { key: 'code', label: '板块代码', render: r => `<span class="mono">${K.esc(r.code)}</span>` },
            { key: 'name', label: '板块' },
            { key: 'count', label: '涨停数', align: 'right', render: r => `<span class="num up">${K.fmtInt(r.count)}</span>` },
            { key: 'stocks', label: '股票代码', render: r => `<span class="ellipsis" title="${K.escAttr(r.stocks.join(','))}">${K.esc(r.stocks.slice(0, 12).join(','))}${r.stocks.length > 12 ? ' …' : ''}</span>` }
          ], vs.strengthNDays, { emptyText: '暂无数据' }) : K.empty('尚未查询 N 日强度')}</div>
        `, '')}`;
      } else if (vs.tab === 'intraday') {
        const data = await K.api('sectorIntraday', { code, date: useDate });
        vs._intraday = data;
        body = `${K.statsGrid([
          { label: '现价', value: K.fmtPrice(data.close), sub: `昨收 ${K.fmtPrice(data.preclose)}`, cls: K.pctClass(data.close - data.preclose) },
          { label: '开/高/低', value: `${K.fmtPrice(data.open)} / ${K.fmtPrice(data.high)} / ${K.fmtPrice(data.low)}`, sub: `${data.points.length} 个分钟点`, cls: '' },
          { label: '区间涨跌', value: K.fmtPct(data.preclose ? (data.close - data.preclose) / data.preclose * 100 : 0), sub: data.date, cls: K.pctClass(data.close - data.preclose) }
        ])}
        ${K.section('板块分时', `${code} · ${data.date}`, `<div class="chart-wrap" style="height:380px"><canvas id="sectorChart"></canvas></div>`)}
        ${K.section('分时明细', '最近 30 个分钟点', K.table([
          { key: 'time', label: '时间' },
          { key: 'price', label: '价格', align: 'right', render: r => `<span class="num">${K.fmtPrice(r.price)}</span>` },
          { key: 'avg', label: '均价', align: 'right', render: r => `<span class="num">${K.fmtPrice(r.avg)}</span>` },
          { key: 'volume', label: '成交量', align: 'right', render: r => K.bigCell(r.volume) },
          { key: 'turnover', label: '成交额', align: 'right', render: r => K.bigCell(r.turnover) }
        ], data.points.slice(-30).reverse()))}`;
      } else if (vs.tab === 'volume') {
        const data = await K.api('sectorVolume', { code, date: useDate });
        vs._volume = data;
        body = `${K.section('板块成交量/成交额', `${code} · ${data.date}`, `
          <div class="chart-wrap" style="height:300px"><canvas id="sectorVolChart"></canvas></div>
          <div class="chart-wrap" style="height:240px;margin-top:12px"><canvas id="sectorTurnoverChart"></canvas></div>`)}
        ${K.section('明细', '最近 30 个分钟点', K.table([
          { key: 'time', label: '时间' },
          { key: 'volume', label: '成交量', align: 'right', render: r => K.bigCell(r.volume) },
          { key: 'turnover', label: '成交额', align: 'right', render: r => K.bigCell(r.turnover) }
        ], data.points.slice(-30).reverse()))}`;
      } else if (vs.tab === 'constituents') {
        const data = await K.api('sectorConstituents', { code, date: d, order: 1, all: !!vs.all });
        const stockTable = K.table([
          { key: 'code', label: '代码', render: r => `<button class="link-btn mono" data-code="${K.escAttr(r.code)}">${K.esc(r.code)}</button>` },
          { key: 'name', label: '名称' },
          { key: 'price', label: '价格', align: 'right', render: r => `<span class="num">${K.fmtPrice(r.price)}</span>` },
          { key: 'changePct', label: '涨跌幅', align: 'right', render: r => K.pctCell(r.changePct) },
          { key: 'turnover', label: '成交额', align: 'right', render: r => K.bigCell(r.turnover) },
          { key: 'turnoverRate', label: '换手', align: 'right', render: r => `<span class="num">${K.fmtRate(r.turnoverRate)}</span>` },
          { key: 'floatCap', label: '流通市值', align: 'right', render: r => K.bigCell(r.floatCap) },
          { key: 'boardText', label: '连板', align: 'center' },
          { key: 'leader', label: '标签', align: 'center' }
        ], data.stocks, { emptyText: '暂无成分股' });
        body = `${K.statsGrid([
          { label: '核心成分股', value: data.coreCount, sub: 'Stocks 字段', cls: '' },
          { label: '当前列表', value: data.stocks.length, sub: data.all ? '已加载全部' : '第一页 30 只', cls: '' },
          { label: '接口总数', value: data.totalCount, sub: `已请求 ${data.pages} 页`, cls: 'flat' }
        ])}
        ${K.section('成分股', `${code} · ${d}`, `${stockTable}
          <div class="form-row"><button class="btn" id="loadAllConstituents" ${vs.all ? 'disabled' : ''}>加载全部成分股</button></div>`)}
        ${K.section('核心代码', 'Stocks 字段', `<div class="chip-row">${data.coreStocks.map(c => `<span class="tag mono">${K.esc(c)}</span>`).join('') || '-'}</div>`)}`;
      } else if (vs.tab === 'reason') {
        const data = await K.api('sectorBoomReasons', { code });
        const latest = data.rows[0] || {};
        const leaderChips = raw => String(raw || '').split(';').map(part => {
          const [stockCode, stockName, tips] = part.split(',');
          return stockCode && stockName ? K.stockChip({ code: stockCode, name: stockName, tips: tips || '' }) : '';
        }).join(' ');
        body = `${K.statsGrid([
          { label: '爆发原因', value: K.fmtInt(data.count), sub: '历史记录', cls: 'flat' },
          { label: '最近日期', value: latest.date || '-', sub: latest.isBoom ? '标记为爆发' : '历史记录', cls: latest.isBoom ? 'up' : '' },
          { label: '最近涨停数', value: K.fmtInt(latest.ztNum), sub: latest.strength == null ? '强度 -' : `强度 ${K.fmtNum(latest.strength, 2)}`, cls: 'up' }
        ])}
        ${K.section('板块爆发原因历史', 'GetDayBaseFaceListZDEvnArt / ZhiShuKLine · 按日期倒序', K.table([
          { key: 'date', label: '日期', width: '92px' },
          { key: 'title', label: '标题 / 原因', render: r => `<div class="strong">${K.esc(r.title || '-')}</div>${r.reason && r.reason !== r.title ? `<div class="muted small ellipsis" title="${K.escAttr(r.reason)}">${K.esc(r.reason)}</div>` : ''}` },
          { key: 'ztNum', label: '涨停数', align: 'right', render: r => `<span class="num up">${K.fmtInt(r.ztNum)}</span>` },
          { key: 'strength', label: '强度', align: 'right', render: r => `<span class="num">${K.fmtNum(r.strength, 2)}</span>` },
          { key: 'leaders', label: '领涨股', render: r => leaderChips(r.leaders) || '<span class="muted">-</span>' }
        ], data.rows, { emptyText: '该板块暂无爆发原因记录' }))}`;
      } else if (vs.tab === 'bidding') {
        const data = await K.api('sectorBidding', { date: useDate });
        const listHtml = (title, list) => K.section(title, `${list.length} 个板块`, list.length ? K.table([
          { key: 'code', label: '代码', render: r => `<button class="link-btn mono" data-sector="${K.escAttr(r.code)}">${K.esc(r.code)}</button>` },
          { key: 'name', label: '板块' },
          { key: 'volumeRatio', label: '竞价量比', align: 'right', render: r => `<span class="num">${K.fmtNum(r.volumeRatio)}</span>` },
          { key: 'anomalyAmount', label: '异动金额', align: 'right', render: r => K.bigCell(r.anomalyAmount) },
          { key: 'strength', label: '竞价强度', align: 'right', render: r => `<span class="num">${K.fmtNum(r.strength)}</span>` },
          { key: 'mainNet', label: '主力净额', align: 'right', render: r => K.moneyCell(r.mainNet) }
        ], list) : K.empty('暂无数据'));
        body = `${K.statsGrid([
          { label: '今日新增', value: data.list1.length, sub: 'List1', cls: 'up' },
          { label: '昨日延续', value: data.list2.length, sub: 'List2', cls: '' },
          { label: '其他', value: data.list3.length, sub: 'List3', cls: 'flat' }
        ])}
        ${listHtml('今日新增竞价异动', data.list1)}
        ${listHtml('昨日爆发延续', data.list2)}
        ${listHtml('其他竞价异动', data.list3)}`;
      }
    } catch (err) {
      body = K.errorBox(err, '板块数据加载失败');
    }

    K.render(`
      <div class="toolbar toolbar-wrap">
        <div class="form-row">
          <label class="inline-field"><span>板块代码</span><input type="text" id="sectorCode" value="${K.escAttr(code)}" placeholder="如 801346"></label>
          <button class="btn btn-primary" id="sectorQuery">查询</button>
          ${K.tabs([{ id: 'realtime', label: '实时' }, { id: 'history', label: '历史' }], mode, 'data-mode')}
        </div>
        ${K.tabs([
          { id: 'capital', label: '资金' },
          { id: 'strength', label: '强度' },
          { id: 'intraday', label: '分时' },
          { id: 'volume', label: '成交量' },
          { id: 'constituents', label: '成分股' },
          { id: 'reason', label: '爆发原因' },
          { id: 'bidding', label: '竞价异动' }
        ], vs.tab)}
      </div>
      <div class="view-body">${body}</div>
    `);
    bindCommon();
    document.querySelectorAll('#content [data-tab]').forEach(btn => {
      btn.addEventListener('click', () => {
        vs.tab = btn.getAttribute('data-tab');
        V.sector();
      });
    });

    document.getElementById('sectorQuery')?.addEventListener('click', () => {
      const value = document.getElementById('sectorCode').value.trim();
      if (!value) return;
      vs.code = value;
      K.state.prefs.sectorCode = value;
      K.savePrefs();
      vs.strengthRows = null;
      vs.strengthNDays = null;
      vs.all = false;
      V.sector();
    });
    document.getElementById('sectorCode')?.addEventListener('keydown', e => {
      if (e.key === 'Enter') document.getElementById('sectorQuery')?.click();
    });
    document.querySelectorAll('[data-mode]').forEach(btn => btn.addEventListener('click', () => {
      vs.mode = btn.getAttribute('data-mode');
      vs.strengthRows = null;
      vs.strengthNDays = null;
      V.sector();
    }));
    document.getElementById('loadAllConstituents')?.addEventListener('click', () => { vs.all = true; V.sector(); });
    document.getElementById('strengthNDaysQuery')?.addEventListener('click', async () => {
      const numDays = Number(document.getElementById('strengthNDays').value) || 7;
      vs.strengthNDaysNum = numDays;
      const box = document.getElementById('strengthNDaysBox');
      if (box) box.innerHTML = K.loading('正在统计 N 日板块强度…');
      try {
        const data = await K.api('sectorStrengthNDays', { endDate: d, numDays });
        vs.strengthNDays = data.rows;
        V.sector();
      } catch (err) {
        K.toast(err.message, 'error');
        if (box) box.innerHTML = K.errorBox(err, 'N 日板块强度查询失败');
      }
    });
    document.getElementById('strengthQuery')?.addEventListener('click', async () => {
      const start = document.getElementById('strengthStart').value;
      const end = document.getElementById('strengthEnd').value;
      if (!start || !end) return;
      vs.strengthStart = start; vs.strengthEnd = end;
      const table = document.getElementById('strengthTable');
      if (table) table.innerHTML = K.loading('正在查询强度历史…');
      try {
        const data = await K.api('sectorStrengthHistory', { code, startDate: start, endDate: end });
        vs.strengthRows = data.rows;
        V.sector();
      } catch (err) {
        K.toast(err.message, 'error');
        if (table) table.innerHTML = K.errorBox(err, '强度历史查询失败');
      }
    });

    requestAnimationFrame(() => {
      if (vs.tab === 'intraday' && vs._intraday) {
        const canvas = document.getElementById('sectorChart');
        if (canvas) window.Charts.trend(canvas, vs._intraday.points, {
          preClose: vs._intraday.preclose,
          title: `板块 ${code} · ${vs._intraday.date}`
        });
      }
      if (vs.tab === 'volume' && vs._volume) {
        const c1 = document.getElementById('sectorVolChart');
        const c2 = document.getElementById('sectorTurnoverChart');
        const pts = vs._volume.points || [];
        if (c1) window.Charts.line(c1, pts.map(p => p.time), pts.map(p => p.volume), { title: '每分钟成交量' });
        if (c2) window.Charts.line(c2, pts.map(p => p.time), pts.map(p => p.turnover), { title: '每分钟成交额', color: '#fbbf24' });
      }
      if (vs.tab === 'strength' && vs.strengthRows && vs.strengthRows.length) {
        const canvas = document.getElementById('strengthChart');
        if (canvas) window.Charts.line(canvas, vs.strengthRows.map(x => x.date), vs.strengthRows.map(x => x.strength), { title: '板块强度历史' });
      }
    });
  };
})();
