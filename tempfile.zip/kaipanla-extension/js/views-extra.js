/* 开盘啦盯盘助手 - 异动/龙虎榜/ETF/资讯/接口目录 */
(function () {
  'use strict';

  const V = window.Views = window.Views || {};
  const today = () => K.todayStr();
  const currentDate = () => K.state.date || today();
  const isHistory = () => currentDate() !== today();

  function inlineError(label, res) {
    if (!res || res.ok) return '';
    return `<div class="inline-error"><b>${K.esc(label)}</b> ${K.esc(res.error || '')}</div>`;
  }

  /* ============================== 异动监控 ============================== */

  function boardTypeLabel(type) {
    return { 1: '首板', 2: '2 连板', 3: '3 连板', 4: '4 连板', 5: '5 板以上' }[type] || `${type} 板`;
  }

  V.monitor = async function () {
    const vs = K.state.viewState.monitor = K.state.viewState.monitor || { tab: 'boards', board: 'all' };
    K.setPage('异动监控', '涨停板、大幅回撤、涨跌分析、炸板与竞价异动', 'KAI PAN LA · MONITOR');
    K.render(K.loading('正在加载异动数据…'));
    const tab = vs.tab;
    const d = currentDate();
    let body = '';

    if (tab === 'boards') {
      if (vs.board === 'all') {
        const res = await K.apiSafe('realtimeAllBoards');
        if (!res.ok) body = K.errorBox(new Error(res.error), '涨停板加载失败');
        else {
          const data = res.data;
          body = `${K.statsGrid([
            { label: '涨停总数', value: data.statistics.total, sub: '首板 + 连板', cls: 'up' },
            { label: '首板', value: data.statistics.firstBoard, sub: '今日首次涨停', cls: 'up' },
            { label: '连板率', value: K.fmtRate(data.statistics.consecutiveRate), sub: '非首板占比', cls: '' },
            { label: '连板梯队', value: data.groups.filter(g => g.type > 1).map(g => `${g.type}板 ${g.items.length}`).join(' · '), sub: '按高度统计', cls: 'flat' }
          ])}
          ${data.groups.map(g => g.items.length ? K.section(`${boardTypeLabel(g.type)}`, `${g.items.length} 只`, K.table([
            { key: 'code', label: '代码', render: r => `<button class="link-btn mono" data-code="${K.escAttr(r.code)}">${K.esc(r.code)}</button>` },
            { key: 'name', label: '名称', render: r => `<span class="strong">${K.esc(r.name)}</span>` },
            { key: 'price', label: '价格', align: 'right', render: r => `<span class="num">${K.fmtPrice(r.price)}</span>` },
            { key: 'changePct', label: '涨跌幅', align: 'right', render: r => K.pctCell(r.changePct) },
            { key: 'sealTime', label: '封板', align: 'right' },
            { key: 'reason', label: '题材', render: r => `<span class="ellipsis" title="${K.escAttr(r.concepts)}">${K.esc(r.reason)}</span>` },
            { key: 'sealAmount', label: '封单额', align: 'right', render: r => K.bigCell(r.sealAmount) },
            { key: 'mainNet', label: '主力净额', align: 'right', render: r => K.moneyCell(r.mainNet) },
            { key: 'turnover', label: '成交额', align: 'right', render: r => K.bigCell(r.turnover) },
            { key: 'amplitude', label: '振幅', align: 'right', render: r => K.fmtRate(r.amplitude) },
            { key: 'sectorLimitCount', label: '板块涨停', align: 'right', render: r => r.sectorLimitCount || '-' }
          ], g.items)) : '').join('')}`;
        }
      } else {
        const res = await K.apiSafe('realtimeBoards', { type: Number(vs.board) });
        if (!res.ok) body = K.errorBox(new Error(res.error), '涨停板加载失败');
        else {
          const data = res.data;
          body = `${K.statsGrid([
            { label: boardTypeLabel(Number(vs.board)), value: data.items.length, sub: data.date, cls: 'up' },
            { label: '平均封单', value: K.fmtBig(data.items.reduce((s, x) => s + x.sealAmount, 0) / Math.max(1, data.items.length)), sub: '封单额均值', cls: '' }
          ])}
          ${K.section(`${boardTypeLabel(Number(vs.board))} 列表`, `共 ${data.items.length} 只`, K.table([
            { key: 'code', label: '代码', render: r => `<button class="link-btn mono" data-code="${K.escAttr(r.code)}">${K.esc(r.code)}</button>` },
            { key: 'name', label: '名称' },
            { key: 'price', label: '价格', align: 'right', render: r => `<span class="num">${K.fmtPrice(r.price)}</span>` },
            { key: 'changePct', label: '涨跌幅', align: 'right', render: r => K.pctCell(r.changePct) },
            { key: 'sealTime', label: '封板', align: 'right' },
            { key: 'reason', label: '题材' },
            { key: 'sealAmount', label: '封单额', align: 'right', render: r => K.bigCell(r.sealAmount) },
            { key: 'mainNet', label: '主力净额', align: 'right', render: r => K.moneyCell(r.mainNet) }
          ], data.items))}`;
        }
      }
    } else if (tab === 'sharp') {
      const res = await K.apiSafe('realtimeSharp');
      if (!res.ok) body = K.errorBox(new Error(res.error), '大幅回撤加载失败');
      else {
        const data = res.data;
        body = `${K.statsGrid([
          { label: '回撤家数', value: data.count, sub: data.date, cls: 'down' },
          { label: '平均回撤', value: K.fmtPct(data.items.reduce((s, x) => s + x.pullbackPct, 0) / Math.max(1, data.items.length)), sub: '按列表均值', cls: 'down' }
        ])}
        ${K.section('实时大幅回撤', '来自 SharpWithdrawalList', K.table([
          { key: 'code', label: '代码', render: r => `<button class="link-btn mono" data-code="${K.escAttr(r.code)}">${K.esc(r.code)}</button>` },
          { key: 'name', label: '名称' },
          { key: 'boardType', label: '板型', align: 'center' },
          { key: 'tag', label: '标签' },
          { key: 'price', label: '最新价', align: 'right', render: r => `<span class="num">${K.fmtPrice(r.price)}</span>` },
          { key: 'changePct', label: '涨跌幅', align: 'right', render: r => K.pctCell(r.changePct) },
          { key: 'pullbackPct', label: '回撤', align: 'right', render: r => K.pctCell(r.pullbackPct) }
        ], data.items))}`;
      }
    } else if (tab === 'rise') {
      const [rise, t1, t2] = await K.parallel([
        () => K.api('riseFall'),
        () => K.api('realtimeIndexTrend', { stockId: '801900', time: '15:00' }),
        () => K.api('realtimeIndexTrend', { stockId: '801903', time: '15:00' })
      ]);
      const r = rise.ok ? rise.data : {};
      body = `${K.statsGrid([
        { label: '涨停', value: K.fmtInt(r.limitUp), sub: 'RiseFallAnalysis', cls: 'up' },
        { label: '跌停', value: K.fmtInt(r.limitDown), sub: '当日', cls: 'down' },
        { label: '炸板（昨）', value: K.fmtInt(r.blown), sub: `昨日炸板率 ${K.fmtRate(r.blownRate)}`, cls: 'down' },
        { label: '破板（昨）', value: K.fmtInt(r.broken), sub: '上一交易日数据', cls: '' },
        { label: '昨日涨停表现', value: K.fmtPct(r.yesterdayLimitPerformance), sub: '801900', cls: K.pctClass(r.yesterdayLimitPerformance) },
        { label: '昨日炸板表现', value: K.fmtPct(r.yesterdayBrokenPerformance), sub: '801903', cls: K.pctClass(r.yesterdayBrokenPerformance) }
      ])}
      ${r.note ? `<div class="callout">${K.esc(r.note)}</div>` : ''}
      <div class="two-col">
        ${K.section('昨日涨停今表现', '801900 分时', `<div class="chart-wrap" style="height:260px"><canvas id="riseChart1"></canvas></div>`)}
        ${K.section('昨日炸板今表现', '801903 分时', `<div class="chart-wrap" style="height:260px"><canvas id="riseChart2"></canvas></div>`)}
      </div>`;
      requestAnimationFrame(() => {
        if (t1.ok && document.getElementById('riseChart1')) window.Charts.trend(document.getElementById('riseChart1'), t1.data.points, { preClose: t1.data.preclose, title: '801900' });
        if (t2.ok && document.getElementById('riseChart2')) window.Charts.trend(document.getElementById('riseChart2'), t2.data.points, { preClose: t2.data.preclose, title: '801903' });
      });
    } else if (tab === 'broken') {
      const res = await K.apiSafe('brokenLimitUp', { date: d });
      if (!res.ok) body = K.errorBox(new Error(res.error), '炸板数据加载失败');
      else {
        const data = res.data;
        body = `${K.section('历史炸板', `${data.date} · 共 ${data.items.length} 只`, K.table([
          { key: 'code', label: '代码', render: r => `<button class="link-btn mono" data-code="${K.escAttr(r.code)}">${K.esc(r.code)}</button>` },
          { key: 'name', label: '名称' },
          { key: 'changePct', label: '涨跌幅', align: 'right', render: r => K.pctCell(r.changePct) },
          { key: 'limitUpTime', label: '涨停时间', align: 'right' },
          { key: 'openTime', label: '打开时间', align: 'right' },
          { key: 'sector', label: '板块' },
          { key: 'mainNet', label: '主力净额', align: 'right', render: r => K.moneyCell(r.mainNet) },
          { key: 'turnover', label: '成交额', align: 'right', render: r => K.bigCell(r.turnover) },
          { key: 'turnoverRate', label: '换手', align: 'right', render: r => K.fmtRate(r.turnoverRate) }
        ], data.items))}`;
      }
    } else if (tab === 'sentiment') {
      const res = await K.apiSafe('sentimentIndicator', { plateId: '801225' });
      if (!res.ok) body = K.errorBox(new Error(res.error), '多空风向标加载失败');
      else {
        const data = res.data;
        const chip = (code, cls) => `<button class="stock-chip ${cls}" data-code="${K.escAttr(code)}"><b>${K.esc(code)}</b></button>`;
        body = `${K.statsGrid([
          { label: '多头风向标', value: data.bullishCodes.join(' / '), sub: `板块 ${data.plateId}`, cls: 'up' },
          { label: '空头风向标', value: data.bearishCodes.join(' / '), sub: `板块 ${data.plateId}`, cls: 'down' },
          { label: '样本数量', value: data.allStocks.length, sub: 'PlateIntroduction_Info', cls: '' }
        ])}
        ${K.section('多头风向标（前 3）', '按接口返回顺序', `<div class="chip-row">${data.bullishCodes.map(c => `<button class="stock-chip" data-code="${K.escAttr(c)}"><b>${K.esc(c)}</b></button>`).join('')}</div>`)}
        ${K.section('空头风向标（后 3）', '按接口返回顺序', `<div class="chip-row">${data.bearishCodes.map(c => `<button class="stock-chip" data-code="${K.escAttr(c)}"><b>${K.esc(c)}</b></button>`).join('')}</div>`)}
        ${K.section('全部样本', `${data.allStocks.length} 只`, `<div class="chip-row">${data.allStocks.map(c => chip(c, '')).join('')}</div>`)}`;
      }
    } else if (tab === 'hot') {
      const type = vs.hotType || 'hour';
      const res = await K.apiSafe('thsHotRank', { type, limit: 50 });
      if (!res.ok) body = K.errorBox(new Error(res.error), '同花顺热榜加载失败');
      else {
        const items = res.data.items;
        body = `${K.statsGrid([
          { label: '榜单类型', value: type === 'hour' ? '小时热度' : '日热度', sub: '同花顺热榜', cls: '' },
          { label: '上榜数量', value: items.length, sub: '前 50 名', cls: 'up' },
          { label: '平均涨幅', value: K.fmtPct(items.reduce((s, x) => s + x.changePct, 0) / Math.max(1, items.length)), sub: '榜单均值', cls: K.pctClass(items.reduce((s, x) => s + x.changePct, 0)) }
        ])}
        ${K.section('同花顺热榜', '数据来自 dq.10jqka.com.cn，作为开盘啦热度的补充', K.table([
          { key: 'order', label: '#', width: '46px' },
          { key: 'name', label: '名称', render: r => `<button class="link-btn" data-code="${K.escAttr(r.code)}">${K.esc(r.name)}</button>` },
          { key: 'code', label: '代码', render: r => `<span class="mono">${K.esc(r.code)}</span>` },
          { key: 'changePct', label: '涨跌幅', align: 'right', render: r => K.pctCell(r.changePct) },
          { key: 'rankChange', label: '排名变化', align: 'right', render: r => `<span class="num ${r.rankChange > 0 ? 'up' : r.rankChange < 0 ? 'down' : ''}">${r.rankChange > 0 ? '+' : ''}${K.fmtInt(r.rankChange)}</span>` },
          { key: 'popularity', label: '人气标签', align: 'center' },
          { key: 'concepts', label: '概念', render: r => r.concepts.map(c => `<span class="tag tag-blue">${K.esc(c)}</span>`).join(' ') || '-' }
        ], items))}`;
      }
    } else {
      const res = await K.apiSafe('sectorBidding', { date: isHistory() ? d : '' });
      if (!res.ok) body = K.errorBox(new Error(res.error), '竞价异动加载失败');
      else {
        const data = res.data;
        const make = (title, list) => K.section(title, `${list.length} 个板块`, list.length ? K.table([
          { key: 'code', label: '代码', render: r => `<button class="link-btn mono" data-sector="${K.escAttr(r.code)}">${K.esc(r.code)}</button>` },
          { key: 'name', label: '板块' },
          { key: 'volumeRatio', label: '竞价量比', align: 'right', render: r => `<span class="num">${K.fmtNum(r.volumeRatio)}</span>` },
          { key: 'anomalyAmount', label: '异动金额', align: 'right', render: r => K.bigCell(r.anomalyAmount) },
          { key: 'strength', label: '强度', align: 'right', render: r => `<span class="num">${K.fmtNum(r.strength)}</span>` },
          { key: 'mainNet', label: '主力净额', align: 'right', render: r => K.moneyCell(r.mainNet) }
        ], list) : K.empty('暂无数据'));
        body = `${K.statsGrid([
          { label: '今日新增', value: data.list1.length, sub: 'List1', cls: 'up' },
          { label: '昨日延续', value: data.list2.length, sub: 'List2', cls: '' },
          { label: '其他', value: data.list3.length, sub: 'List3', cls: 'flat' }
        ])}
        ${make('今日新增竞价异动', data.list1)}
        ${make('昨日爆发延续', data.list2)}
        ${make('其他竞价异动', data.list3)}`;
      }
    }

    K.render(`
      <div class="toolbar">
        ${K.tabs([
          { id: 'boards', label: '涨停板' },
          { id: 'sharp', label: '大幅回撤' },
          { id: 'rise', label: '涨跌分析' },
          { id: 'broken', label: '炸板' },
          { id: 'bidding', label: '竞价异动' },
          { id: 'sentiment', label: '多空风向标' },
          { id: 'hot', label: '同花顺热榜' }
        ], tab, 'data-mtab')}
        <div class="toolbar-right">
          ${tab === 'boards' ? `<select id="boardType">
            <option value="all" ${vs.board === 'all' ? 'selected' : ''}>全部涨停板</option>
            <option value="1" ${vs.board === '1' ? 'selected' : ''}>首板</option>
            <option value="2" ${vs.board === '2' ? 'selected' : ''}>2 连板</option>
            <option value="3" ${vs.board === '3' ? 'selected' : ''}>3 连板</option>
            <option value="4" ${vs.board === '4' ? 'selected' : ''}>4 连板</option>
            <option value="5" ${vs.board === '5' ? 'selected' : ''}>5 板以上</option>
          </select>` : ''}
          ${tab === 'hot' ? `<select id="hotType">
            <option value="hour" ${(vs.hotType || 'hour') === 'hour' ? 'selected' : ''}>小时热度</option>
            <option value="day" ${vs.hotType === 'day' ? 'selected' : ''}>日热度</option>
          </select>` : ''}
          <span class="muted small">${tab === 'broken' || tab === 'bidding' ? `日期 ${d}` : '实时刷新'}</span>
        </div>
      </div>
      <div class="view-body">${body}</div>
    `);
    bindCommon();
    document.querySelectorAll('[data-mtab]').forEach(btn => btn.addEventListener('click', () => {
      vs.tab = btn.getAttribute('data-mtab');
      V.monitor();
    }));
    document.getElementById('boardType')?.addEventListener('change', e => {
      vs.board = e.target.value;
      V.monitor();
    });
    document.getElementById('hotType')?.addEventListener('change', e => {
      vs.hotType = e.target.value;
      V.monitor();
    });
  };

  /* ============================== 龙虎榜 ============================== */

  async function openLhbDetail(code, date, name) {
    K.openDrawer('龙虎榜详情', `${name || code} · ${date}`, K.loading('正在加载席位明细…'));
    try {
      const d = await K.api('lhbDetail', { code, date });
      const summary = K.statsGrid([
        { label: '现价', value: K.fmtPrice(d.price), sub: K.fmtPct(d.changePct), cls: K.pctClass(d.changePct) },
        { label: '龙虎榜买入', value: K.fmtBig(d.buyIn), sub: `成交额 ${K.fmtBig(d.turnover)}`, cls: 'up' },
        { label: '换手率', value: `${K.fmtNum(d.turnoverRatio)}%`, sub: `流通盘 ${K.fmtBig(d.circulation)}`, cls: '' },
        { label: '上榜次数', value: d.onListCount, sub: `首次 ${d.onListStart}`, cls: 'flat' }
      ]);
      const groups = (d.groups || []).map((g, idx) => {
        const buy = K.table([
          { key: 'rank', label: '#', width: '38px' },
          { key: 'name', label: '买入席位' },
          { key: 'buy', label: '买入额', align: 'right', render: r => K.bigCell(r.buy) },
          { key: 'sell', label: '卖出额', align: 'right', render: r => K.bigCell(r.sell) }
        ], g.buyList, { emptyText: '无买入席位' });
        const sell = K.table([
          { key: 'rank', label: '#', width: '38px' },
          { key: 'name', label: '卖出席位' },
          { key: 'buy', label: '买入额', align: 'right', render: r => K.bigCell(r.buy) },
          { key: 'sell', label: '卖出额', align: 'right', render: r => K.bigCell(r.sell) }
        ], g.sellList, { emptyText: '无卖出席位' });
        return K.section(`席位组 ${idx + 1}`, `${g.upReason || ''} · 买入 ${K.fmtBig(g.buyTotal)} / 卖出 ${K.fmtBig(g.sellTotal)}`, `<div class="two-col">${buy}${sell}</div>`);
      }).join('');
      document.getElementById('drawerBody').innerHTML = `${summary}
        ${d.onTimeList?.length ? `<div class="tag-row">${d.onTimeList.slice(0, 12).map(x => `<span class="tag">${K.esc(x)}</span>`).join('')}</div>` : ''}
        ${groups || K.empty('暂无席位数据')}`;
    } catch (err) {
      document.getElementById('drawerBody').innerHTML = K.errorBox(err, '龙虎榜明细加载失败');
    }
  }

  V.lhb = async function () {
    K.setPage('龙虎榜', '每日龙虎榜个股与买卖席位明细', 'KAI PAN LA · DRAGON-TIGER');
    K.render(K.loading('正在加载龙虎榜…'));
    const d = currentDate();
    let data;
    try { data = await K.api('lhbList', { date: d, pageSize: 500 }); }
    catch (err) { K.render(K.errorBox(err, '龙虎榜加载失败')); return; }
    K.render(`
      ${K.statsGrid([
        { label: '上榜个股', value: data.items.length, sub: `${data.date}`, cls: 'up' },
        { label: '买入总额', value: K.fmtBig(data.items.reduce((s, x) => s + x.buyAmount, 0)), sub: '列表合计', cls: 'up' },
        { label: '成交额合计', value: K.fmtBig(data.items.reduce((s, x) => s + x.turnover, 0)), sub: '列表合计', cls: '' }
      ])}
      ${K.section('龙虎榜列表', `${data.date} · 点击行查看席位明细（当日 16:30 后数据更完整）`, K.table([
        { key: 'code', label: '代码', render: r => `<button class="link-btn mono" data-code="${K.escAttr(r.code)}">${K.esc(r.code)}</button>` },
        { key: 'name', label: '名称', render: r => `<span class="strong">${K.esc(r.name)}</span>` },
        { key: 'changePct', label: '涨跌幅', align: 'right', render: r => K.pctCell(r.changePct) },
        { key: 'reasonType', label: '上榜原因', align: 'center' },
        { key: 'buyAmount', label: '买入额', align: 'right', render: r => K.bigCell(r.buyAmount) },
        { key: 'joinNum', label: '参与数', align: 'right', render: r => K.fmtInt(r.joinNum) },
        { key: 'turnover', label: '成交额', align: 'right', render: r => K.bigCell(r.turnover) },
        { key: 'turnoverRatio', label: '换手率', align: 'right', render: r => K.fmtRate(r.turnoverRatio) },
        { key: 'amplitude', label: '振幅', align: 'right', render: r => K.fmtRate(r.amplitude) },
        { key: 'floatCap', label: '流通市值', align: 'right', render: r => K.bigCell(r.floatCap) }
      ], data.items, { rowClass: () => 'row-clickable' }))}
    `);
    bindCommon();
    K.bindRows(document.getElementById('content'), data.items, row => openLhbDetail(row.code, data.date, row.name));
  };

  /* ============================== ETF 排行 ============================== */

  V.etf = async function () {
    const vs = K.state.viewState.etf = K.state.viewState.etf || { order: 1, all: false };
    K.setPage('ETF 排行', '开盘啦 ETF 涨幅、成交额、区间收益与规模', 'KAI PAN LA · ETF');
    K.render(K.loading('正在加载 ETF 排行…'));
    const d = currentDate();
    let data;
    try {
      data = vs.all
        ? await K.api('allEtfRanking', { date: isHistory() ? d : '', order: vs.order, maxPages: 30 })
        : await K.api('etfRanking', { date: isHistory() ? d : '', order: vs.order, index: 0 });
    } catch (err) {
      K.render(K.errorBox(err, 'ETF 排行加载失败'));
      return;
    }
    K.render(`
      <div class="toolbar">
        ${K.tabs([{ id: '1', label: '涨幅降序' }, { id: '2', label: '涨幅升序' }], String(vs.order), 'data-order')}
        <div class="toolbar-right">
          <span class="muted small">${data.isRealtime ? '实时' : data.date} · ${data.items.length} 只</span>
          <button class="btn" id="etfAll" ${vs.all ? 'disabled' : ''}>加载全部</button>
        </div>
      </div>
      ${K.section('ETF 列表', '区间收益单位：%', K.table([
        { key: 'code', label: '代码', render: r => `<span class="mono">${K.esc(r.code)}</span>` },
        { key: 'name', label: '名称', render: r => `<span class="strong">${K.esc(r.name)}</span>` },
        { key: 'price', label: '价格', align: 'right', render: r => `<span class="num">${K.fmtPrice(r.price)}</span>` },
        { key: 'changePct', label: '涨跌幅', align: 'right', render: r => K.pctCell(r.changePct) },
        { key: 'turnover', label: '成交额', align: 'right', render: r => K.bigCell(r.turnover) },
        { key: 'volumeRatio', label: '量比', align: 'right', render: r => `<span class="num">${K.fmtNum(r.volumeRatio)}</span>` },
        { key: 'week', label: '近1周', align: 'right', render: r => K.pctCell(r.week) },
        { key: 'month', label: '近1月', align: 'right', render: r => K.pctCell(r.month) },
        { key: 'month3', label: '近3月', align: 'right', render: r => K.pctCell(r.month3) },
        { key: 'month6', label: '近6月', align: 'right', render: r => K.pctCell(r.month6) },
        { key: 'ytd', label: '今年以来', align: 'right', render: r => K.pctCell(r.ytd) },
        { key: 'totalCap', label: '规模', align: 'right', render: r => K.bigCell(r.totalCap) }
      ], data.items, { emptyText: '暂无 ETF 数据' }))}
    `);
    bindCommon();
    document.querySelectorAll('[data-order]').forEach(btn => btn.addEventListener('click', () => {
      vs.order = Number(btn.getAttribute('data-order'));
      V.etf();
    }));
    document.getElementById('etfAll')?.addEventListener('click', () => { vs.all = true; V.etf(); });
  };

  /* ============================== 板块资讯 ============================== */

  V.news = async function () {
    const prefs = K.state.prefs;
    const vs = K.state.viewState.news = K.state.viewState.news || {
      plateId: prefs.plateId || '801346', items: [], index: 0, pageSize: 20, loaded: false, plates: []
    };
    K.setPage('板块资讯', '开盘啦板块新闻与快讯', 'KAI PAN LA · NEWS');
    if (!vs.loaded) {
      K.render(K.loading('正在加载板块资讯…'));
      const [news, sectors] = await K.parallel([
        () => K.api('plateNews', { plateId: vs.plateId, index: 0, pageSize: vs.pageSize }),
        () => K.api('sectorRanking', { date: currentDate(), index: 0 })
      ]);
      if (news.ok) vs.items = news.data.items;
      if (sectors.ok) vs.plates = (sectors.data.sectors || []).slice(0, 10);
      vs.index = 0;
      vs.loaded = true;
    }
    const cards = vs.items.map(x => `<article class="news-card">
      <div class="news-meta"><span class="tag ${x.type === 1 ? 'tag-red' : 'tag-blue'}">${K.esc(x.typeName)}</span><span>${K.esc(x.datetime)}</span><span class="mono">ID ${K.esc(x.id)}</span></div>
      <h3>${K.esc(x.title)}</h3>
      <p>${K.esc(x.content)}</p>
    </article>`).join('');
    K.render(`
      <div class="toolbar toolbar-wrap">
        <div class="form-row">
          <label class="inline-field"><span>板块代码</span><input type="text" id="newsPlate" value="${K.escAttr(vs.plateId)}" placeholder="如 801346 / 803023"></label>
          <button class="btn btn-primary" id="newsQuery">查询</button>
          <button class="btn" id="newsMore">加载更多</button>
        </div>
        <div class="chip-row">${(vs.plates || []).map(p => `<button class="tag tag-click ${p.code === vs.plateId ? 'active' : ''}" data-plate="${K.escAttr(p.code)}">${K.esc(p.name)}</button>`).join('')}</div>
      </div>
      <div class="news-list">${cards || K.empty('暂无资讯', '可换一个板块代码试试')}</div>
      <div class="center"><button class="btn" id="newsMore2">加载更多</button></div>
    `);
    bindCommon();
    const query = () => {
      const value = document.getElementById('newsPlate').value.trim();
      if (!value) return;
      vs.plateId = value;
      K.state.prefs.plateId = value;
      K.savePrefs();
      vs.items = []; vs.index = 0; vs.loaded = false;
      V.news();
    };
    document.getElementById('newsQuery')?.addEventListener('click', query);
    document.getElementById('newsPlate')?.addEventListener('keydown', e => { if (e.key === 'Enter') query(); });
    document.querySelectorAll('[data-plate]').forEach(btn => btn.addEventListener('click', () => {
      vs.plateId = btn.getAttribute('data-plate');
      K.state.prefs.plateId = vs.plateId;
      K.savePrefs();
      vs.items = []; vs.index = 0; vs.loaded = false;
      V.news();
    }));
    const loadMore = async () => {
      const next = vs.index + vs.pageSize;
      try {
        const data = await K.api('plateNews', { plateId: vs.plateId, index: next, pageSize: vs.pageSize });
        if (!data.items.length) { K.toast('没有更多资讯了'); return; }
        vs.items.push(...data.items);
        vs.index = next;
        V.news();
      } catch (err) { K.toast(err.message, 'error'); }
    };
    document.getElementById('newsMore')?.addEventListener('click', loadMore);
    document.getElementById('newsMore2')?.addEventListener('click', loadMore);
  };

  /* ============================== 接口目录 ============================== */

  const CATALOG = [
    {
      group: '市场数据',
      items: [
        { name: '单日完整数据（组合）', action: 'daily', params: { date: '2026-11-02' }, endpoint: 'HisZhangFuDetail + GetZsReal + ZhangTingExpression + SharpWithdrawal', host: 'apphis', desc: '一次请求 4 个接口，返回涨停、指数、连板、回撤。' },
        { name: '区间完整数据（组合）', action: 'dailyRange', params: { startDate: '2026-10-27', endDate: '2026-11-02' }, endpoint: '同单日完整数据 × 交易日', host: 'apphis', desc: '按交易日循环，自动跳过周末，最多 60 个交易日。' },
        { name: '涨跌统计', action: 'sentiment', params: { date: '2026-11-02' }, endpoint: 'HisZhangFuDetail / HisHomeDingPan', host: 'apphis', desc: '涨停、跌停、上涨、下跌、平盘。' },
        { name: '开盘啦大盘量能', action: 'marketCapacity', params: { date: '2026-11-10' }, endpoint: 'MarketCapacity / HisHomeDingPan', host: 'apphis', desc: '当前成交额、昨日成交额、增量比例和日内量能趋势。' },
        { name: '开盘啦量能历史', action: 'marketCapacityHistory', params: { date: '2026-11-10', days: 10 }, endpoint: 'MarketCapacityKLine / HisHomeDingPan', host: 'apphis', desc: '按日返回市场成交额历史，用于近 10 日量能对比。' },
        { name: '大盘指数', action: 'marketIndex', params: { date: '2026-11-02' }, endpoint: 'GetZsReal / StockL2History', host: 'apphis', desc: '上证、深证等指数快照。' },
        { name: '连板结构统计', action: 'ladderSummary', params: { date: '2026-11-02' }, endpoint: 'ZhangTingExpression / HisHomeDingPan', host: 'apphis', desc: '首板/2板/3板/高度/连板率/破板率/市场评价。' },
        { name: '大幅回撤', action: 'sharpWithdrawal', params: { date: '2026-11-02' }, endpoint: 'SharpWithdrawal / HisHomeDingPan', host: 'apphis', desc: '当日大幅回撤个股。' },
        { name: '百日新高', action: 'newHigh', params: { date: '2026-11-02', startDate: '2026-10-01' }, endpoint: 'GetDayNewHigh_W28 / StockNewHigh', host: 'apphis', desc: '返回 360 日新高序列，可筛选区间。' }
      ]
    },
    {
      group: '连板梯队',
      items: [
        { name: '全市场连板梯队', action: 'marketLadder', params: { date: '' }, endpoint: 'GetYTFP_SCTD / FuPanLa', host: 'apphwhq（实时）/ apphis（历史）', desc: 'date 为空实时；传 YYYY-MM-DD 历史。' },
        { name: '板块连板梯队', action: 'sectorLadder', params: { date: '' }, endpoint: 'GetYTFP_BKHX / FuPanLa', host: 'apphwhq / apphis', desc: '按板块聚合的连板、反包、打开高度。' },
        { name: '连板详情（组合）', action: 'consecutive', params: { date: '2026-11-02', full: false }, endpoint: 'DailyLimitPerformance / HisHomeDingPan', host: 'apphis', desc: '智能模式先读全市场梯队，只请求存在的连板高度；full=true 请求 2–20 板。' },
        { name: '历史炸板', action: 'brokenLimitUp', params: { date: '2026-11-02' }, endpoint: 'HisDaBanList / HisHomeDingPan', host: 'apphis', desc: '炸板个股、封板时间、打开时间、主力净额。' },
        { name: '涨停板数量', action: 'boardStocksCount', params: { type: 1 }, endpoint: 'DailyLimitPerformance / HomeDingPan', host: 'apphwhq', desc: '某连板高度的数量与列表。' }
      ]
    },
    {
      group: '涨停原因 / 板块',
      items: [
        { name: '涨停原因板块', action: 'sectorRanking', params: { date: '2026-11-02', index: 0 }, endpoint: 'GetPlateInfo_w38 / DailyLimitResumption', host: 'apphwhq', desc: '市场概况 + 涨停原因板块 + 个股明细。' },
        { name: '开盘啦精选板块', action: 'featuredSectors', params: { date: '2026-11-03', zsType: '7', all: false }, endpoint: 'RealRankingInfo / ZhiShuRanking', host: 'apphwshhq / apphis（kaipanhong.com）', desc: '精选/行业/地区板块排行，zsType=7/4/6；返回涨跌幅、主力净流入、5日净流入、成交额、换手、市值与细分板块。' },
        { name: '主线追踪（组合）', action: 'sectorMainline', params: { date: '2026-11-17', days: 10, topN: 10 }, endpoint: 'RealRankingInfo × 最近交易日', host: 'apphwshhq / apphis', desc: '最近两周精选板块强度矩阵；按每日强度取 Top N，并汇总出现天数、平均强度和最佳排名。' },
        { name: '板块强度', action: 'sectorStrength', params: { code: '801346', date: '2026-11-02' }, endpoint: 'GetPlate_Info_QJ / ZhiShuRanking', host: 'apphwhq（今日）/ apphis（历史）', desc: '返回 List，强度取 List[1]。' },
        { name: '板块强度历史（组合）', action: 'sectorStrengthHistory', params: { code: '801346', startDate: '2026-10-01', endDate: '2026-11-02' }, endpoint: 'GetPlate_Info_QJ / ZhiShuRanking', host: 'apphwhq / apphis', desc: '按自然日循环，最多 120 天。' },
        { name: 'N 日板块强度（组合）', action: 'sectorStrengthNDays', params: { endDate: '2026-11-02', numDays: 3 }, endpoint: 'GetPlateInfo_w38 / DailyLimitResumption', host: 'apphwhq', desc: '按交易日循环涨停原因板块，返回日期/板块/涨停数/股票代码。' },
        { name: '多板块强度（组合）', action: 'multipleSectorStrength', params: { codes: ['801346', '803023'], date: '2026-11-02' }, endpoint: 'GetPlate_Info_QJ / ZhiShuRanking', host: 'apphwhq / apphis', desc: '批量获取多个板块强度。' },
        { name: '板块资金盘口', action: 'sectorCapital', params: { code: '801346', date: '' }, endpoint: 'GetPanKou / ZhiShuL2Data', host: 'apphwhq / apphis', desc: '成交额、涨跌幅、主力净额、涨跌家数、市值。' },
        { name: '板块分时', action: 'sectorIntraday', params: { code: '801346', date: '' }, endpoint: 'GetTrendIncremental / ZhiShuL2Data', host: 'apphwhq / apphis', desc: '每分钟价格、成交量、成交额、涨跌标志。' },
        { name: '板块成交量/额', action: 'sectorVolume', params: { code: '801346', date: '' }, endpoint: 'GetVolTurIncremental / ZhiShuL2Data', host: 'apphwhq / apphis', desc: '每分钟成交量与成交额。' },
        { name: '板块成分股', action: 'sectorConstituents', params: { code: '803023', date: '2026-11-02', order: 1, all: false }, endpoint: 'ZhiShuStockList_W8 / ZhiShuRanking', host: 'apphis', desc: '第一页 30 只；all=true 自动翻页；tag 可传开盘啦标签 ID。' },
        { name: '板块细分方向', action: 'sonPlateInfo', params: { code: '801004', date: '2026-11-10' }, endpoint: 'SonPlate_Info / ZhiShuRanking', host: 'apphq', desc: '返回子板块代码、名称和强度。' },
        { name: '板块标签', action: 'sectorTags', params: { code: '803041' }, endpoint: 'GetGPCPHBTS_Tag / ZhiShuRanking', host: 'apphq', desc: '返回板块可用的排序标签，如机构增仓、低 PE、高股息。' },
        { name: '板块爆发原因', action: 'sectorBoomReasons', params: { code: '801004' }, endpoint: 'GetDayBaseFaceListZDEvnArt / ZhiShuKLine', host: 'apphis', desc: '返回板块历史爆发原因、日期、涨停数、强度和领涨股。' },
        { name: '板块人气个股（组合）', action: 'sectorHotStocks', params: { code: '801004', date: '2026-11-04' }, endpoint: 'ZhiShuStockList_W8 + GetHotPHB', host: 'apphis + apphq', desc: '板块全部成分股按开盘啦人气榜排名，未上榜按涨幅排序；今日成分接口盘中未更新时自动用上一交易日。' },
        { name: '板块竞价异动', action: 'sectorBidding', params: { date: '' }, endpoint: 'GetBKJJ_W36 / StockBidYiDong', host: 'apphwhq / apphis', desc: 'List1 今日新增、List2 昨日延续、List3 其他。' }
      ]
    },
    {
      group: '实时盘面',
      items: [
        { name: '实时市场情绪', action: 'realtimeMood', params: {}, endpoint: 'MoodNumCount / MarketMood', host: 'apphwhq', desc: '上涨、下跌、涨停、跌停、流通量、涨跌比。' },
        { name: '实时实际涨跌停', action: 'realtimeLimit', params: {}, endpoint: 'MarketStockZDNum / HomeDingPan', host: 'apphwhq', desc: '实际涨停/跌停、含一字涨停/跌停。' },
        { name: '实时涨停板', action: 'realtimeBoards', params: { type: 1 }, endpoint: 'DailyLimitPerformance / HomeDingPan', host: 'apphwhq', desc: 'type=1 首板 … 5 五板以上。' },
        { name: '全部涨停板（组合）', action: 'realtimeAllBoards', params: {}, endpoint: 'DailyLimitPerformance / HomeDingPan', host: 'apphwhq', desc: '并发请求 1–5 板，附连板率统计。' },
        { name: '指数趋势', action: 'realtimeIndexTrend', params: { stockId: '801900', time: '15:00' }, endpoint: 'GetTrendIncremental / ZhiShuL2Data', host: 'apphwhq', desc: '801900 昨日涨停表现；801903 昨日炸板表现。' },
        { name: '实时指数列表', action: 'realtimeIndexList', params: { stockIds: ['SH000001', 'SZ399001', 'SZ399006', 'SH000688'] }, endpoint: 'RefreshStockList / UserSelectStock', host: 'apphwhq', desc: '批量刷新指数快照。' },
        { name: '实时大幅回撤', action: 'realtimeSharp', params: {}, endpoint: 'SharpWithdrawalList / HomeDingPan', host: 'apphwhq', desc: '实时回撤列表。' },
        { name: '涨跌分析', action: 'riseFall', params: {}, endpoint: 'RiseFallAnalysis / HisHomeDingPan', host: 'apphis', desc: '涨停、跌停、炸板、破板、昨日表现。' },
        { name: '开盘啦人气榜', action: 'kplHotRank', params: { type: '1', limit: 50 }, endpoint: 'GetHotPHB / StockBidYiDong', host: 'apphq.longhuvip.com', desc: 'Type=1 人气榜（排名/排名变化），Type=2 最强风口（热度值）。盘中实时，最多 50 名。' }
      ]
    },
    {
      group: '分时 / 大单',
      items: [
        { name: '个股分时', action: 'stockIntraday', params: { code: '600519', date: '' }, endpoint: 'GetStockTrend / GetZstrend', host: 'apphis / apphwhq', desc: '实时自动用 GetZstrend；历史用 GetStockTrend（含主力字段时返回）。' },
        { name: '个股主力大单', action: 'stockBigOrder', params: { code: '600519', date: '2026-11-02' }, endpoint: 'GetMainMonitor_Trend_w30', host: 'apphis / apphwhq', desc: 'Date 历史；实时用 Money=2。' },
        { name: '指数分时', action: 'indexIntraday', params: { code: 'SH000001', date: '' }, endpoint: 'GetStockTrendIncremental / GetStockTrend', host: 'apphwhq / apphis', desc: '实时用 GetStockTrendIncremental；历史用 GetStockTrend。' },
        { name: '个股涨停基因', action: 'stockLimitGene', params: { code: '001330' }, endpoint: 'GetZhangTingGene / StockL2Data', host: 'apphwhq（备用 GetStockPanKou_Narrow.YJJY）', desc: '历史涨停次数、5%溢价次数、次日红盘率、首板封板率/破板率、连板率；全 0 表示暂无涨停样本。' }
      ]
    },
    {
      group: '龙虎榜 / 资讯 / ETF',
      items: [
        { name: '龙虎榜列表', action: 'lhbList', params: { date: '2026-11-02', pageSize: 500 }, endpoint: 'GetStockList / LongHuBang', host: 'applhb', desc: 'Time=日期，Index 偏移，st 页大小。' },
        { name: '龙虎榜个股详情', action: 'lhbDetail', params: { code: '000678', date: '2026-11-02' }, endpoint: 'GetNewOneStockInfo / Stock', host: 'applhb', desc: '买卖席位、上榜原因、买卖总额。' },
        { name: '板块新闻', action: 'plateNews', params: { plateId: '801346', index: 0, pageSize: 30 }, endpoint: 'GetPlateNewsList / APPComplexData', host: 'apparticle', desc: 'Type=1 快讯，2 新闻。' },
        { name: 'ETF 排行', action: 'etfRanking', params: { date: '', order: 1, index: 0 }, endpoint: 'ETFStockRanking / NewStockRanking', host: 'apphwhq', desc: 'order=1 涨幅降序，2 涨幅升序。' },
        { name: '全部 ETF（组合）', action: 'allEtfRanking', params: { date: '', order: 1, maxPages: 30 }, endpoint: 'ETFStockRanking / NewStockRanking', host: 'apphwhq', desc: '自动翻页，最多 30 页。' },
        { name: '板块新闻多页（组合）', action: 'plateNewsAll', params: { plateId: '801346', maxPages: 3, pageSize: 30 }, endpoint: 'GetPlateNewsList / APPComplexData', host: 'apparticle', desc: '按 Index 偏移连续抓取多页。' },
        { name: '多空风向标', action: 'sentimentIndicator', params: { plateId: '801225' }, endpoint: 'PlateIntroduction_Info / ZhiShuRanking', host: 'apphwhq', desc: '返回前 3 多头、后 3 空头及全部样本代码；可传 stocks 自定义列表。' },
        { name: '同花顺热榜', action: 'thsHotRank', params: { type: 'hour', limit: 50 }, endpoint: 'dq.10jqka.com.cn 热榜', host: 'dq.10jqka.com.cn', desc: 'type=hour 小时热度，day 日热度。' }
      ]
    },
    {
      group: '调试 / 原始调用',
      items: [
        { name: '原始 KPL 调用', action: 'rawKpl', params: { host: 'his', params: { a: 'HisZhangFuDetail', c: 'HisHomeDingPan', Day: '2026-11-02' }, query: true }, endpoint: '任意 a/c', host: 'apphis / apphwhq / apparticle / applhb', desc: '直接 POST 任意表单参数，返回原始 JSON（含 errcode）。host: his/hq/article/lhb。' }
      ]
    },
    {
      group: '腾讯 K线 / 分时 / 行情（东方财富备用）',
      items: [
        { name: 'K线', action: 'kline', params: { secid: '1.600519', period: 'day', fq: 'qfq', bars: 120, end: '' }, endpoint: '/cgi/cgi-bin/stockinfoquery/kline/app/get', host: 'proxy.finance.qq.com', desc: '腾讯自选股网关，爱盯盘主源；ktype/limit/fqtype/toDate。period: 1m,5m,15m,30m,60m,120m,day,week,month,quarter(月线聚合),year。东财为备用。' },
        { name: '分时', action: 'trends', params: { secid: '1.600519', ndays: 1, date: '' }, endpoint: '/ifzqgtimg/appstock/app/minute/query', host: 'proxy.finance.qq.com', desc: '腾讯自选股网关实时分时；五日用 day/query；历史日期走 generalminute/history。东财为备用。' },
        { name: '实时快照', action: 'quote', params: { secid: '1.600519' }, endpoint: '/cgi/cgi-bin/stockinfoquery/kline/app/get', host: 'proxy.finance.qq.com', desc: '从腾讯 K 线响应的 qt.fields 读取实时快照；东财为备用。' },
        { name: '批量快照', action: 'quotes', params: { secids: ['1.600519', '0.000001'] }, endpoint: '/api/qt/ulist.np/get', host: 'push2.eastmoney.com', desc: '批量行情。' },
        { name: '证券搜索', action: 'search', params: { keyword: '贵州茅台' }, endpoint: '/api/suggest/get', host: 'searchapi.eastmoney.com', desc: '代码/名称联想。' },
        { name: '集合竞价逐笔', action: 'stockAuction', params: { code: '600519' }, endpoint: '/api/qt/stock/details/get', host: 'push2.eastmoney.com', desc: '仅保留 09:15–09:25 的逐笔。' }
      ]
    }
  ];

  function openCatalogEntry(entry) {
    const params = JSON.stringify(entry.params || {}, null, 2);
    K.openDrawer(entry.name, `${entry.host} · ${entry.endpoint}`, `
      <div class="catalog-desc">${K.esc(entry.desc || '')}</div>
      <label class="field-label">请求参数（JSON）</label>
      <textarea id="catalogParams" class="code-area" spellcheck="false">${K.esc(params)}</textarea>
      <div class="form-row"><button class="btn btn-primary" id="catalogRun">调用接口</button><span class="muted small">${K.esc(entry.endpoint)}</span></div>
      <pre id="catalogOut" class="code-output">点击“调用接口”查看调用结果 JSON。</pre>
    `);
    document.getElementById('catalogRun')?.addEventListener('click', async () => {
      const out = document.getElementById('catalogOut');
      let payload;
      try { payload = JSON.parse(document.getElementById('catalogParams').value || '{}'); }
      catch (err) { out.textContent = `JSON 解析失败：${err.message}`; return; }
      out.textContent = '请求中…';
      try {
        const data = await K.api(entry.action, payload);
        out.textContent = JSON.stringify(data, null, 2);
      } catch (err) {
        out.textContent = `调用失败：${err.message}`;
      }
    });
  }

  V.catalog = async function () {
    K.setPage('接口目录', '开盘啦 30 个原始接口 + 东方财富 K线/分时/行情，均可直接调用', 'KAI PAN LA · API CATALOG');
    let idx = 0;
    const groups = CATALOG.map(group => {
      const rows = group.items.map(item => {
        const row = { ...item, index: idx++ };
        return `<tr>
          <td><b>${K.esc(item.name)}</b><div class="muted small">${K.esc(item.desc || '')}</div></td>
          <td><span class="mono small">${K.esc(item.endpoint)}</span><div class="muted small">${K.esc(item.host)}</div></td>
          <td><span class="mono small">${K.esc(JSON.stringify(item.params || {}))}</span></td>
          <td class="right"><button class="btn btn-sm" data-catalog="${row.index}">调用</button></td>
        </tr>`;
      }).join('');
      return `<section class="panel"><header class="panel-head"><div><h2>${K.esc(group.group)}</h2></div></header><div class="panel-body">
        <div class="table-wrap"><table class="data-table catalog-table"><thead><tr><th>功能</th><th>接口 / 域名</th><th>默认参数</th><th class="right">操作</th></tr></thead><tbody>${rows}</tbody></table></div>
      </div></section>`;
    }).join('');
    const flat = CATALOG.flatMap(g => g.items);
    K.render(`
      <div class="callout">
        <b>全部接口可调用。</b> 本页列出源码中的 30 个开盘啦 a/c 接口、组合方法和东方财富 K线/分时/行情接口。点击“调用”可编辑参数并查看调用结果 JSON。
        日期参数统一使用 <span class="mono">YYYY-MM-DD</span>；实时接口传空字符串或省略。
      </div>
      ${groups}
    `);
    document.querySelectorAll('[data-catalog]').forEach(btn => btn.addEventListener('click', () => {
      const entry = flat[Number(btn.getAttribute('data-catalog'))];
      if (entry) openCatalogEntry(entry);
    }));
  };
})();
