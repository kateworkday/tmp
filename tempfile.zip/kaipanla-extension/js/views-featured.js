/* 开盘啦盯盘助手 - 精选板块 / 人气排行榜 */
(function () {
  'use strict';

  const V = window.Views = window.Views || {};
  const today = () => K.todayStr();
  const currentDate = () => K.state.date || today();

  function sum(items, key) {
    return items.reduce((s, x) => s + (Number(x[key]) || 0), 0);
  }

  function pctClass(v) { return K.pctClass(v); }

  V.featured = async function () {
    const vs = K.state.viewState.featured = K.state.viewState.featured || { zsType: '7', all: false };
    if (!['7', '4', '6'].includes(String(vs.zsType))) vs.zsType = '7';
    K.setPage('精选板块', '开盘啦精选板块 · 行业板块 / 地区板块排行', 'KAI PAN LA · FEATURED SECTORS');
    K.render(K.loading('正在加载开盘啦精选板块…'));
    const d = currentDate();
    const res = await K.apiSafe('featuredSectors', { date: d, zsType: vs.zsType, all: vs.all });
    if (!res.ok) {
      K.render(`<div class="toolbar">${K.tabs([
        { id: '7', label: '精选板块' }, { id: '4', label: '行业板块' }, { id: '6', label: '地区板块' }
      ], vs.zsType, 'data-zs')}</div>${K.errorBox(new Error(res.error), '精选板块加载失败')}`);
      bindFeatured(vs);
      return;
    }
    const data = res.data;
    const items = data.items || [];
    const empty = !items.length;
    const note = data.isFallback
      ? `盘前资金数据尚未生成，已自动展示 ${data.date} 的精选板块；开盘后刷新即可切换当日数据。`
      : data.preMarket
        ? '当前为盘前快照，资金数据可能尚未生成，开盘后刷新即可看到完整数据。'
        : '';
    const sub = data.subSectors || [];
    const subCards = sub.map(x => `
      <button class="subsector-chip" data-sector="${K.escAttr(x.code)}" data-sector-name="${K.escAttr(x.name)}" data-sector-mode="stocks">
        <b>${K.esc(x.name)}</b>
        <span class="${pctClass(x.changePct)}">${K.fmtPct(x.changePct)}</span>
        <em>强度 ${K.fmtNum(x.strength, 2)}</em>
      </button>`).join('');

    K.render(`
      <div class="toolbar">
        ${K.tabs([{ id: '7', label: '精选板块' }, { id: '4', label: '行业板块' }, { id: '6', label: '地区板块' }], data.zsType, 'data-zs')}
        <div class="toolbar-right">
          ${data.isFallback ? '<span class="tag tag-blue">盘前参考上一交易日</span>' : ''}
          <span class="muted small">${K.esc(data.date)} · ${K.esc(data.time || '')} · 共 ${K.fmtInt(data.count)} 个板块</span>
          <button class="btn btn-ghost" data-goto="mainline">主线追踪</button>
          <button class="btn btn-primary" id="featuredAll" ${vs.all ? 'disabled' : ''}>加载全部</button>
        </div>
      </div>
      ${note ? `<div class="callout">${K.esc(note)}</div>` : ''}
      ${K.section('板块排行', `${data.zsName} · 点击板块查看成分股（默认按涨幅排序）`, K.table([
        { key: 'rank', label: '#', width: '46px', render: (r, i) => `<span class="rank-num">${i + 1}</span>` },
        { key: 'name', label: '板块', render: r => `<button class="link-btn strong" data-sector="${K.escAttr(r.code)}" data-sector-name="${K.escAttr(r.name)}" data-sector-mode="stocks">${K.esc(r.name)}</button><span class="muted mono small"> ${K.esc(r.code)}</span>` },
        { key: 'strength', label: '强度', align: 'right', render: r => `<span class="num">${K.fmtNum(r.strength, 2)}</span>` },
        { key: 'changePct', label: '涨跌幅', align: 'right', render: r => K.pctCell(r.changePct) },
        { key: 'changeSpeed', label: '涨速', align: 'right', render: r => K.pctCell(r.changeSpeed) },
        { key: 'netInflow', label: '主力净额', align: 'right', render: r => K.moneyCell(r.netInflow) },
        { key: 'mainBuy', label: '主买', align: 'right', render: r => K.bigCell(r.mainBuy) },
        { key: 'mainSell', label: '主卖', align: 'right', render: r => K.bigCell(r.mainSell) },
        { key: 'amount', label: '成交额', align: 'right', render: r => K.bigCell(r.amount) },
        { key: 'volumeRatio', label: '量比', align: 'right', render: r => `<span class="num">${K.fmtNum(r.volumeRatio, 2)}</span>` },
        { key: 'floatCap', label: '流通市值', align: 'right', render: r => K.bigCell(r.floatCap) },
        { key: 'totalCap', label: '总市值', align: 'right', render: r => K.bigCell(r.totalCap) }
      ], items, { rowClass: () => 'row-clickable', emptyText: empty ? '盘前暂无精选板块数据' : '暂无精选板块数据' }))}
      ${sub.length ? K.section('细分板块', '精选板块下的细分方向', `<div class="subsector-grid">${subCards}</div>`) : ''}
    `);
    bindFeatured(vs);
    document.getElementById('featuredAll')?.addEventListener('click', () => { vs.all = true; V.featured(); });
    K.bindRows(document.getElementById('content'), items, row => K.openSectorStocks(row.code, row.name));
    bindCommon();
  };

  function bindFeatured(vs) {
    const tabs = document.querySelectorAll('#content [data-zs]');
    tabs.forEach(btn => {
      if (btn.dataset.boundZs) return;
      btn.dataset.boundZs = '1';
      btn.addEventListener('click', () => {
        vs.zsType = btn.getAttribute('data-zs');
        vs.all = false;
        V.featured();
      });
    });
    bindCommon();
  }

  V.mainline = async function () {
    const vs = K.state.viewState.mainline = K.state.viewState.mainline || {
      days: 10, topN: 10, selectedCode: ''
    };
    if (!Number.isFinite(Number(vs.days))) vs.days = 10;
    if (!Number.isFinite(Number(vs.topN))) vs.topN = 10;
    if (!vs.selectedCode) vs.selectedCode = '';
    K.setPage('主线追踪', '最近两周精选板块强度矩阵 · 点击板块跨日高亮', 'KAI PAN LA · MAINLINE TRACKER');
    K.render(K.loading('正在汇总最近两周精选板块强度…'));
    const d = currentDate();
    const res = await K.apiSafe('sectorMainline', { date: d, days: vs.days, topN: vs.topN });
    if (!res.ok) {
      K.render(`${K.errorBox(new Error(res.error), '主线追踪加载失败')}`);
      return;
    }
    const data = res.data || {};
    const days = [...(data.days || [])].sort((a, b) => String(b.date || '').localeCompare(String(a.date || '')));
    const mainlines = data.mainlines || [];
    const selected = mainlines.find(x => x.code === vs.selectedCode) || null;
    const weekdayName = date => ['周日', '周一', '周二', '周三', '周四', '周五', '周六'][new Date(`${date}T12:00:00`).getDay()] || '';
    const matrix = days.map((day, index) => `
      <div class="mainline-col ${index === 0 ? 'latest' : ''}">
        <div class="mainline-col-head">
          <b>${K.esc(String(day.date || '').slice(5))}</b>
          <span>${K.esc(weekdayName(day.date))}${index === 0 ? ' · 最新' : ''}</span>
        </div>
        <div class="mainline-cells">
          ${day.rows.length ? day.rows.map(row => `
            <button type="button" class="mainline-cell ${vs.selectedCode === row.code ? 'selected' : ''}" data-mainline-code="${K.escAttr(row.code)}" data-mainline-name="${K.escAttr(row.name)}" title="${K.escAttr(`${row.name} · ${day.date} · 强度 ${K.fmtNum(row.strength, 0)}`)}">
              <span class="mainline-cell-head"><span class="mainline-rank">${row.rank}</span><b class="mainline-name">${K.esc(row.name)}</b></span>
              <span class="mainline-cell-meta"><span>强度 ${K.fmtNum(row.strength, 0)}</span><span class="${K.pctClass(row.changePct)}">${K.fmtPct(row.changePct)}</span></span>
            </button>`).join('') : '<div class="mainline-empty">暂无数据</div>'}
        </div>
      </div>`).join('');
    const candidateRows = mainlines.slice(0, 10).map((m, i) => `
      <button type="button" class="mainline-candidate ${vs.selectedCode === m.code ? 'selected' : ''}" data-mainline-code="${K.escAttr(m.code)}" data-mainline-name="${K.escAttr(m.name)}">
        <span class="mainline-candidate-rank">${i + 1}</span>
        <span class="mainline-candidate-name">${K.esc(m.name)}</span>
        <span class="mainline-candidate-meta">${m.appearDays}/${days.length} 天 · 平均强度 ${K.fmtNum(m.avgStrength, 0)} · 最佳 #${m.bestRank == null ? '-' : m.bestRank}</span>
      </button>`).join('');
    const top = mainlines[0];
    const latestDay = days[0] || null;
    const oldestDay = days[days.length - 1] || null;
    const latestTop = latestDay && latestDay.rows.length ? latestDay.rows[0] : null;
    K.render(`
      <div class="toolbar">
        <div class="form-row">
          <span class="tag tag-blue">${K.esc(data.zsName || '精选板块')}</span>
          <span class="muted small">最近 ${K.fmtInt(days.length)} 个交易日 · 每日强度 Top ${K.fmtInt(data.topN)}</span>
        </div>
        <div class="toolbar-right">
          <span class="muted small">${K.esc(oldestDay?.date || '')}${days.length > 1 ? ` ~ ${K.esc(latestDay.date)}` : ''} · 最新在左</span>
          <button class="btn" id="mainlineRefresh">刷新</button>
        </div>
      </div>
      ${K.statsGrid([
        { label: '覆盖交易日', value: K.fmtInt(days.length), sub: '按精选板块强度汇总', cls: 'flat' },
        { label: '候选主线', value: K.fmtInt(mainlines.length), sub: '至少进入一次每日 Top', cls: top ? 'up' : 'flat' },
        { label: '最强主线', value: top ? top.name : '-', sub: top ? `${top.appearDays}/${days.length} 天 · 平均强度 ${K.fmtNum(top.avgStrength, 0)}` : '暂无数据', cls: top ? 'up' : 'flat' },
        { label: '最新榜首', value: latestTop ? latestTop.name : '-', sub: latestDay ? `${latestDay.date} · 强度 ${K.fmtNum(latestTop?.strength, 0)}` : '暂无数据', cls: latestTop ? 'up' : 'flat' }
      ])}
      <div class="callout" id="mainlineSelectionNote">${selected ? `已选 <b>${K.esc(selected.name)}</b> · 出现 ${selected.appearDays}/${days.length} 天 · 平均强度 ${K.fmtNum(selected.avgStrength, 0)}；再次点击取消高亮。` : '点击任意板块，同一板块会在所有日期列中高亮；选择主线候选也会同步联动。'}</div>
      ${K.section('精选板块强度矩阵', '左侧为最新日期，每天一列，按强度从高到低；点击板块跨日联动', days.length ? `<div class="mainline-matrix ${vs.selectedCode ? 'has-selection' : ''}" id="mainlineMatrix">${matrix}</div>` : K.empty('最近两周没有可用的精选板块数据'), '<span class="tag tag-blue">强度排序</span>')}
      ${K.section('主线候选', '按出现天数、平均强度、最佳排名综合排序', candidateRows ? `<div class="mainline-candidates">${candidateRows}</div>` : K.empty('暂无主线候选'))}
      <div class="muted small">说明：候选主线不是预测，只统计最近 ${K.fmtInt(days.length)} 个交易日内进入每日强度 Top ${K.fmtInt(data.topN)} 的频次与强度；数据来自开盘啦精选板块。</div>
    `);
    bindCommon();
    document.getElementById('mainlineRefresh')?.addEventListener('click', () => V.mainline());
    const applySelection = code => {
      const matrix = document.getElementById('mainlineMatrix');
      if (matrix) matrix.classList.toggle('has-selection', !!code);
      document.querySelectorAll('#content [data-mainline-code]').forEach(el => {
        el.classList.toggle('selected', el.getAttribute('data-mainline-code') === code);
      });
      const item = mainlines.find(x => x.code === code);
      const note = document.getElementById('mainlineSelectionNote');
      if (note) {
        note.innerHTML = item
          ? `已选 <b>${K.esc(item.name)}</b> · 出现 ${item.appearDays}/${days.length} 天 · 平均强度 ${K.fmtNum(item.avgStrength, 0)}；再次点击取消高亮。`
          : '点击任意板块，同一板块会在所有日期列中高亮；选择主线候选也会同步联动。';
      }
    };
    document.querySelectorAll('#content [data-mainline-code]').forEach(el => {
      el.addEventListener('click', () => {
        const code = el.getAttribute('data-mainline-code');
        vs.selectedCode = vs.selectedCode === code ? '' : code;
        applySelection(vs.selectedCode);
      });
    });
    applySelection(vs.selectedCode);
  };

  V.sectorStocks = async function () {
    const vs = K.state.viewState.sectorStocks = K.state.viewState.sectorStocks || {
      code: K.state.prefs.sectorCode || '801004',
      name: K.state.prefs.sectorName || '',
      mode: 'realtime', sort: 'change', tag: '',
      extraCols: { ...(K.state.prefs.sectorStockCols || {}) }
    };
    if (!vs.code) vs.code = '801004';
    if (!['realtime', 'history'].includes(vs.mode)) vs.mode = 'realtime';
    if (!['change', 'hot', 'tag'].includes(vs.sort)) vs.sort = 'change';
    if (!vs.tag) vs.tag = '';
    if (!vs.extraCols || typeof vs.extraCols !== 'object') vs.extraCols = { ...(K.state.prefs.sectorStockCols || {}) };
    const name = vs.name || K.state.prefs.sectorName || vs.code;
    const pageMode = vs.sort === 'hot' ? '板块成分股 · 按人气排名' : vs.sort === 'tag' ? '板块成分股 · 按开盘啦标签排序' : '板块成分股 · 按涨幅排序';
    K.setPage(`${name} · 个股`, pageMode, 'SECTOR STOCKS');
    K.render(K.loading('正在加载板块成分股、人气榜与板块标签…'));
    const d = currentDate();
    const queryDate = vs.mode === 'history' ? d : '';
    const tag = vs.sort === 'tag' ? vs.tag : '';
    const res = await K.apiSafe('sectorHotStocks', { code: vs.code, date: queryDate, tag });
    const back = `<button class="btn btn-ghost" data-goto="featured">← 返回精选板块</button>`;
    if (!res.ok) {
      K.render(`<div class="toolbar"><div class="form-row">${back}</div></div>${K.errorBox(new Error(res.error), '板块个股加载失败')}`);
      bindCommon();
      return;
    }
    const data = res.data;
    const rawItems = data.stocks || [];
    const items = [...rawItems];
    if (vs.sort === 'hot') {
      items.sort((a, b) => {
        const ar = a.hotRank == null ? Number.MAX_SAFE_INTEGER : a.hotRank;
        const br = b.hotRank == null ? Number.MAX_SAFE_INTEGER : b.hotRank;
        if (ar !== br) return ar - br;
        return (Number(b.changePct) || 0) - (Number(a.changePct) || 0);
      });
    } else if (!tag) {
      items.sort((a, b) => (Number(b.changePct) || 0) - (Number(a.changePct) || 0));
    }
    const tags = data.tags || [];
    const tagName = tags.find(x => x.id === vs.tag)?.name || '';
    const subSectors = data.subSectors || [];
    const hotItems = items.filter(x => x.hotRank != null);
    const topChange = [...rawItems].sort((a, b) => (Number(b.changePct) || 0) - (Number(a.changePct) || 0))[0];
    const avg = items.length ? sum(items, 'changePct') / items.length : 0;
    const rawUpdateTime = String(data.constituentTime || '');
    const updateTime = /^\d{4}$/.test(rawUpdateTime) ? `${rawUpdateTime.slice(0, 2)}:${rawUpdateTime.slice(2)}` : rawUpdateTime;
    const fallbackNote = data.constituentFallback
      ? `今日成分股接口盘中未更新，当前使用最近交易日 ${data.constituentDate} 的成分股列表。`
      : '';
    const hotNote = !data.hotAvailable
      ? '开盘啦人气榜暂不可用，当前按涨跌幅排序。'
      : `人气排名来自开盘啦人气榜 Top 50（${data.hotDate || d}），未上榜个股按涨跌幅排序。`;
    const tagNote = tags.length
      ? `标签来自 GetGPCPHBTS_Tag；选择标签后按开盘啦标签顺序展示，标签接口不可用时仍可按涨幅或人气排序。`
      : '';
    const popularityNote = '人气值来自成分股接口 list[58]，人气变化为 list[59]；人气排名/榜单变化仍来自 Top 50 人气榜。';
    const sortTabs = [{ id: 'change', label: '涨幅排序' }, { id: 'hot', label: '人气排序' }];
    if (tags.length) sortTabs.push({ id: 'tag', label: '标签排序' });
    const listMode = vs.sort === 'hot'
      ? '按人气排名优先，未上榜按涨幅排序'
      : vs.sort === 'tag'
        ? `按开盘啦标签「${tagName || '请选择'}」排序`
        : '按今日涨幅从高到低';

    const defaultStockColumns = [
      { key: 'hotRank', label: '人气排名', width: '64px', render: r => r.hotRank != null ? `<span class="rank-num">#${r.hotRank}</span>` : '<span class="muted">未上榜</span>' },
      { key: 'name', label: '股票', width: '140px', render: r => `<button class="link-btn strong" data-code="${K.escAttr(r.code)}" title="${K.escAttr(`${r.name} ${r.code}`)}">${K.esc(r.name)}</button><span class="muted mono small"> ${K.esc(r.code)}</span>` },
      { key: 'popularity', label: '人气值', width: '78px', align: 'right', render: r => {
        if (!r.popularity) return '<span class="muted">-</span>';
        const delta = Number(r.popularityChange) || 0;
        const deltaHtml = delta ? `<span class="pop-delta ${delta > 0 ? 'up' : delta < 0 ? 'down' : 'flat'}">${delta > 0 ? '+' : ''}${K.fmtInt(delta)}</span>` : '';
        return `<span class="num" title="list[58] 人气值 / list[59] 人气变化">${K.fmtInt(r.popularity)}</span>${deltaHtml}`;
      } },
      { key: 'changePct', label: '涨跌幅', width: '68px', align: 'right', render: r => K.pctCell(r.changePct) },
      { key: 'actualTurnover', label: '实际换手率', width: '78px', align: 'right', render: r => K.fmtRate(r.actualTurnover) },
      { key: 'turnover', label: '成交额', width: '82px', align: 'right', render: r => K.bigCell(r.turnover) },
      { key: 'mainNet', label: '主力净额', width: '82px', align: 'right', render: r => K.moneyCell(r.mainNet) },
      { key: 'netRatio', label: '净额占比', width: '70px', align: 'right', render: r => K.pctCell(r.netRatio) },
      { key: 'boardText', label: '连板标签', width: '130px', align: 'center', render: r => [r.boardText, r.leader].filter(Boolean).map(x => `<span class="tag ${/龙/.test(x) ? 'tag-red' : ''}">${K.esc(x)}</span>`).join(' ') || '-' }
    ];
    const optionalStockColumns = [
      { key: 'price', label: '最新价', width: '68px', align: 'right', render: r => `<span class="num">${K.fmtPrice(r.price)}</span>` },
      { key: 'turnoverRate', label: '换手率', width: '64px', align: 'right', render: r => K.fmtRate(r.turnoverRate) },
      { key: 'volumeRatio', label: '量比', width: '54px', align: 'right', render: r => `<span class="num">${K.fmtNum(r.volumeRatio, 2)}</span>` },
      { key: 'limitCount', label: '近期涨停', width: '64px', align: 'right', render: r => K.fmtInt(r.limitCount) },
      { key: 'recentChange', label: '近期涨幅', width: '68px', align: 'right', render: r => K.pctCell(r.recentChange) },
      { key: 'floatCap', label: '流通市值', width: '78px', align: 'right', render: r => K.bigCell(r.floatCap) },
      { key: 'hotRankChange', label: '榜单变化', width: '88px', align: 'right', render: r => {
        if (r.hotRank == null) return '<span class="muted">-</span>';
        const parts = [];
        if (r.isNewHot) parts.push('<span class="tag tag-red">新进</span>');
        if (r.hotRankChange != null) parts.push(`<span class="num ${r.hotRankChange > 0 ? 'up' : r.hotRankChange < 0 ? 'down' : 'flat'}">${r.hotRankChange > 0 ? '+' : ''}${K.fmtInt(r.hotRankChange)}</span>`);
        return parts.join(' ') || '<span class="muted">-</span>';
      } }
    ];
    const extraCols = vs.extraCols || {};
    const visibleStockColumns = [...defaultStockColumns, ...optionalStockColumns.filter(c => !!extraCols[c.key])];
    const stockTableMinWidth = visibleStockColumns.reduce((sum, c) => sum + (parseInt(c.width, 10) || 80), 0);

    K.render(`
      <div class="toolbar">
        <div class="form-row">
          ${back}
          <span class="tag tag-blue">${K.esc(name)}</span>
          <span class="tag tag-red">强度 ${data.sectorStrength == null ? '-' : K.fmtNum(data.sectorStrength, 2)}</span>
          <span class="muted mono small">${K.esc(vs.code)}</span>
        </div>
        <div class="toolbar-right">
          <span class="muted small">成分股 ${data.constituentDate}${updateTime ? ` 更新至 ${updateTime}` : ''} · 人气榜 ${data.hotDate || d}</span>
          ${K.tabs([{ id: 'realtime', label: '实时' }, { id: 'history', label: '历史' }], vs.mode, 'data-stock-mode')}
          ${K.tabs(sortTabs, vs.sort, 'data-stock-sort')}
          ${tags.length ? `<label class="inline-field"><span>标签</span><select id="sectorTag">
            <option value="">默认</option>
            ${tags.map(t => `<option value="${K.escAttr(t.id)}" ${vs.tag === t.id ? 'selected' : ''}>${K.esc(t.name)}</option>`).join('')}
          </select></label>` : ''}
          <button class="btn btn-ghost" id="sectorFieldsHelp">字段说明</button>
          <button class="btn" data-sector="${K.escAttr(vs.code)}" data-sector-name="${K.escAttr(name)}">板块行情</button>
        </div>
      </div>
      ${K.statsGrid([
        { label: '板块强度', value: data.sectorStrength == null ? '-' : K.fmtNum(data.sectorStrength, 2), sub: `开盘啦强度 · ${data.strengthDate || data.constituentDate}`, cls: data.sectorStrength >= 0 ? 'up' : 'down' },
        { label: '成分股', value: K.fmtInt(data.total), sub: `已加载 ${items.length} 只`, cls: '' },
        { label: '人气上榜', value: K.fmtInt(data.hotCount), sub: `Top 50 · ${data.hotDate || d}`, cls: 'up' },
        { label: '涨幅第一', value: topChange ? topChange.name : '-', sub: topChange ? K.fmtPct(topChange.changePct) : '暂无数据', cls: topChange ? pctClass(topChange.changePct) : 'flat' },
        { label: '平均涨幅', value: K.fmtPct(avg), sub: '板块成分股均值', cls: pctClass(avg) }
      ])}
      <div class="callout">${K.esc(hotNote)} ${K.esc(popularityNote)}${tagNote ? ' ' + K.esc(tagNote) : ''}${fallbackNote ? ' ' + K.esc(fallbackNote) : ''}</div>
      ${subSectors.length ? K.section('细分板块', '开盘啦 SonPlate_Info · 点击切换到细分板块', `<div class="subsector-grid">${subSectors.map(x => `
        <button class="subsector-chip" data-sector="${K.escAttr(x.code)}" data-sector-name="${K.escAttr(x.name)}" data-sector-mode="stocks">
          <b>${K.esc(x.name)}</b>
          <em>强度 ${K.fmtNum(x.strength, 2)}</em>
        </button>`).join('')}</div>`) : ''}
      <div class="stock-column-picker">
        <span class="stock-column-picker-label">显示更多列</span>
        ${optionalStockColumns.map(c => `<label class="stock-column-toggle ${extraCols[c.key] ? 'active' : ''}">
          <input type="checkbox" data-extra-col="${K.escAttr(c.key)}" ${extraCols[c.key] ? 'checked' : ''}>
          <span>${K.esc(c.label)}</span>
        </label>`).join('')}
      </div>
      ${K.section('板块成分股', `${listMode}；点击个股查看行情`, K.table(visibleStockColumns, items, { tableClass: 'sector-stock-table', minWidth: stockTableMinWidth, rowClass: r => r.hot ? 'row-hot' : '', emptyText: '该板块暂无成分股数据' }))}
    `);
    bindCommon();
    K.bindRows(document.getElementById('content'), items, row => K.openStock(row.code, row.name));
    document.querySelectorAll('[data-stock-mode]').forEach(btn => btn.addEventListener('click', () => {
      vs.mode = btn.getAttribute('data-stock-mode');
      V.sectorStocks();
    }));
    document.querySelectorAll('[data-stock-sort]').forEach(btn => btn.addEventListener('click', () => {
      const sort = btn.getAttribute('data-stock-sort');
      if (sort === 'tag') {
        if (!vs.tag && tags.length) vs.tag = tags[0].id;
      } else {
        vs.tag = '';
      }
      vs.sort = sort;
      V.sectorStocks();
    }));
    document.getElementById('sectorTag')?.addEventListener('change', e => {
      vs.tag = e.target.value;
      vs.sort = vs.tag ? 'tag' : 'change';
      V.sectorStocks();
    });
    document.querySelectorAll('[data-extra-col]').forEach(input => input.addEventListener('change', () => {
      const key = input.getAttribute('data-extra-col');
      vs.extraCols = { ...(vs.extraCols || {}), [key]: input.checked };
      K.state.prefs.sectorStockCols = { ...vs.extraCols };
      K.savePrefs();
      V.sectorStocks();
    }));
    document.getElementById('sectorFieldsHelp')?.addEventListener('click', () => openSectorFieldsHelp());
  };

  function openSectorFieldsHelp() {
    const sectorRows = [
      ['板块代码', 'list[0]', '如 801004'],
      ['板块名称', 'list[1]', '如 锂电池'],
      ['强度', 'list[2]', '开盘啦板块强度指标，如 5568'],
      ['涨跌幅', 'list[3]', '百分比'],
      ['涨速', 'list[4]', '百分比'],
      ['成交额', 'list[5]', '元'],
      ['主力净额', 'list[6]', '元'],
      ['主买 / 主卖', 'list[7] / list[8]', '元'],
      ['量比', 'list[9]', ''],
      ['流通市值', 'list[10]', '元'],
      ['平均涨幅', 'list[11]', '百分比'],
      ['300万大单净额', 'list[12]', '元'],
      ['总市值', 'list[13]', '元'],
      ['机构增仓', 'list[14]', '元'],
      ['今PE / 明PE', 'list[15] / list[16]', ''],
      ['强度2 / 涨幅2', 'list[17] / list[18]', '接口重复字段']
    ];
    const stockRows = [
      ['股票代码 / 名称', 'list[0] / list[1]', ''],
      ['概念标签', 'list[4]', '如 固态电池、算力'],
      ['现价 / 涨跌幅', 'list[5] / list[6]', ''],
      ['成交额', 'list[7]', '元'],
      ['换手率', 'list[8]', '百分比'],
      ['流通市值', 'list[10]', '元'],
      ['主力买入 / 卖出 / 净额', 'list[11] / list[12] / list[13]', '元'],
      ['主买占比 / 主卖占比 / 净额占比', 'list[14] / list[15] / list[16]', '百分比'],
      ['量比', 'list[21]', ''],
      ['连板标签 / 龙头标签', 'list[23] / list[24]', '如 首板 / 龙一'],
      ['近期涨幅', 'list[33]', '百分比'],
      ['近期涨停次数', 'list[40]', '次'],
      ['实际换手率', 'list[53]', '百分比'],
      ['人气值 / 人气排名变化', 'list[58] / list[59]', '覆盖全部成分股；与 Top 50 人气榜不同']
    ];
    K.openDrawer('板块与个股字段说明', '开盘啦精选板块 / 成分股接口字段', `
      <div class="callout"><b>强度</b>是板块级指标（精选板块 list[2]），不是单只个股字段；个股接口中没有独立的“个股强度”字段。</div>
      ${K.section('精选板块字段', 'RealRankingInfo / ZhiShuRanking', K.table([
        { key: 'name', label: '字段' }, { key: 'index', label: '数组位置' }, { key: 'note', label: '说明' }
      ], sectorRows.map(([name, index, note]) => ({ name, index, note }))))}
      ${K.section('板块个股字段', 'ZhiShuStockList_W8 / ZhiShuRanking', K.table([
        { key: 'name', label: '字段' }, { key: 'index', label: '数组位置' }, { key: 'note', label: '说明' }
      ], stockRows.map(([name, index, note]) => ({ name, index, note }))))}
      <div class="muted small">字段含义基于接口实测与开源整理；部分未知字段未在界面展示。</div>
    `);
  }

  V.hot = async function () {
    const vs = K.state.viewState.hot = K.state.viewState.hot || { tab: 'kpl1' };
    if (!['kpl1', 'kpl2', 'ths_hour', 'ths_day'].includes(vs.tab)) vs.tab = 'kpl1';
    K.setPage('人气排行榜', '开盘啦人气榜 / 最强风口 / 同花顺热榜', 'POPULARITY RANKING');
    K.render(K.loading('正在加载人气排行榜…'));
    const tab = vs.tab || 'kpl1';
    const isKpl = tab === 'kpl1' || tab === 'kpl2';
    const isKplType2 = tab === 'kpl2';
    const isThs = !isKpl;
    let res;
    if (isKpl) {
      res = await K.apiSafe('kplHotRank', { type: isKplType2 ? '2' : '1', limit: 50 });
    } else {
      res = await K.apiSafe('thsHotRank', { type: tab === 'ths_day' ? 'day' : 'hour', limit: 50 });
    }
    if (isKpl && (!res.ok || !((res.data && res.data.items) || []).length)) {
      const fallback = await K.apiSafe('thsHotRank', { type: 'hour', limit: 50 });
      if (fallback.ok && ((fallback.data && fallback.data.items) || []).length) {
        vs.tab = 'ths_hour';
        K.toast('开盘啦人气榜暂不可用，已切换同花顺热榜', 'info', 2600);
        return V.hot();
      }
    }
    if (!res.ok) {
      K.render(`<div class="toolbar">${K.tabs([
        { id: 'kpl1', label: '开盘啦人气榜' },
        { id: 'kpl2', label: '最强风口' },
        { id: 'ths_hour', label: '同花顺小时榜' },
        { id: 'ths_day', label: '同花顺日榜' }
      ], tab, 'data-hot-tab')}</div>${K.errorBox(new Error(res.error), '人气排行榜加载失败')}`);
      bindHot(vs);
      return;
    }
    const data = res.data;
    const items = (data.items || []).map((x, i) => ({
      ...x,
      listIndex: i + 1,
      rank: isThs ? (x.order || i + 1) : (isKplType2 ? (x.rank || i + 1) : (x.rank || i + 1)),
      rankChange: x.rankChange,
      heat: isThs ? Number(x.rate) : x.heat
    }));
    const sourceName = isThs ? '同花顺热榜' : isKplType2 ? '开盘啦最强风口' : '开盘啦人气榜';

    const columns = [
      { key: 'rank', label: isKplType2 ? '榜内序' : '#', width: '62px', render: r => `<span class="rank-num">${isKplType2 ? r.listIndex : r.rank}</span>` },
      { key: 'name', label: '股票', render: r => `<button class="link-btn strong" data-code="${K.escAttr(r.code)}">${K.esc(r.name)}</button><span class="muted mono small"> ${K.esc(r.code)}</span><span class="hot-desc" data-hot-desc="${K.escAttr(r.code)}"></span><span class="hot-reason" data-hot-reason="${K.escAttr(r.code)}"></span>` },
      { key: 'changePct', label: '涨跌幅', align: 'right', render: r => K.pctCell(r.changePct) }
    ];
    if (isKplType2 || isThs) {
      columns.push({ key: 'heat', label: isKplType2 ? '热度值' : '热度值', align: 'right', render: r => `<span class="num">${K.fmtBig(r.heat)}</span>` });
    }
    if (!isKplType2) {
      columns.push({ key: 'rankChange', label: '排名变化', align: 'right', render: r => `<span class="num ${r.rankChange > 0 ? 'up' : r.rankChange < 0 ? 'down' : 'flat'}">${r.rankChange > 0 ? '+' : ''}${K.fmtInt(r.rankChange)}</span>` });
    }
    if (isThs) {
      columns.push({ key: 'popularity', label: '人气标签', align: 'center', render: r => r.popularity ? `<span class="tag tag-red">${K.esc(r.popularity)}</span>` : '-' });
      columns.push({ key: 'concepts', label: '概念', render: r => (r.concepts || []).slice(0, 4).map(c => `<span class="tag tag-blue">${K.esc(c)}</span>`).join(' ') || '-' });
    } else {
      columns.push({ key: 'isNew', label: '新进', align: 'center', render: r => r.isNew ? '<span class="tag tag-red">新进</span>' : '<span class="muted">-</span>' });
      if (isKplType2) columns.push({ key: 'rank', label: '人气榜排名', align: 'right', render: r => `<span class="num">${K.fmtInt(r.rank)}</span>` });
    }

    K.render(`
      <div class="toolbar">
        ${K.tabs([
          { id: 'kpl1', label: '开盘啦人气榜' },
          { id: 'kpl2', label: '最强风口' },
          { id: 'ths_hour', label: '同花顺小时榜' },
          { id: 'ths_day', label: '同花顺日榜' }
        ], tab, 'data-hot-tab')}
        <div class="toolbar-right"><span class="muted small">${K.esc(data.date || '')} · ${K.esc(data.time || '')} · ${K.esc(sourceName)}</span></div>
      </div>
      ${K.section('完整榜单', isThs ? '点击个股进入行情详情' : '开盘啦盘中实时榜，最多 50 名', K.table(columns, items, { emptyText: '暂无人气榜数据' }))}
      <div class="callout">开盘啦人气榜为盘中实时榜（最多 50 名）；「最强风口」按热度值展示；同花顺小时榜/日榜作为补充。点击股票可查看分时、K 线、主力大单等详情。</div>
    `);
    bindHot(vs);
    bindCommon();
    if (!isThs) {
      loadHotDescriptions(items, tab);
      loadHotReasons(items, tab, data.date || today());
    }
  };

  async function loadHotDescriptions(items, tab) {
    const codes = [...new Set((items || []).map(x => x.code).filter(Boolean))];
    if (!codes.length) return;
    const res = await K.apiSafe('stockConcepts', { codes });
    if (!res.ok || K.state.route !== 'hot' || (K.state.viewState.hot && K.state.viewState.hot.tab) !== tab) return;
    const map = new Map((res.data.items || []).map(x => [x.code, x]));
    document.querySelectorAll('[data-hot-desc]').forEach(el => {
      const item = map.get(el.getAttribute('data-hot-desc'));
      const concepts = item && item.concepts ? item.concepts : [];
      if (!concepts.length) return;
      el.textContent = `概念：${concepts.slice(0, 4).map(x => x.name).join(' · ')}${concepts.length > 4 ? ' …' : ''}`;
      el.title = concepts.map(x => x.name).join('、');
      el.classList.add('loaded');
    });
  }

  function hotLimitPct(item) {
    const code = String(item.code || '');
    const name = String(item.name || '');
    if (/ST/i.test(name)) return 5;
    if (/^(300|301|688|689)/.test(code)) return 20;
    if (/^(4|8|92)/.test(code)) return 30;
    return 10;
  }

  function isLimitUpItem(item) {
    const pct = Number(item.changePct);
    return Number.isFinite(pct) && pct >= hotLimitPct(item) - 0.15;
  }

  async function loadHotReasons(items, tab, hotDate) {
    const targets = (items || []).filter(isLimitUpItem).map(x => x.code).filter(Boolean);
    if (!targets.length) return;
    const res = await K.apiSafe('stockLimitReasons', { codes: targets });
    if (!res.ok || K.state.route !== 'hot' || (K.state.viewState.hot && K.state.viewState.hot.tab) !== tab) return;
    const map = new Map((res.data.items || []).map(x => [x.code, x]));
    document.querySelectorAll('[data-hot-reason]').forEach(el => {
      const item = map.get(el.getAttribute('data-hot-reason'));
      const reason = String((item && (item.reason || item.summary)) || '').replace(/\s+/g, ' ').trim();
      if (!reason) return;
      const summary = reason.split(/[；;\r\n]/)[0].slice(0, 92);
      const dateLabel = item.date && item.date !== hotDate ? `（${item.date}）` : '';
      el.textContent = `涨停原因${dateLabel}：${summary}${summary.length >= 92 ? '…' : ''}`;
      el.title = reason;
      el.classList.add('loaded');
    });
  }

  function bindHot(vs) {
    document.querySelectorAll('#content [data-hot-tab]').forEach(btn => {
      if (btn.dataset.boundHot) return;
      btn.dataset.boundHot = '1';
      btn.addEventListener('click', () => {
        vs.tab = btn.getAttribute('data-hot-tab');
        V.hot();
      });
    });
  }
})();
