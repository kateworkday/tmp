/* 开盘啦盯盘助手 - 前端核心工具 */
(function () {
  'use strict';

  const K = window.K = window.K || {};

  K.state = {
    route: 'overview',
    date: todayStr(),
    auto: 0,
    timer: null,
    navHistory: [],
    navReady: false,
    viewState: {},
    prefs: loadPrefs()
  };

  function pad2(n) { return String(n).padStart(2, '0'); }

  function todayStr() {
    const d = new Date();
    return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
  }

  function loadPrefs() {
    try {
      return JSON.parse(localStorage.getItem('kpl.prefs') || '{}') || {};
    } catch (_) { return {}; }
  }

  function savePrefs() {
    try { localStorage.setItem('kpl.prefs', JSON.stringify(K.state.prefs)); } catch (_) {}
  }

  K.todayStr = todayStr;
  K.pad2 = pad2;
  K.loadPrefs = loadPrefs;
  K.savePrefs = savePrefs;

  K.esc = function esc(v) {
    return String(v === null || v === undefined ? '' : v)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  };

  K.num = function num(v, fallback = 0) {
    const n = Number(v);
    return Number.isFinite(n) ? n : fallback;
  };

  K.round = function round(v, digits = 2) {
    const n = Number(v);
    if (!Number.isFinite(n)) return 0;
    const p = 10 ** digits;
    return Math.round(n * p) / p;
  };

  K.fmtNum = function fmtNum(v, digits = 2) {
    const n = Number(v);
    if (!Number.isFinite(n)) return '-';
    return n.toLocaleString('zh-CN', { maximumFractionDigits: digits, minimumFractionDigits: digits });
  };

  K.fmtInt = function fmtInt(v) {
    const n = Number(v);
    if (!Number.isFinite(n)) return '-';
    return n.toLocaleString('zh-CN', { maximumFractionDigits: 0 });
  };

  K.fmtPrice = function fmtPrice(v, digits = 2) {
    const n = Number(v);
    if (!Number.isFinite(n) || n === 0) return '-';
    return n.toFixed(digits);
  };

  K.fmtRate = function fmtRate(v, digits = 2) {
    const n = Number(v);
    if (!Number.isFinite(n)) return '-';
    return `${n.toFixed(digits)}%`;
  };

  K.fmtPct = function fmtPct(v, digits = 2) {
    const n = Number(v);
    if (!Number.isFinite(n)) return '-';
    return `${n > 0 ? '+' : ''}${n.toFixed(digits)}%`;
  };

  K.pctClass = function pctClass(v) {
    const n = Number(v);
    if (!Number.isFinite(n) || n === 0) return 'flat';
    return n > 0 ? 'up' : 'down';
  };

  K.fmtBig = function fmtBig(v) {
    const n = Number(v);
    if (!Number.isFinite(n)) return '-';
    const abs = Math.abs(n);
    const sign = n < 0 ? '-' : '';
    if (abs >= 1e8) return `${sign}${(abs / 1e8).toFixed(2)}亿`;
    if (abs >= 1e4) return `${sign}${(abs / 1e4).toFixed(1)}万`;
    return `${sign}${abs.toFixed(0)}`;
  };

  K.fmtBigSigned = function fmtBigSigned(v) {
    const n = Number(v);
    if (!Number.isFinite(n)) return '-';
    return `${n > 0 ? '+' : ''}${K.fmtBig(n)}`;
  };

  K.fmtDate = function fmtDate(v) {
    const s = String(v || '');
    if (/^\d{8}$/.test(s)) return `${s.slice(0, 4)}-${s.slice(4, 6)}-${s.slice(6, 8)}`;
    return s;
  };

  K.pctCell = function pctCell(v, digits = 2) {
    return `<span class="num ${K.pctClass(v)}">${K.esc(K.fmtPct(v, digits))}</span>`;
  };

  K.bigCell = function bigCell(v, signed = false) {
    const text = signed ? K.fmtBigSigned(v) : K.fmtBig(v);
    return `<span class="num ${signed ? K.pctClass(v) : ''}">${K.esc(text)}</span>`;
  };

  K.moneyCell = function moneyCell(v) {
    const n = Number(v);
    const cls = n > 0 ? 'up' : n < 0 ? 'down' : 'flat';
    return `<span class="num ${cls}">${K.esc(K.fmtBigSigned(n))}</span>`;
  };

  K.api = async function api(action, params = {}) {
    let res;
    try {
      res = await browser.runtime.sendMessage({ type: 'api', action, params });
    } catch (err) {
      throw new Error(`后台通信失败：${err && err.message ? err.message : err}`);
    }
    if (!res) throw new Error('后台无响应，请重新加载扩展');
    if (!res.ok) throw new Error(res.error || '接口调用失败');
    return res.data;
  };

  K.apiSafe = async function apiSafe(action, params = {}) {
    try {
      return { ok: true, data: await K.api(action, params) };
    } catch (err) {
      return { ok: false, error: err && err.message ? err.message : String(err) };
    }
  };

  K.parallel = async function parallel(tasks) {
    const results = await Promise.allSettled(tasks.map(t => t()));
    return results.map(r => r.status === 'fulfilled' ? { ok: true, data: r.value } : { ok: false, error: r.reason && r.reason.message || String(r.reason) });
  };

  K.escAttr = function escAttr(v) { return K.esc(v).replace(/`/g, '&#96;'); };

  K.toast = function toast(message, type = 'info', ms = 3200) {
    const box = document.getElementById('toast');
    if (!box) return;
    const item = document.createElement('div');
    item.className = `toast-item toast-${type}`;
    item.innerHTML = `<span class="toast-dot"></span><span>${K.esc(message)}</span>`;
    box.appendChild(item);
    requestAnimationFrame(() => item.classList.add('show'));
    setTimeout(() => {
      item.classList.remove('show');
      setTimeout(() => item.remove(), 250);
    }, ms);
  };

  K.openDrawer = function openDrawer(title, subtitle, html) {
    const drawer = document.getElementById('drawer');
    document.getElementById('drawerTitle').textContent = title || '详情';
    document.getElementById('drawerSubtitle').textContent = subtitle || '';
    document.getElementById('drawerBody').innerHTML = html || '';
    drawer.classList.remove('hidden');
    drawer.setAttribute('aria-hidden', 'false');
    document.body.classList.add('drawer-open');
  };

  K.closeDrawer = function closeDrawer() {
    const drawer = document.getElementById('drawer');
    drawer.classList.add('hidden');
    drawer.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('drawer-open');
  };

  document.addEventListener('click', e => {
    if (e.target.closest('[data-close-drawer]')) K.closeDrawer();
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') K.closeDrawer();
  });

  K.empty = function empty(text = '暂无数据', hint = '') {
    return `<div class="empty-state"><div class="empty-icon">∅</div><p>${K.esc(text)}</p>${hint ? `<span>${K.esc(hint)}</span>` : ''}</div>`;
  };

  K.errorBox = function errorBox(err, title = '数据加载失败') {
    const msg = err && err.message ? err.message : String(err || '未知错误');
    return `<div class="error-box"><div class="error-title">${K.esc(title)}</div><div class="error-msg">${K.esc(msg)}</div><div class="error-hint">请检查网络、接口日期是否为交易日，或稍后重试。</div></div>`;
  };

  K.loading = function loading(text = '加载中…') {
    return `<div class="loading-box"><div class="spinner"></div><span>${K.esc(text)}</span></div>`;
  };

  K.stat = function stat(label, value, sub = '', cls = '', raw = false) {
    const val = raw ? value : K.esc(value);
    return `<div class="stat-card ${cls}"><div class="stat-label">${K.esc(label)}</div><div class="stat-value">${val}</div>${sub ? `<div class="stat-sub">${raw ? sub : K.esc(sub)}</div>` : ''}</div>`;
  };

  K.statsGrid = function statsGrid(items) {
    return `<div class="stat-grid">${items.map(x => K.stat(x.label, x.value, x.sub, x.cls, x.raw)).join('')}</div>`;
  };

  K.section = function section(title, subtitle, body, actions = '') {
    return `<section class="panel">
      <header class="panel-head">
        <div><h2>${K.esc(title)}</h2>${subtitle ? `<p>${K.esc(subtitle)}</p>` : ''}</div>
        ${actions ? `<div class="panel-actions">${actions}</div>` : ''}
      </header>
      <div class="panel-body">${body}</div>
    </section>`;
  };

  K.tabs = function tabs(items, active, attr = 'data-tab') {
    return `<div class="segmented">${items.map(x => `<button class="seg-btn ${x.id === active ? 'active' : ''}" ${attr}="${K.escAttr(x.id)}">${K.esc(x.label)}${x.count !== undefined ? `<em>${K.esc(x.count)}</em>` : ''}</button>`).join('')}</div>`;
  };

  K.table = function table(columns, rows, options = {}) {
    const list = Array.isArray(rows) ? rows : [];
    if (!list.length) return options.empty || K.empty(options.emptyText || '暂无数据', options.emptyHint || '');
    const head = columns.map(c => `<th class="${c.align || ''}"${c.width ? ` style="width:${c.width}"` : ''}>${K.esc(c.label)}</th>`).join('');
    const body = list.map((row, i) => {
      const cells = columns.map(c => {
        let value;
        if (typeof c.render === 'function') value = c.render(row, i);
        else value = K.esc(row[c.key]);
        if (value === undefined || value === null || value === '') value = '<span class="muted">-</span>';
        return `<td class="${c.align || ''} ${c.className || ''}">${value}</td>`;
      }).join('');
      const rowClass = typeof options.rowClass === 'function' ? options.rowClass(row, i) : '';
      return `<tr data-row="${i}" class="${rowClass}">${cells}</tr>`;
    }).join('');
    const tableClass = options.tableClass ? ` ${K.escAttr(options.tableClass)}` : '';
    const minWidth = Number(options.minWidth);
    const tableStyle = Number.isFinite(minWidth) && minWidth > 0 ? ` style="min-width:${Math.round(minWidth)}px"` : '';
    return `<div class="table-wrap"><table class="data-table${tableClass}"${tableStyle}><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>`;
  };

  K.bindRows = function bindRows(root, rows, handler) {
    root.querySelectorAll('tbody tr[data-row]').forEach(tr => {
      tr.addEventListener('click', () => {
        const index = Number(tr.getAttribute('data-row'));
        if (Number.isInteger(index) && rows[index]) handler(rows[index], index);
      });
    });
  };

  K.stockChip = function stockChip(item, cls = '') {
    const tips = item.tips || item.boardText || '';
    return `<button type="button" class="stock-chip ${cls}" data-code="${K.escAttr(item.code)}" data-name="${K.escAttr(item.name || '')}">
      <b>${K.esc(item.name || item.code || '-')}</b>
      <span>${K.esc(item.code || '')}</span>
      ${tips ? `<em>${K.esc(tips)}</em>` : ''}
    </button>`;
  };

  K.bindStockLinks = function bindStockLinks(root) {
    root.querySelectorAll('[data-code]').forEach(el => {
      if (el.dataset.boundStock) return;
      el.dataset.boundStock = '1';
      el.addEventListener('click', e => {
        const code = el.getAttribute('data-code');
        if (!code) return;
        e.preventDefault();
        e.stopPropagation();
        K.openStock(code, el.getAttribute('data-name') || '');
      });
    });
  };

  K.openStock = function openStock(code, name = '') {
    const value = String(code || '');
    K.state.prefs.stockCode = value;
    K.state.prefs.stockName = name;
    if (K.state.viewState.stock) K.state.viewState.stock.code = value;
    K.savePrefs();
    if (window.navigate) window.navigate('stock');
  };

  K.openSectorStocks = function openSectorStocks(code, name = '') {
    const value = String(code || '');
    if (!value) return;
    const label = name || K.state.prefs.sectorName || value;
    K.state.prefs.sectorCode = value;
    K.state.prefs.sectorName = label;
    const extraCols = K.state.prefs.sectorStockCols || {};
    K.state.viewState.sectorStocks = { code: value, name: label, mode: 'realtime', sort: 'change', extraCols: { ...extraCols } };
    if (K.state.viewState.sector) K.state.viewState.sector.code = value;
    K.savePrefs();
    if (window.navigate) window.navigate('sectorStocks');
  };

  K.openSector = function openSector(code, name = '') {
    const value = String(code || '');
    K.state.prefs.sectorCode = value;
    K.state.prefs.sectorName = name;
    if (K.state.viewState.sector) K.state.viewState.sector.code = value;
    K.savePrefs();
    if (window.navigate) window.navigate('sector');
  };

  K.details = function details(title, meta, body, open = false) {
    return `<details class="accordion" ${open ? 'open' : ''}>
      <summary><span class="acc-title">${K.esc(title)}</span><span class="acc-meta">${meta || ''}</span></summary>
      <div class="acc-body">${body}</div>
    </details>`;
  };

  K.toggleClass = function toggleClass(el, cls, on) {
    if (!el) return;
    el.classList.toggle(cls, !!on);
  };

  K.debounce = function debounce(fn, ms = 300) {
    let timer = null;
    return function (...args) {
      clearTimeout(timer);
      timer = setTimeout(() => fn.apply(this, args), ms);
    };
  };

  K.attachChartResize = function attachChartResize(canvas, draw) {
    if (!canvas) return;
    canvas._roDraw = draw;
    if (canvas._ro) return;
    const wrap = canvas.parentElement;
    if (!wrap) return;
    let lastW = wrap.clientWidth;
    const ro = new ResizeObserver(() => {
      const w = wrap.clientWidth;
      if (!w || Math.abs(w - lastW) < 2) return;
      lastW = w;
      if (typeof canvas._roDraw === 'function') canvas._roDraw();
    });
    ro.observe(wrap);
    canvas._ro = ro;
  };

  K.setPage = function setPage(title, subtitle, eyebrow) {
    K.state.viewRoute = K.state.route;
    const t = document.getElementById('pageTitle');
    const s = document.getElementById('pageSubtitle');
    const e = document.getElementById('pageEyebrow');
    if (t) t.textContent = title;
    if (s) s.textContent = subtitle || '';
    if (e && eyebrow) e.textContent = eyebrow;
  };

  K.scrollTop = function scrollTop() {
    const main = document.querySelector('.main');
    if (main) main.scrollTo({ top: 0, behavior: 'smooth' });
  };

  K.render = function render(html) {
    if (K.state.viewRoute && K.state.viewRoute !== K.state.route) return;
    const content = document.getElementById('content');
    content.innerHTML = html;
    content.classList.remove('fade-in');
    void content.offsetWidth;
    content.classList.add('fade-in');
  };

  K.confirmButton = function confirmButton(label, handler, cls = 'btn') {
    return `<button class="${cls}" data-action="${K.escAttr(label)}">${K.esc(label)}</button>`;
  };
})();
