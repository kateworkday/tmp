/* 开盘啦盯盘助手 - Canvas 图表（无第三方依赖） */
(function () {
  'use strict';

  const C = window.Charts = window.Charts || {};
  const COLORS = {
    up: '#f6465d',
    down: '#0ecb81',
    flat: '#8b9bb4',
    line: '#6ea8fe',
    avg: '#fbbf24',
    grid: 'rgba(139,155,180,0.14)',
    text: '#8b9bb4',
    strong: '#e6edf7',
    pre: 'rgba(139,155,180,0.55)',
    ma5: '#f7c948',
    ma10: '#6ea8fe',
    ma20: '#c084fc'
  };

  function setup(canvas, height) {
    const wrap = canvas.parentElement;
    const dpr = window.devicePixelRatio || 1;
    const w = Math.max(320, wrap.clientWidth || 800);
    const h = height || wrap.clientHeight || 340;
    canvas.width = Math.floor(w * dpr);
    canvas.height = Math.floor(h * dpr);
    canvas.style.width = `${w}px`;
    canvas.style.height = `${h}px`;
    const ctx = canvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);
    return { ctx, w, h, dpr };
  }

  function empty(canvas, text) {
    const { ctx, w, h } = setup(canvas, canvas.parentElement.clientHeight || 340);
    ctx.fillStyle = 'rgba(139,155,180,0.55)';
    ctx.font = '13px system-ui, -apple-system, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text || '暂无数据', w / 2, h / 2);
  }

  function clamp(v, a, b) { return Math.min(b, Math.max(a, v)); }

  function money(v) { return window.K ? K.fmtBig(v) : String(v); }

  function ensureTip(canvas) {
    let tip = canvas.parentElement.querySelector('.chart-tip');
    if (!tip) {
      tip = document.createElement('div');
      tip.className = 'chart-tip';
      canvas.parentElement.appendChild(tip);
    }
    return tip;
  }

  function hideTip(canvas) {
    const tip = canvas.parentElement && canvas.parentElement.querySelector('.chart-tip');
    if (tip) tip.classList.remove('show');
  }

  function showTip(canvas, html, x, y, w) {
    const tip = ensureTip(canvas);
    tip.innerHTML = html;
    tip.classList.add('show');
    const tw = Math.min(230, tip.offsetWidth || 180);
    const left = x + 14 > w - tw - 10 ? x - tw - 14 : x + 14;
    tip.style.left = `${clamp(left, 8, w - tw - 8)}px`;
    tip.style.top = `${clamp(y + 10, 8, 260)}px`;
  }

  function bindHover(canvas, paint) {
    if (canvas._hoverBound) return;
    canvas._hoverBound = true;
    canvas.addEventListener('mousemove', e => {
      const rect = canvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      if (canvas._pick) {
        const idx = canvas._pick(x);
        canvas._hoverIndex = idx;
        paint(idx);
        if (idx == null) hideTip(canvas);
      }
    });
    canvas.addEventListener('mouseleave', () => {
      canvas._hoverIndex = null;
      paint(null);
      hideTip(canvas);
    });
  }

  function drawGrid(ctx, left, right, top, bottom, lines, labels, valueToY) {
    ctx.save();
    ctx.strokeStyle = COLORS.grid;
    ctx.lineWidth = 1;
    ctx.font = '11px system-ui, -apple-system, sans-serif';
    ctx.fillStyle = COLORS.text;
    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';
    for (let i = 0; i <= lines; i += 1) {
      const y = top + (bottom - top) * (i / lines);
      ctx.beginPath();
      ctx.moveTo(left, y);
      ctx.lineTo(right, y);
      ctx.stroke();
      if (labels) {
        ctx.fillText(labels[i] || '', left - 8, y);
      }
    }
    ctx.restore();
  }

  function drawTimeAxis(ctx, left, right, top, bottom, pickIndices, points, multiDay) {
    ctx.save();
    ctx.fillStyle = COLORS.text;
    ctx.font = '11px system-ui, -apple-system, sans-serif';
    ctx.textBaseline = 'top';
    const n = points.length;
    for (const idx of pickIndices) {
      if (idx < 0 || idx >= n) continue;
      const x = left + (right - left) * (n <= 1 ? 0.5 : idx / (n - 1));
      let label = points[idx].time || '';
      if (multiDay && points[idx].date) label = `${points[idx].date.slice(5)} ${label}`;
      ctx.textAlign = idx === 0 ? 'left' : idx === n - 1 ? 'right' : 'center';
      ctx.fillText(label, x, bottom + 8);
    }
    ctx.restore();
  }

  function drawTrend(canvas, points, options = {}) {
    const list = (points || []).filter(p => p && Number.isFinite(Number(p.price)) && Number(p.price) > 0);
    if (!list.length) { empty(canvas, options.emptyText || '暂无分时数据'); return; }
    const height = options.height || canvas.parentElement.clientHeight || 340;
    const { ctx, w, h } = setup(canvas, height);
    const left = 58, right = w - 56, top = 18, bottom = h - 46;
    const volumeH = options.volume === false ? 0 : 58;
    const priceBottom = bottom - volumeH - (volumeH ? 8 : 0);
    const priceH = priceBottom - top;
    const preClose = Number(options.preClose) || 0;
    const showPre = preClose > 0 && !options.multiDay;
    const values = list.map(p => Number(p.price));
    if (options.avg !== false) values.push(...list.map(p => Number(p.avg)).filter(Number.isFinite));
    if (showPre) values.push(preClose);
    let min = Math.min(...values), max = Math.max(...values);
    if (!Number.isFinite(min) || !Number.isFinite(max)) { empty(canvas); return; }
    if (max === min) { max += max * 0.01 || 1; min -= min * 0.01 || 1; }
    const pad = (max - min) * 0.06;
    min -= pad; max += pad;
    const y = v => top + (max - v) / (max - min) * priceH;
    const x = i => left + (right - left) * (list.length <= 1 ? 0.5 : i / (list.length - 1));

    const priceLabels = [];
    for (let i = 0; i <= 5; i += 1) priceLabels.push((max - (max - min) * i / 5).toFixed(2));
    drawGrid(ctx, left, right, top, priceBottom, 5, priceLabels);

    if (showPre) {
      ctx.save();
      ctx.strokeStyle = COLORS.pre;
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      ctx.moveTo(left, y(preClose));
      ctx.lineTo(right, y(preClose));
      ctx.stroke();
      ctx.restore();
    }

    // 涨跌幅右侧刻度
    if (showPre) {
      ctx.save();
      ctx.fillStyle = COLORS.text;
      ctx.font = '11px system-ui, -apple-system, sans-serif';
      ctx.textAlign = 'left';
      ctx.textBaseline = 'middle';
      for (let i = 0; i <= 5; i += 1) {
        const p = max - (max - min) * i / 5;
        const pct = (p - preClose) / preClose * 100;
        ctx.fillStyle = pct > 0 ? COLORS.up : pct < 0 ? COLORS.down : COLORS.text;
        ctx.fillText(`${pct > 0 ? '+' : ''}${pct.toFixed(2)}%`, right + 8, top + priceH * i / 5);
      }
      ctx.restore();
    }

    // 面积
    const grad = ctx.createLinearGradient(0, top, 0, priceBottom);
    grad.addColorStop(0, 'rgba(110,168,254,0.28)');
    grad.addColorStop(1, 'rgba(110,168,254,0.01)');
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(x(0), priceBottom);
    list.forEach((p, i) => ctx.lineTo(x(i), y(p.price)));
    ctx.lineTo(x(list.length - 1), priceBottom);
    ctx.closePath();
    ctx.fillStyle = grad;
    ctx.fill();
    ctx.restore();

    // 价格线
    ctx.save();
    ctx.beginPath();
    list.forEach((p, i) => i ? ctx.lineTo(x(i), y(p.price)) : ctx.moveTo(x(i), y(p.price)));
    ctx.strokeStyle = options.color || COLORS.line;
    ctx.lineWidth = 1.6;
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    ctx.stroke();
    ctx.restore();

    // 均价线
    if (options.avg !== false) {
      ctx.save();
      ctx.beginPath();
      let started = false;
      list.forEach((p, i) => {
        const a = Number(p.avg);
        if (!Number.isFinite(a) || a <= 0) return;
        if (!started) { ctx.moveTo(x(i), y(a)); started = true; }
        else ctx.lineTo(x(i), y(a));
      });
      if (started) {
        ctx.strokeStyle = COLORS.avg;
        ctx.lineWidth = 1.2;
        ctx.setLineDash([4, 3]);
        ctx.stroke();
      }
      ctx.restore();
    }

    // 成交量
    if (volumeH) {
      const maxVol = Math.max(...list.map(p => Number(p.volume) || 0), 1);
      const volTop = priceBottom + 8;
      const volBottom = bottom;
      ctx.save();
      ctx.strokeStyle = COLORS.grid;
      ctx.beginPath();
      ctx.moveTo(left, volTop);
      ctx.lineTo(right, volTop);
      ctx.stroke();
      const barW = Math.max(1, (right - left) / list.length * 0.65);
      list.forEach((p, i) => {
        const v = Number(p.volume) || 0;
        if (v <= 0) return;
        const bh = Math.max(1, v / maxVol * (volBottom - volTop));
        const prev = i > 0 ? Number(list[i - 1].price) : Number(p.price);
        const up = Number(p.price) >= prev;
        ctx.fillStyle = up ? 'rgba(246,70,93,0.42)' : 'rgba(14,203,129,0.42)';
        ctx.fillRect(x(i) - barW / 2, volBottom - bh, barW, bh);
      });
      ctx.fillStyle = COLORS.text;
      ctx.font = '10px system-ui, -apple-system, sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText('成交量', left + 2, volTop + 2);
      ctx.restore();
    }

    const pickIndices = [0, Math.floor((list.length - 1) * 0.25), Math.floor((list.length - 1) * 0.5), Math.floor((list.length - 1) * 0.75), list.length - 1];
    drawTimeAxis(ctx, left, right, top, bottom, pickIndices, list, options.multiDay);

    if (options.title) {
      ctx.save();
      ctx.fillStyle = COLORS.strong;
      ctx.font = '600 12px system-ui, -apple-system, sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText(options.title, left, 4);
      ctx.restore();
    }

    canvas._pick = px => {
      if (px < left || px > right) return null;
      return clamp(Math.round((px - left) / (right - left) * (list.length - 1)), 0, list.length - 1);
    };
    canvas._paint = hoverIndex => {
      drawTrend(canvas, list, { ...options, height, _hover: hoverIndex });
      const idx = hoverIndex != null ? hoverIndex : canvas._hoverIndex;
      if (idx == null || !list[idx]) return;
      const p = list[idx];
      const px = x(idx), py = y(p.price);
      ctx.save();
      ctx.strokeStyle = 'rgba(230,237,247,0.35)';
      ctx.setLineDash([3, 4]);
      ctx.beginPath();
      ctx.moveTo(px, top);
      ctx.lineTo(px, bottom);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = options.color || COLORS.line;
      ctx.beginPath();
      ctx.arc(px, py, 3.2, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
      const pct = showPre ? (p.price - preClose) / preClose * 100 : null;
      showTip(canvas, `<div class="tip-title">${K.esc(p.date || '')} ${K.esc(p.time || '')}</div>
        <div class="tip-row"><span>价格</span><b>${p.price.toFixed(2)}</b></div>
        ${pct != null ? `<div class="tip-row"><span>涨跌</span><b class="${pct >= 0 ? 'up' : 'down'}">${pct > 0 ? '+' : ''}${pct.toFixed(2)}%</b></div>` : ''}
        ${p.avg ? `<div class="tip-row"><span>均价</span><b>${Number(p.avg).toFixed(2)}</b></div>` : ''}
        <div class="tip-row"><span>成交量</span><b>${money(p.volume)}</b></div>`, px, py, w);
    };
    bindHover(canvas, idx => canvas._paint(idx));
    if (window.K) K.attachChartResize(canvas, () => drawTrend(canvas, list, options));
  }

  function calcMA(bars, n) {
    const out = new Array(bars.length).fill(null);
    let sum = 0;
    for (let i = 0; i < bars.length; i += 1) {
      sum += Number(bars[i].close) || 0;
      if (i >= n) sum -= Number(bars[i - n].close) || 0;
      if (i >= n - 1) out[i] = sum / n;
    }
    return out;
  }

  function drawKline(canvas, bars, options = {}) {
    const all = (bars || []).filter(b => b && Number.isFinite(Number(b.close)));
    const maxBars = Math.max(30, Number(options.maxBars) || 120);
    const list = all.slice(-maxBars);
    if (!list.length) { empty(canvas, '暂无K线数据'); return; }
    const height = options.height || canvas.parentElement.clientHeight || 380;
    const { ctx, w, h } = setup(canvas, height);
    const left = 58, right = w - 16, top = 26, bottom = h - 42;
    const volumeH = 58;
    const priceBottom = bottom - volumeH - 10;
    const priceH = priceBottom - top;
    const highs = list.map(b => Number(b.high) || Number(b.close));
    const lows = list.map(b => Number(b.low) || Number(b.close));
    let max = Math.max(...highs), min = Math.min(...lows);
    if (max === min) { max += 1; min -= 1; }
    const pad = (max - min) * 0.05;
    max += pad; min -= pad;
    const y = v => top + (max - v) / (max - min) * priceH;
    const n = list.length;
    const step = (right - left) / n;
    const bw = Math.max(1, Math.min(13, step * 0.62));
    const x = i => left + step * (i + 0.5);

    const labels = [];
    for (let i = 0; i <= 5; i += 1) labels.push((max - (max - min) * i / 5).toFixed(2));
    drawGrid(ctx, left, right, top, priceBottom, 5, labels);

    // MA
    const maDefs = (options.ma || [5, 10, 20]).map(nn => ({ n: nn, values: calcMA(all, nn).slice(-maxBars), color: nn === 5 ? COLORS.ma5 : nn === 10 ? COLORS.ma10 : COLORS.ma20 }));
    for (const ma of maDefs) {
      ctx.save();
      ctx.beginPath();
      let started = false;
      ma.values.forEach((v, i) => {
        if (v == null) return;
        if (!started) { ctx.moveTo(x(i), y(v)); started = true; } else ctx.lineTo(x(i), y(v));
      });
      if (started) {
        ctx.strokeStyle = ma.color;
        ctx.lineWidth = 1.1;
        ctx.stroke();
      }
      ctx.restore();
    }

    // Candles + volume
    const maxVol = Math.max(...list.map(b => Number(b.volume) || 0), 1);
    const volTop = priceBottom + 10;
    const volBottom = bottom;
    ctx.save();
    ctx.strokeStyle = COLORS.grid;
    ctx.beginPath(); ctx.moveTo(left, volTop); ctx.lineTo(right, volTop); ctx.stroke();
    list.forEach((b, i) => {
      const open = Number(b.open), close = Number(b.close), high = Number(b.high), low = Number(b.low);
      const up = close >= open;
      const color = up ? COLORS.up : COLORS.down;
      const cx = x(i);
      ctx.strokeStyle = color;
      ctx.fillStyle = color;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(cx, y(high));
      ctx.lineTo(cx, y(low));
      ctx.stroke();
      const bodyTop = y(Math.max(open, close));
      const bodyH = Math.max(1, Math.abs(y(open) - y(close)));
      ctx.fillRect(cx - bw / 2, bodyTop, bw, bodyH);
      const v = Number(b.volume) || 0;
      if (v > 0) {
        const bh = Math.max(1, v / maxVol * (volBottom - volTop));
        ctx.globalAlpha = 0.5;
        ctx.fillRect(cx - bw / 2, volBottom - bh, bw, bh);
        ctx.globalAlpha = 1;
      }
    });
    ctx.restore();

    // Date labels
    const idxs = [0, Math.floor((n - 1) * 0.2), Math.floor((n - 1) * 0.4), Math.floor((n - 1) * 0.6), Math.floor((n - 1) * 0.8), n - 1];
    ctx.save();
    ctx.fillStyle = COLORS.text;
    ctx.font = '11px system-ui, -apple-system, sans-serif';
    ctx.textBaseline = 'top';
    for (const i of [...new Set(idxs)]) {
      const d = String(list[i].date || '');
      ctx.textAlign = i === 0 ? 'left' : i === n - 1 ? 'right' : 'center';
      ctx.fillText(d.length > 10 ? d.slice(5, 10) : d, x(i), bottom + 6);
    }
    ctx.restore();

    // Legend
    ctx.save();
    ctx.font = '11px system-ui, -apple-system, sans-serif';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    let lx = left;
    for (const ma of maDefs) {
      ctx.fillStyle = ma.color;
      ctx.fillRect(lx, 7, 12, 2);
      ctx.fillText(`MA${ma.n}`, lx + 16, 8);
      lx += 62;
    }
    ctx.fillStyle = COLORS.text;
    ctx.fillText(`最近 ${n} 根`, right - 70, 8);
    ctx.restore();

    if (options.title) {
      ctx.save();
      ctx.fillStyle = COLORS.strong;
      ctx.font = '600 12px system-ui, -apple-system, sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText(options.title, left, 2);
      ctx.restore();
    }

    canvas._pick = px => {
      if (px < left || px > right) return null;
      return clamp(Math.floor((px - left) / step), 0, n - 1);
    };
    canvas._paint = hoverIndex => {
      drawKline(canvas, all, { ...options, maxBars, height, _hover: hoverIndex });
      const idx = hoverIndex != null ? hoverIndex : canvas._hoverIndex;
      if (idx == null || !list[idx]) return;
      const b = list[idx];
      const cx = x(idx), cy = y(Number(b.close));
      ctx.save();
      ctx.strokeStyle = 'rgba(230,237,247,0.35)';
      ctx.setLineDash([3, 4]);
      ctx.beginPath(); ctx.moveTo(cx, top); ctx.lineTo(cx, bottom); ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = COLORS.strong;
      ctx.beginPath(); ctx.arc(cx, cy, 3, 0, Math.PI * 2); ctx.fill();
      ctx.restore();
      const chg = Number(b.changePct);
      showTip(canvas, `<div class="tip-title">${K.esc(b.date || '')}</div>
        <div class="tip-row"><span>开</span><b>${Number(b.open).toFixed(2)}</b></div>
        <div class="tip-row"><span>高</span><b>${Number(b.high).toFixed(2)}</b></div>
        <div class="tip-row"><span>低</span><b>${Number(b.low).toFixed(2)}</b></div>
        <div class="tip-row"><span>收</span><b>${Number(b.close).toFixed(2)}</b></div>
        <div class="tip-row"><span>涨跌</span><b class="${chg >= 0 ? 'up' : 'down'}">${chg > 0 ? '+' : ''}${Number(chg).toFixed(2)}%</b></div>
        <div class="tip-row"><span>成交量</span><b>${money(b.volume)}</b></div>
        ${b.amount ? `<div class="tip-row"><span>成交额</span><b>${money(b.amount)}</b></div>` : ''}`, cx, cy, w);
    };
    bindHover(canvas, idx => canvas._paint(idx));
    if (window.K) K.attachChartResize(canvas, () => drawKline(canvas, all, options));
  }

  function drawLine(canvas, labels, values, options = {}) {
    const list = (values || []).map(Number);
    if (!list.length) { empty(canvas, '暂无数据'); return; }
    const height = options.height || canvas.parentElement.clientHeight || 260;
    const { ctx, w, h } = setup(canvas, height);
    const left = 48, right = w - 24, top = 18, bottom = h - 34;
    let min = Math.min(...list), max = Math.max(...list);
    if (max === min) { max += 1; min -= 1; }
    const pad = (max - min) * 0.12;
    min -= pad; max += pad;
    const y = v => top + (max - v) / (max - min) * (bottom - top);
    const x = i => left + (right - left) * (list.length <= 1 ? 0.5 : i / (list.length - 1));
    const yl = [];
    for (let i = 0; i <= 4; i += 1) yl.push((max - (max - min) * i / 4).toFixed(2));
    drawGrid(ctx, left, right, top, bottom, 4, yl);

    ctx.save();
    ctx.beginPath();
    list.forEach((v, i) => i ? ctx.lineTo(x(i), y(v)) : ctx.moveTo(x(i), y(v)));
    ctx.strokeStyle = options.color || COLORS.line;
    ctx.lineWidth = 1.8;
    ctx.stroke();
    if (options.fill !== false) {
      ctx.lineTo(x(list.length - 1), bottom);
      ctx.lineTo(x(0), bottom);
      ctx.closePath();
      const grad = ctx.createLinearGradient(0, top, 0, bottom);
      grad.addColorStop(0, 'rgba(110,168,254,0.22)');
      grad.addColorStop(1, 'rgba(110,168,254,0.01)');
      ctx.fillStyle = grad;
      ctx.fill();
    }
    ctx.restore();

    ctx.save();
    ctx.fillStyle = COLORS.text;
    ctx.font = '11px system-ui, -apple-system, sans-serif';
    ctx.textBaseline = 'top';
    const step = Math.max(1, Math.ceil(list.length / 7));
    for (let i = 0; i < list.length; i += step) {
      ctx.textAlign = i === 0 ? 'left' : 'center';
      ctx.fillText(String(labels[i] || ''), x(i), bottom + 8);
    }
    ctx.restore();

    canvas._pick = px => {
      if (px < left || px > right) return null;
      return clamp(Math.round((px - left) / (right - left) * (list.length - 1)), 0, list.length - 1);
    };
    canvas._paint = hoverIndex => {
      drawLine(canvas, labels, values, { ...options, height, _hover: hoverIndex });
      const idx = hoverIndex != null ? hoverIndex : canvas._hoverIndex;
      if (idx == null) return;
      const px = x(idx), py = y(list[idx]);
      ctx.save();
      ctx.strokeStyle = 'rgba(230,237,247,0.35)';
      ctx.setLineDash([3, 4]);
      ctx.beginPath(); ctx.moveTo(px, top); ctx.lineTo(px, bottom); ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = options.color || COLORS.line;
      ctx.beginPath(); ctx.arc(px, py, 3.2, 0, Math.PI * 2); ctx.fill();
      ctx.restore();
      showTip(canvas, `<div class="tip-title">${K.esc(labels[idx] || '')}</div><div class="tip-row"><span>数值</span><b>${list[idx].toFixed(2)}</b></div>`, px, py, w);
    };
    bindHover(canvas, idx => canvas._paint(idx));
    if (window.K) K.attachChartResize(canvas, () => drawLine(canvas, labels, values, options));
  }

  C.trend = drawTrend;
  C.kline = drawKline;
  C.line = drawLine;
  C.empty = empty;
})();
