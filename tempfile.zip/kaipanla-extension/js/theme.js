/* 在首帧前应用已保存的主题、透明度、色彩度和亮度，避免闪烁 */
(function () {
  try {
    var theme = localStorage.getItem('kpl.theme');
    if (theme === 'light' || theme === 'dark' || theme === 'gray') {
      document.documentElement.setAttribute('data-theme', theme);
    }
    var opacityRaw = localStorage.getItem('kpl.opacity');
    var opacity = opacityRaw == null || opacityRaw === '' ? NaN : Number(opacityRaw);
    if (Number.isFinite(opacity)) {
      opacity = Math.max(10, Math.min(100, opacity));
      document.documentElement.style.setProperty('--surface-alpha', String(opacity / 100));
      document.documentElement.setAttribute('data-glass', opacity < 100 ? 'true' : 'false');
    }
    var colorRaw = localStorage.getItem('kpl.colorNum');
    var colorNum = colorRaw == null || colorRaw === '' ? NaN : Number(colorRaw);
    if (Number.isFinite(colorNum)) {
      colorNum = Math.max(0, Math.min(100, colorNum));
      document.documentElement.style.setProperty('--ui-grayscale', `${100 - colorNum}%`);
    }
    if (window.innerWidth > 0 && window.innerWidth <= 900 && window.innerHeight <= 700) {
      document.documentElement.classList.add('popup-mode');
    }
    var brightnessRaw = localStorage.getItem('kpl.brightness');
    var brightness = brightnessRaw == null || brightnessRaw === '' ? NaN : Number(brightnessRaw);
    if (Number.isFinite(brightness)) {
      brightness = Math.max(70, Math.min(130, brightness));
      document.documentElement.style.setProperty('--ui-brightness', String(brightness / 100));
    }
  } catch (e) {}
})();
