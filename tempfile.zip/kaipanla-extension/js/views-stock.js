/* 开盘啦盯盘助手 - 个股/指数视图 */
(function () {
  'use strict';

  const V = window.Views = window.Views || {};
  const today = () => K.todayStr();
  const currentDate = () => K.state.date || today();
  const isHistory = () => currentDate() !== today();

  function inferSecid(code) {
    let text = String(code || '').trim().toUpperCase();
    if (/^\d\./.test(text)) return text;
    if (text.startsWith('SH') || text.startsWith('SZ')) {
      return `${text.startsWith('SH') ? '1' : '0'}.${text.slice(2)}`;
    }
    if (/^\d{6}$/.test(text)) return /^(6|5|9)/.test(text) ? `1.${text}` : `0.${text}`;
    return text;
  }

  const PERIODS = [
    { id: 'trend', label: '分时', type: 'trend' },
    { id: 'five', label: '五日', type: 'trend', ndays: 5 },
    { id: '1m', label: '1分', type: 'kline' },
    { id: '5m', label: '5分', type: 'kline' },
    { id: '15m', label: '15分', type: 'kline' },
    { id: '30m', label: '30分', type: 'kline' },
    { id: '60m', label: '60分', type: 'kline' },
    { id: '120m', label: '120分', type: 'kline' },
    { id: 'day', label: '日K', type: 'kline' },
    { id: 'week', label: '周K', type: 'kline' },
    { id: 'month', label: '月K', type: 'kline' },
    { id: 'quarter', label: '季K', type: 'kline' },
    { id: 'year', label: '年K', type: 'kline' }
  ];

  function periodOf(id) { return PERIODS.find(x => x.id === id) || PERIODS.find(x => x.id === 'day'); }

  function quoteBlock(q, fallbackCode) {
    const name = q?.name || fallbackCode;
    const price = q?.price || 0;
    const pct = q?.changePct || 0;
    const cls = K.pctClass(pct);
    return `<div class="quote-head">
      <div class="quote-identity">
        <div class="quote-title"><h2>${K.esc(name)}</h2><span class="mono muted">${K.esc(q?.code || fallbackCode)}</span></div>
        <div class="quote-tags">
          ${q?.industry ? `<span class="tag">${K.esc(q.industry)}</span>` : ''}
          ${(q?.concepts || []).slice(0, 5).map(c => `<span class="tag tag-blue">${K.esc(c)}</span>`).join('')}
        </div>
      </div>
      <div class="quote-price ${cls}">
        <strong>${price ? K.fmtPrice(price) : '-'}</strong>
        <span>${price ? K.fmtPct(pct) : '-'}</span>
      </div>
      <div class="quote-side">
        <div><span>今开</span><b>${K.fmtPrice(q?.open)}</b></div>
        <div><span>最高</span><b class="up">${K.fmtPrice(q?.high)}</b></div>
        <div><span>最低</span><b class="down">${K.fmtPrice(q?.low)}</b></div>
        <div><span>昨收</span><b>${K.fmtPrice(q?.preClose)}</b></div>
      </div>
      <div class="quote-side">
        <div><span>成交额</span><b>${K.fmtBig(q?.amount)}</b></div>
        <div><span>换手率</span><b>${K.fmtRate(q?.turnoverRate)}</b></div>
        <div><span>市盈率</span><b>${q?.pe ? K.fmtNum(q.pe) : '-'}</b></div>
        <div><span>市净率</span><b>${q?.pb ? K.fmtNum(q.pb) : '-'}</b></div>
      </div>
    </div>`;
  }

  function chartMetaTrend(data) {
    const last = data.points[data.points.length - 1];
    const first = data.points[0];
    if (!last) return '';
    const chg = data.preClose > 0 ? (last.price - data.preClose) / data.preClose * 100 : 0;
    return `<div class="chart-meta">
      <span>最新 <b class="${K.pctClass(chg)}">${K.fmtPrice(last.price)}</b></span>
      <span>涨跌 <b class="${K.pctClass(chg)}">${K.fmtPct(chg)}</b></span>
      <span>均价 <b>${K.fmtPrice(last.avg)}</b></span>
      <span>区间 <b>${K.fmtPrice(Math.min(...data.points.map(p => p.price)))} - ${K.fmtPrice(Math.max(...data.points.map(p => p.price)))}</b></span>
      <span>数据源 <b>${data.source === 'tencent' ? '腾讯分时' : data.source === 'kpl' ? '开盘啦分时' : '东方财富'}</b></span>
    </div>`;
  }

  function chartMetaKline(data) {
    const last = data.bars[data.bars.length - 1];
    if (!last) return '';
    return `<div class="chart-meta">
      <span>${K.esc(last.date)}</span>
      <span>开 <b>${K.fmtPrice(last.open)}</b></span>
      <span>高 <b class="up">${K.fmtPrice(last.high)}</b></span>
      <span>低 <b class="down">${K.fmtPrice(last.low)}</b></span>
      <span>收 <b class="${K.pctClass(last.changePct)}">${K.fmtPrice(last.close)}</b></span>
      <span>涨跌 <b class="${K.pctClass(last.changePct)}">${K.fmtPct(last.changePct)}</b></span>
      <span>成交额 <b>${last.amount ? K.fmtBig(last.amount) : '-'}</b></span>
      <span>数据源 <b>${data.source === 'tencent' ? '腾讯K线' : '东方财富'}</b></span>
    </div>`;
  }

  function stockSubContent(vs, data) {
    if (!data) return K.empty('暂无数据');
    if (vs.sub === 'kpl') {
      const d = data;
      return `${K.statsGrid([
        { label: '日期', value: d.date, sub: d.realtime ? '实时' : '历史', cls: '' },
        { label: '昨收', value: K.fmtPrice(d.preclose), sub: `${d.points.length} 个分钟点`, cls: '' },
        { label: '主力净流入', value: K.fmtBigSigned(d.totalMainInflow), sub: d.mainFlowAvailable ? '按分钟合计' : '该接口无主力字段', cls: d.totalMainInflow >= 0 ? 'up' : 'down' },
        { label: '主力净流出', value: K.fmtBigSigned(d.totalMainOutflow), sub: '按分钟合计', cls: 'down' }
      ])}
      ${K.section('开盘啦分时明细', '最近 30 个分钟点', K.table([
        { key: 'time', label: '时间' },
        { key: 'price', label: '价格', align: 'right', render: r => `<span class="num">${K.fmtPrice(r.price)}</span>` },
        { key: 'avg', label: '均价', align: 'right', render: r => `<span class="num">${K.fmtPrice(r.avg)}</span>` },
        { key: 'volume', label: '成交量', align: 'right', render: r => K.bigCell(r.volume) },
        { key: 'turnover', label: '成交额', align: 'right', render: r => K.bigCell(r.turnover) },
        { key: 'mainNet', label: '主力净额', align: 'right', render: r => r.mainNet ? K.moneyCell(r.mainNet) : '<span class="muted">-</span>' }
      ], d.points.slice(-30).reverse()))}`;
    }
    if (vs.sub === 'big') {
      const d = data;
      return `${K.statsGrid([
        { label: '大单买入', value: K.fmtBigSigned(d.buyTotal), sub: 'ZJB', cls: 'up' },
        { label: '大单卖出', value: K.fmtBigSigned(d.sellTotal), sub: 'ZJS', cls: 'down' },
        { label: '大单净额', value: K.fmtBigSigned(d.netTotal), sub: '买入 + 卖出', cls: d.netTotal >= 0 ? 'up' : 'down' }
      ])}
      ${K.section('主力大单分时', '最近 30 个分钟点', K.table([
        { key: 'time', label: '时间' },
        { key: 'bigOrderNet', label: '大单净额', align: 'right', render: r => K.moneyCell(r.bigOrderNet) },
        { key: 'buy', label: '主动买', align: 'right', render: r => K.bigCell(r.buy) },
        { key: 'sell', label: '主动卖', align: 'right', render: r => K.bigCell(r.sell) },
        { key: 'buyOrders', label: '买笔数', align: 'right', render: r => K.fmtInt(r.buyOrders) },
        { key: 'sellOrders', label: '卖笔数', align: 'right', render: r => K.fmtInt(r.sellOrders) }
      ], d.points.slice(-30).reverse()))}`;
    }
    if (vs.sub === 'auction') {
      const d = data;
      return `${K.statsGrid([
        { label: '证券', value: d.name || d.code, sub: d.code, cls: '' },
        { label: '昨收', value: K.fmtPrice(d.preClose), sub: '集合竞价参考', cls: '' },
        { label: '竞价点数', value: d.points.length, sub: '09:15 - 09:25', cls: 'flat' }
      ])}
      ${K.section('集合竞价逐笔', d.note, K.table([
        { key: 'time', label: '时间' },
        { key: 'price', label: '价格', align: 'right', render: r => `<span class="num">${K.fmtPrice(r.price)}</span>` },
        { key: 'volume', label: '成交量', align: 'right', render: r => K.fmtInt(r.volume) },
        { key: 'amount', label: '成交额', align: 'right', render: r => K.bigCell(r.amount) },
        { key: 'side', label: '方向', align: 'center' }
      ], d.points, { emptyText: '当前没有竞价逐笔数据（盘中/收盘后通常为空）' }))}`;
    }
    if (vs.sub === 'gene') {
      const d = data;
      const source = d.source === 'GetStockPanKou_Narrow.YJJY'
        ? 'GetStockPanKou_Narrow.YJJY（备用字段）'
        : 'GetZhangTingGene';
      const summary = d.hasSamples
        ? `历史涨停 ${K.fmtInt(d.limitUpCount)} 次，涨停后次日红盘率 ${K.fmtRate(d.nextRedRate)}，首板封板率 ${K.fmtRate(d.firstSealRate)}、破板率 ${K.fmtRate(d.firstBreakRate)}，连板率 ${K.fmtRate(d.consecutiveRate)}。`
        : '当前接口返回的涨停样本为 0，暂无足够数据形成涨停基因画像。';
      return `${K.statsGrid([
        { label: '历史涨停', value: K.fmtInt(d.limitUpCount), sub: '次', cls: d.limitUpCount > 0 ? 'up' : 'flat' },
        { label: '5% 溢价', value: K.fmtInt(d.premium5Count), sub: '次', cls: d.premium5Count > 0 ? 'up' : 'flat' },
        { label: '次日红盘率', value: K.fmtRate(d.nextRedRate), sub: '涨停后次日', cls: '' },
        { label: '首板封板率', value: K.fmtRate(d.firstSealRate), sub: '首板封住比例', cls: '' },
        { label: '首板破板率', value: K.fmtRate(d.firstBreakRate), sub: '封后开板比例', cls: '' },
        { label: '连板率', value: K.fmtRate(d.consecutiveRate), sub: '晋级连板比例', cls: '' }
      ])}
      ${K.section('涨停基因解读', `${source} · 历史聚合统计`, `
        <div class="callout">${K.esc(summary)}</div>
        <div class="muted small">涨停基因统计个股历史涨停后的表现，不代表当日或未来走势；全 0 表示接口当前没有返回可统计的涨停样本，常见于新股、长期未涨停或数据未覆盖的个股。</div>
      `)}`;
    }
    const q = data;
    return `${K.section('盘口数据', '腾讯实时快照（东方财富备用）', `
      <div class="kv-grid">
        ${[
          ['最新价', K.fmtPrice(q.price)], ['涨跌幅', K.fmtPct(q.changePct)], ['涨跌额', K.fmtNum(q.change)],
          ['今开', K.fmtPrice(q.open)], ['最高', K.fmtPrice(q.high)], ['最低', K.fmtPrice(q.low)],
          ['昨收', K.fmtPrice(q.preClose)], ['成交量', K.fmtBig(q.volume)], ['成交额', K.fmtBig(q.amount)],
          ['换手率', K.fmtRate(q.turnoverRate)], ['量比', K.fmtNum(q.volumeRatio)], ['振幅', K.fmtRate(q.amplitude)],
          ['总市值', K.fmtBig(q.totalCap)], ['流通市值', K.fmtBig(q.floatCap)], ['市盈率', K.fmtNum(q.pe)],
          ['市净率', K.fmtNum(q.pb)], ['每股净资产', K.fmtNum(q.bps)], ['均价', K.fmtPrice(q.avgPrice)],
          ['涨停价', K.fmtPrice(q.limitUp)], ['跌停价', K.fmtPrice(q.limitDown)], ['行业', q.industry || '-'], ['地区', q.region || '-']
        ].map(([k, v]) => `<div><span>${K.esc(k)}</span><b>${K.esc(v)}</b></div>`).join('')}
      </div>`)}`;
  }

  V.stock = async function () {
    const prefs = K.state.prefs;
    const vs = K.state.viewState.stock = K.state.viewState.stock || {
      code: prefs.stockCode || '600519', period: 'day', fq: 'qfq', bars: 300, sub: 'kpl'
    };
    K.setPage('个股行情', '分时、K线、主力大单、集合竞价与涨停基因', 'KAI PAN LA · STOCK');
    const code = vs.code || '600519';
    const back = (K.state.navHistory || []).slice(-1)[0];
    const backTarget = back && back.route && back.route !== 'stock' ? back : null;
    const secid = inferSecid(code);
    const period = periodOf(vs.period);
    const hist = isHistory();
    const d = currentDate();
    K.render(K.loading('正在加载个股行情…'));

    const chartPromise = period.type === 'trend'
      ? K.api('trends', { secid, ndays: period.ndays || 1, date: hist ? d : '' })
      : K.api('kline', { secid, period: period.id, fq: vs.fq, bars: vs.bars, end: hist ? d : '' });
    const subPromise = vs.sub === 'kpl'
      ? K.api('stockIntraday', { code, date: hist ? d : '' })
      : vs.sub === 'big'
        ? K.api('stockBigOrder', { code, date: hist ? d : '' })
        : vs.sub === 'auction'
          ? K.api('stockAuction', { code })
          : vs.sub === 'gene'
            ? K.api('stockLimitGene', { code })
            : K.api('quote', { secid });

    const [quoteRes, chartRes, subRes] = await Promise.allSettled([K.api('quote', { secid }), chartPromise, subPromise]);
    const quote = quoteRes.status === 'fulfilled' ? quoteRes.value : null;
    const chart = chartRes.status === 'fulfilled' ? chartRes.value : null;
    const sub = subRes.status === 'fulfilled' ? subRes.value : null;
    const quick = [
      { code: '600519', name: '贵州茅台' },
      { code: '000001', name: '平安银行' },
      { code: '300750', name: '宁德时代' },
      { code: '002594', name: '比亚迪' },
      { code: '601318', name: '中国平安' }
    ];

    K.render(`
      ${backTarget ? `<div class="stock-back-bar"><button class="btn btn-ghost" id="stockBack">← 返回${K.esc(backTarget.label || '上一页')}</button></div>` : ''}
      <div class="stock-search-bar">
        <div class="search-box">
          <input id="stockSearch" type="text" value="${K.escAttr(code)}" placeholder="输入代码或名称，如 600519 / 贵州茅台" autocomplete="off">
          <button class="btn btn-primary" id="stockSearchBtn">查询</button>
          <div class="search-results" id="searchResults"></div>
        </div>
        <div class="quick-stocks">${quick.map(q => `<button class="tag tag-click" data-quick="${q.code}" data-name="${K.escAttr(q.name)}">${K.esc(q.name)}</button>`).join('')}</div>
        <div class="muted small">${hist ? `历史图表 ${d} · 上方快照仍为实时` : '实时行情'} · 代码自动识别沪/深市场</div>
      </div>

      ${quoteBlock(quote, code)}

      <div class="chart-toolbar">
        <div class="segmented period-tabs">${PERIODS.map(p => `<button class="seg-btn ${p.id === vs.period ? 'active' : ''}" data-period="${p.id}">${p.label}</button>`).join('')}</div>
        <div class="chart-actions">
          ${period.type === 'kline' ? `<label class="inline-field"><span>复权</span><select id="stockFq">
            <option value="qfq" ${vs.fq === 'qfq' ? 'selected' : ''}>前复权</option>
            <option value="hfq" ${vs.fq === 'hfq' ? 'selected' : ''}>后复权</option>
            <option value="none" ${vs.fq === 'none' ? 'selected' : ''}>不复权</option>
          </select></label>
          <label class="inline-field"><span>根数</span><select id="stockBars">
            ${[60, 120, 300, 500].map(n => `<option value="${n}" ${Number(vs.bars) === n ? 'selected' : ''}>${n}</option>`).join('')}
          </select></label>` : ''}
        </div>
      </div>

      <div class="panel chart-panel">
        <div class="panel-body">
          <div class="chart-wrap" style="height:430px"><canvas id="stockChart"></canvas></div>
          <div id="stockChartMeta">${chartRes.status !== 'fulfilled' ? K.errorBox(chartRes.reason, '图表数据加载失败') : chart ? (period.type === 'trend' ? chartMetaTrend(chart) : chartMetaKline(chart)) : K.empty('暂无图表数据')}</div>
        </div>
      </div>

      <div class="toolbar">
        ${K.tabs([
          { id: 'kpl', label: '开盘啦分时' },
          { id: 'big', label: '主力大单' },
          { id: 'auction', label: '集合竞价' },
          { id: 'gene', label: '涨停基因' },
          { id: 'quote', label: '盘口数据' }
        ], vs.sub, 'data-sub')}
        <span class="muted small">开盘啦接口 + 腾讯 K线/分时（东方财富备用）</span>
      </div>
      <div id="stockSub">${subRes.status === 'fulfilled' ? stockSubContent(vs, sub) : K.errorBox(subRes.reason, '明细数据加载失败')}</div>
    `);
    bindCommon();
    document.getElementById('stockBack')?.addEventListener('click', () => K.goBack());

    requestAnimationFrame(() => {
      const canvas = document.getElementById('stockChart');
      if (!canvas || !chart) return;
      if (period.type === 'trend') {
        window.Charts.trend(canvas, chart.points, {
          preClose: chart.preClose,
          multiDay: period.ndays === 5 && !hist,
          title: `${quote?.name || code} · ${period.ndays === 5 && hist ? '历史分时' : period.label}`
        });
      } else {
        window.Charts.kline(canvas, chart.bars, {
          maxBars: Math.min(Number(vs.bars) || 120, chart.bars.length),
          title: `${quote?.name || code} · ${period.label}`
        });
      }
    });

    document.querySelectorAll('[data-period]').forEach(btn => btn.addEventListener('click', () => {
      vs.period = btn.getAttribute('data-period');
      V.stock();
    }));
    document.getElementById('stockFq')?.addEventListener('change', e => { vs.fq = e.target.value; V.stock(); });
    document.getElementById('stockBars')?.addEventListener('change', e => { vs.bars = Number(e.target.value); V.stock(); });
    document.querySelectorAll('[data-sub]').forEach(btn => btn.addEventListener('click', () => {
      vs.sub = btn.getAttribute('data-sub');
      V.stock();
    }));
    document.querySelectorAll('[data-quick]').forEach(btn => btn.addEventListener('click', () => {
      vs.code = btn.getAttribute('data-quick');
      K.state.prefs.stockCode = vs.code;
      K.savePrefs();
      V.stock();
    }));

    const input = document.getElementById('stockSearch');
    const resultBox = document.getElementById('searchResults');
    const runSearch = K.debounce(async () => {
      const kw = input.value.trim();
      if (kw.length < 2) { resultBox.classList.remove('show'); return; }
      try {
        const data = await K.api('search', { keyword: kw });
        if (!data.items.length) { resultBox.innerHTML = '<div class="search-empty">未找到匹配证券</div>'; }
        else {
          resultBox.innerHTML = data.items.map(x => `<button class="search-item" data-search-code="${K.escAttr(x.code)}"><b>${K.esc(x.name)}</b><span>${K.esc(x.code)} · ${K.esc(x.typeName || x.market)}</span></button>`).join('');
          resultBox.querySelectorAll('[data-search-code]').forEach(btn => btn.addEventListener('click', () => {
            vs.code = btn.getAttribute('data-search-code');
            K.state.prefs.stockCode = vs.code;
            K.savePrefs();
            resultBox.classList.remove('show');
            V.stock();
          }));
        }
        resultBox.classList.add('show');
      } catch (_) {
        resultBox.innerHTML = '<div class="search-empty">搜索失败，可直接输入代码</div>';
        resultBox.classList.add('show');
      }
    }, 280);
    input?.addEventListener('input', runSearch);
    const applySearch = () => {
      const raw = input.value.trim();
      const first = resultBox?.querySelector('[data-search-code]');
      const looksLikeCode = /^\d{6}$/.test(raw) || /^(SH|SZ)\d{6}$/i.test(raw);
      const value = looksLikeCode ? raw : first ? first.getAttribute('data-search-code') : raw;
      if (!value) return;
      vs.code = value;
      K.state.prefs.stockCode = vs.code;
      K.savePrefs();
      V.stock();
    };
    input?.addEventListener('keydown', e => {
      if (e.key === 'Enter') applySearch();
    });
    document.getElementById('stockSearchBtn')?.addEventListener('click', applySearch);
    document.addEventListener('click', e => {
      if (resultBox && !e.target.closest('.search-box')) resultBox.classList.remove('show');
    }, { once: true });
  };

  const INDEXES = [
    { code: 'SH000001', name: '上证指数' },
    { code: 'SZ399001', name: '深证成指' },
    { code: 'SZ399006', name: '创业板指' },
    { code: 'SH000688', name: '科创50' },
    { code: 'SH000300', name: '沪深300' },
    { code: 'SH000016', name: '上证50' }
  ];

  V.index = async function () {
    const vs = K.state.viewState.index = K.state.viewState.index || { code: 'SH000001', period: 'trend' };
    K.setPage('指数行情', '指数分时、K线与实时指数列表', 'KAI PAN LA · INDEX');
    const code = vs.code;
    const secid = inferSecid(code);
    const period = periodOf(vs.period);
    const hist = isHistory();
    const d = currentDate();
    K.render(K.loading('正在加载指数行情…'));
    const chartPromise = period.type === 'trend'
      ? K.api('trends', { secid, ndays: period.ndays || 1, date: hist ? d : '' })
      : K.api('kline', { secid, period: period.id, fq: 'qfq', bars: 300, end: hist ? d : '' });
    const [quoteRes, listRes, chartRes, kplRes] = await Promise.allSettled([
      K.api('quote', { secid }), K.api('realtimeIndexList'), chartPromise,
      K.api('indexIntraday', { code, date: hist ? d : '' })
    ]);
    const quote = quoteRes.status === 'fulfilled' ? quoteRes.value : null;
    const list = listRes.status === 'fulfilled' ? listRes.value.items : [];
    const chart = chartRes.status === 'fulfilled' ? chartRes.value : null;
    const kpl = kplRes.status === 'fulfilled' ? kplRes.value : null;

    K.render(`
      <div class="index-switch">${INDEXES.map(x => `<button class="seg-btn ${x.code === code ? 'active' : ''}" data-index="${x.code}">${K.esc(x.name)}</button>`).join('')}</div>
      ${quoteBlock(quote, code)}
      <div class="chart-toolbar">
        <div class="segmented">${PERIODS.filter(p => ['trend', 'five', 'day', 'week', 'month'].includes(p.id)).map(p => `<button class="seg-btn ${p.id === vs.period ? 'active' : ''}" data-period="${p.id}">${p.label}</button>`).join('')}</div>
        <div class="muted small">${hist ? `历史图表 ${d} · 快照为实时` : '实时'}</div>
      </div>
      <div class="panel chart-panel"><div class="panel-body">
        <div class="chart-wrap" style="height:430px"><canvas id="indexChart"></canvas></div>
        <div>${chartRes.status !== 'fulfilled' ? K.errorBox(chartRes.reason, '图表加载失败') : chart ? (period.type === 'trend' ? chartMetaTrend(chart) : chartMetaKline(chart)) : K.empty('暂无图表数据')}</div>
      </div></div>
      <div class="two-col">
        ${K.section('实时指数列表', '开盘啦 RefreshStockList', K.table([
          { key: 'name', label: '指数' },
          { key: 'price', label: '最新', align: 'right', render: r => `<span class="num">${K.fmtPrice(r.price)}</span>` },
          { key: 'changePct', label: '涨跌幅', align: 'right', render: r => K.pctCell(r.changePct) },
          { key: 'turnover', label: '成交额', align: 'right', render: r => K.bigCell(r.turnover) }
        ], list))}
        ${K.section('开盘啦指数分时', kpl ? `${kpl.date} · ${kpl.points.length} 点` : '数据不可用', kpl ? K.table([
          { key: 'time', label: '时间' },
          { key: 'price', label: '价格', align: 'right', render: r => `<span class="num">${K.fmtPrice(r.price)}</span>` },
          { key: 'avg', label: '均价', align: 'right', render: r => `<span class="num">${K.fmtPrice(r.avg)}</span>` },
          { key: 'pct', label: '涨跌幅', align: 'right', render: r => K.pctCell(r.pct) },
          { key: 'volume', label: '成交量', align: 'right', render: r => K.bigCell(r.volume) }
        ], kpl.points.slice(-20).reverse()) : K.errorBox(kplRes.reason, '指数分时加载失败'))}
      </div>
    `);
    bindCommon();
    requestAnimationFrame(() => {
      const canvas = document.getElementById('indexChart');
      if (!canvas || !chart) return;
      if (period.type === 'trend') {
        window.Charts.trend(canvas, chart.points, { preClose: chart.preClose, multiDay: period.ndays === 5 && !hist, title: `${quote?.name || code} · ${period.ndays === 5 && hist ? '历史分时' : period.label}` });
      } else {
        window.Charts.kline(canvas, chart.bars, { maxBars: 120, title: `${quote?.name || code} · ${period.label}` });
      }
    });
    document.querySelectorAll('[data-index]').forEach(btn => btn.addEventListener('click', () => {
      vs.code = btn.getAttribute('data-index');
      V.index();
    }));
    document.querySelectorAll('[data-period]').forEach(btn => btn.addEventListener('click', () => {
      vs.period = btn.getAttribute('data-period');
      V.index();
    }));
  };
})();
