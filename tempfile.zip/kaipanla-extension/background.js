/* 开盘啦盯盘助手 - background service script
 * 统一封装开盘啦 App API 与东方财富行情接口。
 * 所有请求均从扩展后台发出，页面只负责渲染。
 */
'use strict';

const KPL_HOSTS = {
  his: 'apphis.longhuvip.com',
  hq: 'apphwhq.longhuvip.com',
  apphq: 'apphq.longhuvip.com',
  apphwshhq: 'apphwshhq.longhuvip.com',
  article: 'apparticle.longhuvip.com',
  lhb: 'applhb.longhuvip.com'
};

const KPH_HOSTS = {
  realtime: ['apphwshhq.longhuvip.com', 'apphwhq.longhuvip.com', 'apphwshhq.kaipanhong.com'],
  history: ['apphis.longhuvip.com', 'apphis.kaipanhong.com']
};
const KPH_BASE = {
  PhoneOSNew: '1', VerSion: '6.0.6', Token: '0',
  UserID: '0', Red: '1', apiv: 'w45'
};
const KPH_DEVICE = '1a609dd6-b2b8-3bf9-ac40-a77581551454';

/* 腾讯自选股网关：爱盯盘的主行情源。
 * 该域名同时代理 ifzqgtimg 行情接口，国内访问通常比东财快。 */
const TENCENT_PROXY = 'https://proxy.finance.qq.com';
const TENCENT_IFZQ_HOSTS = [`${TENCENT_PROXY}/ifzqgtimg`, 'https://web.ifzq.gtimg.cn'];

/* 这些接口对 User-Agent 敏感；浏览器 fetch 不允许直接设置 UA，
 * 因此通过 webRequest 在请求发出前改写。 */
const UA_MOBILE_KPL = 'Dalvik/2.1.0 (Linux; U; Android 9; SHARK PRS-A0 Build/PQ3A.190605.01141736)';
const UA_MOBILE_ARTICLE = 'Dalvik/2.1.0 (Linux; U; Android 9; 23116PN5BC Build/PQ3A.190605.01141736)';
const UA_MOBILE_KPH = 'Dalvik/2.1.0 (Linux; U; Android 12; 2206123SC Build/c069a49.2)';
const UA_DESKTOP = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
const EXT_ORIGIN = (browser.runtime && typeof browser.runtime.getURL === 'function') ? browser.runtime.getURL('') : '';

function installUserAgentRewrite() {
  try {
    if (!browser.webRequest || !browser.webRequest.onBeforeSendHeaders) return;
    browser.webRequest.onBeforeSendHeaders.addListener(details => {
      try {
        const origin = details.originUrl || details.documentUrl || '';
        if (origin && !origin.startsWith(EXT_ORIGIN)) return {};
        if (!origin && Number(details.tabId) >= 0) return {};
        const host = new URL(details.url).hostname;
        let ua = UA_MOBILE_KPL;
        let referer = '';
        if (host.endsWith('longhuvip.com')) {
          ua = host.startsWith('apparticle.') || host.startsWith('applhb.') ? UA_MOBILE_ARTICLE : UA_MOBILE_KPL;
        } else if (host.endsWith('kaipanhong.com')) {
          ua = UA_MOBILE_KPH;
        } else if (host.endsWith('eastmoney.com')) {
          ua = UA_DESKTOP;
          referer = 'https://quote.eastmoney.com/';
        } else if (host.endsWith('gtimg.cn') || host === 'proxy.finance.qq.com') {
          ua = UA_DESKTOP;
          referer = 'https://gu.qq.com/';
        } else if (host.endsWith('10jqka.com.cn')) {
          ua = UA_DESKTOP;
          referer = 'https://eq.10jqka.com.cn/';
        }
        const headers = (details.requestHeaders || []).filter(h => {
          const name = String(h.name || '').toLowerCase();
          return name !== 'user-agent' && (!referer || name !== 'referer');
        });
        headers.push({ name: 'User-Agent', value: ua });
        if (referer) headers.push({ name: 'Referer', value: referer });
        return { requestHeaders: headers };
      } catch (_) {
        return {};
      }
    }, {
      urls: [
        '*://*.longhuvip.com/*',
        '*://*.kaipanhong.com/*',
        '*://*.eastmoney.com/*',
        '*://*.gtimg.cn/*',
        '*://proxy.finance.qq.com/*',
        '*://*.10jqka.com.cn/*'
      ]
    }, ['blocking', 'requestHeaders']);
  } catch (_) {}
}

installUserAgentRewrite();

const EM_HOSTS = {
  em: 'push2.eastmoney.com',
  emhis: 'push2his.eastmoney.com',
  emdelay: 'push2delay.eastmoney.com',
  emdelay2: 'push2delay2.eastmoney.com',
  search: 'searchapi.eastmoney.com'
};
const EM_FALLBACKS = {
  em: ['push2.eastmoney.com', 'push2delay.eastmoney.com', 'push2delay2.eastmoney.com'],
  emhis: ['push2his.eastmoney.com', '33.push2his.eastmoney.com', '63.push2his.eastmoney.com'],
  emdelay: ['push2delay.eastmoney.com', 'push2delay2.eastmoney.com', 'push2.eastmoney.com'],
  search: ['searchapi.eastmoney.com']
};

const FIXED_DEVICE = 'e78ba169-6c03-3faf-8e5e-a72f8411a8eb';
const TOKEN = '0daffcf404348e2fb714795ba5bdff02';
const USER_ID = '4315515';
const KPL_QUERY = { apiv: 'w42', PhoneOSNew: '1', VerSion: '5.21.0.2' };

const cacheStore = new Map();

function uuid() {
  try {
    if (crypto && typeof crypto.randomUUID === 'function') return crypto.randomUUID();
  } catch (_) {}
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

function pad2(n) { return String(n).padStart(2, '0'); }

function nowHHMM() {
  // 开盘啦实时接口使用北京时间（UTC+8），不依赖本机时区。
  const d = new Date(Date.now() + 8 * 3600 * 1000);
  let minutes = d.getUTCHours() * 60 + d.getUTCMinutes();
  minutes = Math.max(565, Math.min(900, Math.floor(minutes / 5) * 5));
  return `${pad2(Math.floor(minutes / 60))}${pad2(minutes % 60)}`;
}

function shiftHHMM(hhmm, delta) {
  const n = Number(hhmm);
  const total = Math.max(565, Math.min(900, Math.floor(n / 100) * 60 + (n % 100) + delta));
  return `${pad2(Math.floor(total / 60))}${pad2(total % 60)}`;
}

function today() {
  const d = new Date();
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

function compactDate(date) {
  return String(date || today()).replace(/-/g, '').slice(0, 8);
}

function addDays(date, n) {
  const d = new Date(`${date}T12:00:00`);
  d.setDate(d.getDate() + n);
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

function previousWeekday(date) {
  let d = addDays(date, -1);
  let guard = 0;
  while (guard < 7) {
    const w = new Date(`${d}T12:00:00`).getDay();
    if (w !== 0 && w !== 6) return d;
    d = addDays(d, -1);
    guard += 1;
  }
  return d;
}

function dateRange(start, end) {
  let a = start, b = end;
  if (!a || !b) return [a || b || today()];
  if (a > b) [a, b] = [b, a];
  const out = [];
  let cur = a;
  let guard = 0;
  while (cur <= b && guard < 400) {
    out.push(cur);
    cur = addDays(cur, 1);
    guard += 1;
  }
  return out;
}

function num(v, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function round(v, digits = 2) {
  const n = Number(v);
  if (!Number.isFinite(n)) return 0;
  const p = 10 ** digits;
  return Math.round(n * p) / p;
}

function str(v) { return v === null || v === undefined ? '' : String(v); }

function pctNum(v) {
  return round(num(String(v ?? '').replace('%', '')), 2);
}

function cleanParams(params) {
  const out = {};
  for (const [k, v] of Object.entries(params || {})) {
    if (v === undefined || v === null) continue;
    out[k] = Array.isArray(v) ? v.join(',') : String(v);
  }
  return out;
}

async function fetchJson(url, options = {}) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), options.timeout || 20000);
  try {
    const res = await fetch(url, {
      method: options.method || 'GET',
      headers: options.headers || {},
      body: options.body,
      signal: ctrl.signal,
      credentials: 'omit',
      cache: 'no-store',
      redirect: 'follow'
    });
    if (!res.ok) throw new Error(`HTTP ${res.status} ${res.statusText || ''}`.trim());
    const text = await res.text();
    if (!text || !text.trim()) throw new Error('接口返回空内容');
    try {
      return JSON.parse(text);
    } catch (_) {
      throw new Error('接口返回非 JSON 数据');
    }
  } catch (err) {
    if (err && err.name === 'AbortError') throw new Error('请求超时');
    throw err;
  } finally {
    clearTimeout(timer);
  }
}

async function fetchTextRaw(url, options = {}) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), options.timeout || 20000);
  try {
    const res = await fetch(url, {
      method: options.method || 'GET',
      headers: options.headers || {},
      signal: ctrl.signal,
      credentials: 'omit',
      cache: 'no-store',
      redirect: 'follow'
    });
    if (!res.ok) throw new Error(`HTTP ${res.status} ${res.statusText || ''}`.trim());
    const buf = await res.arrayBuffer();
    return new TextDecoder(options.encoding || 'utf-8').decode(buf);
  } catch (err) {
    if (err && err.name === 'AbortError') throw new Error('请求超时');
    throw err;
  } finally {
    clearTimeout(timer);
  }
}

function normalizeKplError(json) {
  if (!json || typeof json !== 'object') return null;
  if (json.errcode === undefined || json.errcode === null) return null;
  if (String(json.errcode) === '0') return null;
  const code = String(json.errcode);
  let msg = json.errmsg || json.msg || '';
  if (code === '1020') msg = msg || '参数出错（可能是非交易日、当天数据尚未生成，或日期/代码不正确）';
  return `开盘啦接口错误 ${code}${msg ? '：' + msg : ''}`;
}

async function kpl(hostKey, params, options = {}) {
  const host = KPL_HOSTS[hostKey];
  if (!host) throw new Error(`未知开盘啦域名: ${hostKey}`);
  const query = options.query === false ? '' : '?' + new URLSearchParams(KPL_QUERY).toString();
  const body = new URLSearchParams();
  if (options.base !== false) {
    body.set('PhoneOSNew', '1');
    body.set('VerSion', '5.21.0.2');
    body.set('apiv', 'w42');
    body.set('DeviceID', options.device || uuid());
  }
  const all = cleanParams({ ...(options.extra || {}), ...params });
  for (const [k, v] of Object.entries(all)) body.set(k, v);

  const schemes = options.scheme === 'http' ? ['http'] : ['https', 'http'];
  let lastErr = null;
  for (const scheme of schemes) {
    const url = `${scheme}://${host}/w1/api/index.php${query}`;
    for (let attempt = 0; attempt < 2; attempt += 1) {
      try {
        const json = await fetchJson(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'User-Agent': hostKey === 'article' || hostKey === 'lhb' ? UA_MOBILE_ARTICLE : UA_MOBILE_KPL
          },
          body: body.toString(),
          timeout: options.timeout || 15000
        });
        const err = normalizeKplError(json);
        if (err) throw new Error(err);
        return json;
      } catch (err) {
        lastErr = err;
        const transient = /fetch failed|other side closed|NetworkError|Load failed|请求超时/i.test(String(err && err.message || ''));
        if (!transient || attempt === 1) break;
        await new Promise(res => setTimeout(res, 350));
      }
    }
  }
  throw lastErr || new Error('开盘啦请求失败');
}

async function kph(hostKey, params, options = {}) {
  const configured = KPH_HOSTS[hostKey];
  const hosts = Array.isArray(configured) ? configured : (configured ? [configured] : []);
  if (!hosts.length) throw new Error(`未知开盘红域名: ${hostKey}`);
  const body = new URLSearchParams();
  for (const [k, v] of Object.entries(KPH_BASE)) body.set(k, v);
  body.set('DeviceID', options.device || KPH_DEVICE);
  for (const [k, v] of Object.entries(cleanParams(params))) body.set(k, v);
  const schemes = options.scheme === 'http' ? ['http'] : ['https', 'http'];
  let lastErr = null;
  for (const host of hosts) {
    for (const scheme of schemes) {
      const url = `${scheme}://${host}/w1/api/index.php`;
      try {
        const json = await fetchJson(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'User-Agent': UA_MOBILE_KPH
          },
          body: body.toString(),
          timeout: options.timeout || 15000
        });
        const err = normalizeKplError(json);
        if (err) throw new Error(err.replace('开盘啦', '开盘红'));
        return json;
      } catch (err) {
        lastErr = err;
      }
    }
  }
  throw lastErr || new Error('开盘红请求失败');
}

async function em(hostKey, path, params, options = {}) {
  const primary = EM_HOSTS[hostKey];
  if (!primary) throw new Error(`未知东方财富域名: ${hostKey}`);
  const hosts = EM_FALLBACKS[hostKey] || [primary];
  const qs = new URLSearchParams(cleanParams(params)).toString();
  const schemes = options.scheme === 'https' ? ['https'] : ['https', 'http'];
  let lastErr = null;
  for (const host of hosts) {
    let hostNetworkError = false;
    for (const scheme of schemes) {
      for (let attempt = 0; attempt < 2; attempt += 1) {
        const url = `${scheme}://${host}${path}${qs ? '?' + qs : ''}`;
        try {
          const json = await fetchJson(url, {
            method: options.method || 'GET',
            headers: { Accept: 'application/json, text/plain, */*' },
            timeout: options.timeout || 12000
          });
          if (json && json.rc !== undefined && Number(json.rc) !== 0 && !json.data) {
            throw new Error(`东方财富接口错误 rc=${json.rc}`);
          }
          return json;
        } catch (err) {
          lastErr = err;
          if (/fetch failed|other side closed|NetworkError|Load failed|请求超时/i.test(String(err && err.message || ''))) {
            hostNetworkError = true;
          }
          if (attempt === 0) await new Promise(res => setTimeout(res, 180));
        }
      }
    }
    // 网络层被阻断时不再轮询备用域名，直接交给腾讯/KPL 兜底。
    if (hostNetworkError) break;
  }
  throw lastErr || new Error('东方财富请求失败');
}

function cached(key, ttl, loader) {
  const hit = cacheStore.get(key);
  const now = Date.now();
  if (hit && now - hit.at < ttl) return hit.value;
  const value = Promise.resolve().then(loader).catch(err => {
    cacheStore.delete(key);
    throw err;
  });
  cacheStore.set(key, { at: now, value });
  return value;
}

function mapLimit(items, limit, fn) {
  const list = [...items];
  const out = new Array(list.length);
  let cursor = 0;
  async function worker() {
    while (cursor < list.length) {
      const index = cursor++;
      out[index] = await fn(list[index], index);
    }
  }
  const workers = Array.from({ length: Math.min(limit, list.length) }, worker);
  return Promise.all(workers).then(() => out);
}

function parseBoardTips(tips) {
  const m = String(tips || '').match(/(\d+)天(\d+)板/);
  return m ? Number(m[2]) : 0;
}

function fmtApiTime(raw) {
  if (raw === undefined || raw === null || raw === '') return '';
  const n = Number(raw);
  if (Number.isFinite(n) && n > 1000000000) {
    const d = new Date(n * 1000);
    return `${pad2(d.getHours())}:${pad2(d.getMinutes())}:${pad2(d.getSeconds())}`;
  }
  if (Number.isFinite(n) && n > 0 && n < 24) {
    let h = Math.floor(n);
    let m = Math.round((n - h) * 60);
    if (m >= 60) { h += Math.floor(m / 60); m %= 60; }
    return `${pad2(h)}:${pad2(m)}:00`;
  }
  return String(raw);
}

function fmtDay(raw) {
  const v = str(raw);
  if (/^\d{8}$/.test(v)) return `${v.slice(0, 4)}-${v.slice(4, 6)}-${v.slice(6, 8)}`;
  return v;
}

function parseTrendPoint(item) {
  if (!Array.isArray(item) || item.length < 4) return null;
  const base = {
    time: str(item[0]),
    price: num(item[1]),
    avg: num(item[2]),
    volume: num(item[3]),
    turnover: item.length >= 7 ? num(item[4]) : 0,
    mainNet: item.length >= 7 ? num(item[5]) : 0,
    flag: item.length >= 7 ? num(item[6]) : num(item[4])
  };
  if (!base.price) return null;
  return base;
}

function ohlc(points) {
  const valid = points.filter(p => p && p.price > 0);
  if (!valid.length) return { open: 0, close: 0, high: 0, low: 0 };
  return {
    open: valid[0].price,
    close: valid[valid.length - 1].price,
    high: Math.max(...valid.map(p => p.price)),
    low: Math.min(...valid.map(p => p.price))
  };
}

/* 历史分时：腾讯证券接口（爱盯盘同款），sign = md5(date=...&stockCode=...) */
const MD5_K = Array.from({ length: 64 }, (_, i) => Math.floor(Math.abs(Math.sin(i + 1)) * 4294967296) >>> 0);
const MD5_S = [
  7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22,
  5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20,
  4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23,
  6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21
];

function md5Hex(input) {
  const bytes = Array.from(new TextEncoder().encode(String(input)));
  const bitLen = bytes.length * 8;
  bytes.push(0x80);
  while (bytes.length % 64 !== 56) bytes.push(0);
  for (let i = 0; i < 4; i += 1) bytes.push((bitLen >>> (8 * i)) & 0xff);
  for (let i = 0; i < 4; i += 1) bytes.push(Math.floor(bitLen / 4294967296) >>> (8 * i) & 0xff);
  let a0 = 0x67452301, b0 = 0xefcdab89, c0 = 0x98badcfe, d0 = 0x10325476;
  const M = new Uint32Array(16);
  for (let off = 0; off < bytes.length; off += 64) {
    for (let i = 0; i < 16; i += 1) {
      const j = off + i * 4;
      M[i] = (bytes[j] | (bytes[j + 1] << 8) | (bytes[j + 2] << 16) | (bytes[j + 3] << 24)) >>> 0;
    }
    let A = a0, B = b0, C = c0, D = d0;
    for (let i = 0; i < 64; i += 1) {
      let F, g;
      if (i < 16) { F = (B & C) | (~B & D); g = i; }
      else if (i < 32) { F = (D & B) | (~D & C); g = (5 * i + 1) % 16; }
      else if (i < 48) { F = B ^ C ^ D; g = (3 * i + 5) % 16; }
      else { F = C ^ (B | ~D); g = (7 * i) % 16; }
      F = (F + A + MD5_K[i] + M[g]) >>> 0;
      A = D; D = C; C = B;
      B = (B + (((F << MD5_S[i]) | (F >>> (32 - MD5_S[i]))) >>> 0)) >>> 0;
    }
    a0 = (a0 + A) >>> 0; b0 = (b0 + B) >>> 0;
    c0 = (c0 + C) >>> 0; d0 = (d0 + D) >>> 0;
  }
  const word = n => [0, 8, 16, 24].map(s => ((n >>> s) & 0xff).toString(16).padStart(2, '0')).join('');
  return word(a0) + word(b0) + word(c0) + word(d0);
}

function tencentCode(secid) {
  const text = String(secid || '').trim();
  const [market, code] = text.split('.');
  if (market === '1') return `sh${code}`;
  if (market === '0') return /^[48]/.test(code) ? `bj${code}` : `sz${code}`;
  if (/^SH/i.test(text)) return `sh${text.slice(2)}`;
  if (/^SZ/i.test(text)) return `sz${text.slice(2)}`;
  return text.toLowerCase();
}

async function getTencentHistoryMinute(secid, date) {
  const sd = inferSecid(secid);
  const code = tencentCode(sd);
  const d = compactDate(date);
  const sign = md5Hex(`date=${d}&stockCode=${code}`).toLowerCase();
  const url = `https://proxy.finance.qq.com/cgi/cgi-bin/generalminute/history/minute?${new URLSearchParams({ date: d, stockCode: code, sign }).toString()}`;
  const json = await fetchJson(url, { timeout: 20000 });
  if (Number(json.code) !== 0 || !json.data) throw new Error(json.msg || '腾讯历史分时请求失败');
  const data = json.data;
  const minList = Array.isArray(data.minList) ? data.minList : [];
  const index = isIndexCode(secid);
  const points = [];
  let prevVolume = 0, prevAmount = 0;
  for (const item of minList) {
    const parts = String(item).trim().split(/\s+/);
    if (parts.length < 4) continue;
    const time = /^\d{4}$/.test(parts[0]) ? `${parts[0].slice(0, 2)}:${parts[0].slice(2)}` : parts[0];
    if (/^[01]\./.test(sd) && time > '15:00') continue;
    const price = num(parts[1]);
    const cumVolume = num(parts[2]);
    const cumAmount = num(parts[3]);
    if (!price) continue;
    const volume = Math.max(0, cumVolume - prevVolume);
    const amount = Math.max(0, cumAmount - prevAmount);
    const avg = index ? price : (cumVolume > 0 ? cumAmount / (cumVolume * 100) : price);
    points.push({
      date: `${d.slice(0, 4)}-${d.slice(4, 6)}-${d.slice(6, 8)}`,
      datetime: `${d.slice(0, 4)}-${d.slice(4, 6)}-${d.slice(6, 8)} ${time}`,
      time,
      price, avg: Number.isFinite(avg) && avg > 0 ? avg : price,
      volume, turnover: amount, mainNet: 0, flag: 0
    });
    prevVolume = cumVolume; prevAmount = cumAmount;
  }
  const o = ohlc(points);
  return {
    secid: sd, code, date: `${d.slice(0, 4)}-${d.slice(4, 6)}-${d.slice(6, 8)}`,
    preClose: num(data.preClose), ...o, points, source: 'tencent'
  };
}

function inferSecid(code) {
  let text = String(code || '').trim().toUpperCase();
  if (!text) return '';
  if (/^\d\./.test(text)) return text;
  if (text.startsWith('SH') || text.startsWith('SZ')) {
    const market = text.startsWith('SH') ? '1' : '0';
    return `${market}.${text.slice(2)}`;
  }
  if (/^\d{6}$/.test(text)) {
    if (/^(6|5|9)/.test(text)) return `1.${text}`;
    return `0.${text}`;
  }
  if (text.startsWith('BK')) return `90.${text.slice(2)}`;
  return text;
}

function isIndexCode(code) {
  const c = String(code || '').toUpperCase();
  return (c.startsWith('SH') && c.endsWith('1')) || (c.startsWith('SZ') && c.includes('399')) ||
    /^(000001|399001|399006|000300|000688|000016|000905|000852)$/.test(c) ||
    /^[01]\.(000001|399001|399006|000300|000688|000016|000905|000852)$/.test(c);
}

/* ============================== 市场数据 ============================== */

async function getDailyRealtime() {
  const d = today();
  return cached(`dailyRealtime:${d}`, 3000, async () => {
    const results = await Promise.allSettled([
      getRealtimeMood(),
      getRealtimeLimit(),
      getRealtimeIndexList({}),
      getRiseFall(),
      getRealtimeAllBoards(),
      getRealtimeSharp()
    ]);
    if (results.every(r => r.status === 'rejected')) {
      throw new Error('实时盘面接口暂时不可用');
    }
    const val = index => results[index].status === 'fulfilled' ? results[index].value : {};
    const mood = val(0), limit = val(1), idx = val(2), rise = val(3), boards = val(4), sharp = val(5);
    const indexes = idx.items || [];
    const sh = indexes.find(x => x.code === 'SH000001') || indexes[0] || {};
    const groups = boards.groups || [];
    const countType = type => (groups.find(g => g.type === type)?.items || []).length;
    const first = countType(1), second = countType(2), third = countType(3);
    const fourth = countType(4), fifth = countType(5);
    return {
      date: d,
      isRealtime: true,
      limitUp: num(mood.limitUp),
      actualLimitUp: num(limit.actualLimitUp) || num(mood.limitUp),
      limitDown: num(mood.limitDown),
      actualLimitDown: num(limit.actualLimitDown) || num(mood.limitDown),
      up: num(mood.up),
      down: num(mood.down),
      index: {
        code: sh.code || 'SH000001',
        name: sh.name || '上证指数',
        price: num(sh.price),
        change: num(sh.change),
        changePct: num(sh.changePct),
        changePctText: sh.changePct != null ? `${sh.changePct}%` : '',
        turnover: num(sh.turnover)
      },
      firstBoard: first,
      secondBoard: second,
      thirdBoard: third,
      fourthPlus: fourth + fifth,
      consecutiveRate: num(boards.statistics?.consecutiveRate),
      yesterdayLimitPerformance: rise.yesterdayLimitPerformance,
      yesterdayBrokenPerformance: rise.yesterdayBrokenPerformance,
      comment: '实时盘面',
      sharpCount: num(sharp.count),
      ladderRaw: [],
      note: '今日历史日线尚未生成，当前使用实时接口汇总；收盘后会切换为完整日线。'
    };
  });
}

async function getDailyData({ date }) {
  const d = date || today();
  if (d === today()) return getDailyRealtime();
  return cached(`daily:${d}`, 8000, async () => {
    const [r1, r2, r3, r4] = await Promise.all([
      kpl('his', { a: 'HisZhangFuDetail', c: 'HisHomeDingPan', Day: d }),
      kpl('his', { a: 'GetZsReal', c: 'StockL2History', Day: d }),
      kpl('his', { a: 'ZhangTingExpression', c: 'HisHomeDingPan', Day: d }),
      kpl('his', { a: 'SharpWithdrawal', c: 'HisHomeDingPan', Day: d })
    ]);
    const info = r1.info || {};
    const sh = (r2.StockList || []).find(x => x.StockID === 'SH000001') || {};
    const zt = Array.isArray(r3.info) ? r3.info : [];
    return {
      date: r1.date || d,
      limitUp: num(info.ZT),
      actualLimitUp: num(info.SJZT),
      limitDown: num(info.DT),
      actualLimitDown: num(info.SJDT),
      up: num(info.SZJS),
      down: num(info.XDJS),
      flat: num(info['0']),
      index: {
        code: 'SH000001',
        name: sh.prod_name || '上证指数',
        price: num(sh.last_px),
        change: num(sh.increase_amount),
        changePct: pctNum(sh.increase_rate),
        changePctText: str(sh.increase_rate),
        turnover: num(sh.turnover)
      },
      firstBoard: num(zt[0]),
      secondBoard: num(zt[1]),
      thirdBoard: num(zt[2]),
      fourthPlus: num(zt[3]),
      consecutiveRate: round(zt[4], 2),
      yesterdayFirstUp: num(zt[5]),
      yesterdayFirstDown: num(zt[6]),
      brokenRate: round(zt[7], 2),
      yesterdayLimitPerformance: round(zt[8], 2),
      yesterdayConsecutivePerformance: round(zt[9], 2),
      yesterdayBrokenPerformance: round(zt[10], 2),
      comment: zt[11] || '',
      sharpCount: num(r4.num),
      ladderRaw: zt
    };
  });
}

async function getDailyRange({ startDate, endDate }) {
  const end = endDate || today();
  const start = startDate || addDays(end, -6);
  return cached(`dailyRange:${start}:${end}`, 60000, async () => {
    const dates = dateRange(start, end).filter(d => {
      const w = new Date(`${d}T12:00:00`).getDay();
      return w >= 1 && w <= 5;
    }).slice(-60);
    const rows = await mapLimit(dates, 3, async d => {
      try { return await getDailyData({ date: d }); }
      catch (_) { return null; }
    });
    return { startDate: start, endDate: end, rows: rows.filter(r => r && r.limitUp > 0) };
  });
}

async function getMarketSentiment({ date }) {
  const d = date || today();
  return cached(`sentiment:${d}`, 8000, async () => {
    const r = await kpl('his', { a: 'HisZhangFuDetail', c: 'HisHomeDingPan', Day: d });
    const i = r.info || {};
    return {
      date: r.date || d,
      limitUp: num(i.ZT), actualLimitUp: num(i.SJZT),
      limitDown: num(i.DT), actualLimitDown: num(i.SJDT),
      up: num(i.SZJS), down: num(i.XDJS), flat: num(i['0'])
    };
  });
}

async function getMarketIndex({ date }) {
  const d = date || today();
  if (d === today()) {
    const r = await getRealtimeIndexList({});
    return { date: d, isRealtime: true, items: r.items };
  }
  return cached(`marketIndex:${d}`, 8000, async () => {
    const r = await kpl('his', { a: 'GetZsReal', c: 'StockL2History', Day: d });
    return {
      date: d,
      items: (r.StockList || []).map(x => ({
        code: str(x.StockID),
        name: str(x.prod_name),
        price: num(x.last_px),
        change: num(x.increase_amount),
        changePct: pctNum(x.increase_rate),
        turnover: num(x.turnover)
      }))
    };
  });
}

async function getLadderSummary({ date }) {
  const d = date || today();
  if (d === today()) {
    const [boards, rise] = await Promise.all([getRealtimeAllBoards(), getRiseFall()]);
    const groups = boards.groups || [];
    const countType = type => (groups.find(g => g.type === type)?.items || []).length;
    return {
      date: d,
      isRealtime: true,
      firstBoard: countType(1),
      secondBoard: countType(2),
      thirdBoard: countType(3),
      fourthPlus: countType(4) + countType(5),
      consecutiveRate: num(boards.statistics?.consecutiveRate),
      yesterdayLimitPerformance: rise.yesterdayLimitPerformance,
      yesterdayBrokenPerformance: rise.yesterdayBrokenPerformance,
      comment: '实时盘面',
      raw: []
    };
  }
  return cached(`ladderSummary:${d}`, 8000, async () => {
    const r = await kpl('his', { a: 'ZhangTingExpression', c: 'HisHomeDingPan', Day: d });
    const a = Array.isArray(r.info) ? r.info : [];
    return {
      date: d,
      firstBoard: num(a[0]),
      secondBoard: num(a[1]),
      thirdBoard: num(a[2]),
      fourthPlus: num(a[3]),
      consecutiveRate: round(a[4], 2),
      yesterdayFirstUp: num(a[5]),
      yesterdayFirstDown: num(a[6]),
      brokenRate: round(a[7], 2),
      yesterdayLimitPerformance: round(a[8], 2),
      yesterdayConsecutivePerformance: round(a[9], 2),
      yesterdayBrokenPerformance: round(a[10], 2),
      comment: a[11] || '',
      raw: a
    };
  });
}

async function getSharpWithdrawal({ date }) {
  const d = date || today();
  if (d === today()) {
    const r = await getRealtimeSharp();
    return {
      date: r.date || d,
      isRealtime: true,
      count: r.count,
      items: (r.items || []).map(x => ({
        code: x.code, name: x.name,
        changePct: x.changePct, drawdownPct: x.pullbackPct, price: x.price
      }))
    };
  }
  return cached(`sharp:${d}`, 8000, async () => {
    const r = await kpl('his', { a: 'SharpWithdrawal', c: 'HisHomeDingPan', Day: d });
    return {
      date: r.date || d,
      count: num(r.num),
      items: (r.info || []).filter(a => Array.isArray(a) && a.length >= 5).map(a => ({
        code: str(a[0]),
        name: str(a[1]),
        changePct: round(a[2], 2),
        drawdownPct: round(a[3], 2),
        price: round(a[4], 2)
      }))
    };
  });
}

async function getNewHigh({ date, startDate }) {
  const d = date || today();
  return cached(`newHigh:${d}:${startDate || ''}`, 60000, async () => {
    const r = await kpl('his', {
      a: 'GetDayNewHigh_W28', st: '360', c: 'StockNewHigh',
      Index: '0', GroupID: 'ALL', Type: '0_0_0_0_0'
    }, { query: false });
    const rows = [];
    for (const item of r.x || []) {
      const parts = String(item).split('_');
      if (parts.length < 3 || !/^\d{8}$/.test(parts[0])) continue;
      rows.push({
        date: `${parts[0].slice(0, 4)}-${parts[0].slice(4, 6)}-${parts[0].slice(6, 8)}`,
        total: num(parts[1]),
        newCount: num(parts[2])
      });
    }
    rows.sort((a, b) => a.date.localeCompare(b.date));
    const single = rows.find(x => x.date === d) || null;
    const filtered = startDate ? rows.filter(x => x.date >= startDate && x.date <= d) : rows.slice(-20);
    return { date: d, startDate: startDate || '', single, latest: rows[rows.length - 1] || null, rows: filtered };
  });
}

/* ============================== 涨停/板块 ============================== */

async function getSectorRanking({ date, index = 0 }) {
  const d = date || today();
  if (d === today()) {
    return cached(`sectorRanking:${d}:rt:${index}`, 3000, async () => {
      const [boards, mood, rise, featured] = await Promise.all([
        getRealtimeAllBoards(),
        getRealtimeMood(),
        getRiseFall().catch(() => ({})),
        getFeaturedSectors({ date: d, zsType: '7', all: true }).catch(() => ({ items: [] }))
      ]);
      const nameMap = new Map((featured.items || []).map(x => [x.code, x.name]));
      const map = new Map();
      for (const group of boards.groups || []) {
        for (const st of group.items || []) {
          const sectorCode = st.sectorCode;
          if (!sectorCode) continue;
          if (!map.has(sectorCode)) {
            map.set(sectorCode, {
              code: sectorCode,
              name: nameMap.get(sectorCode) || st.reason || sectorCode,
              count: 0,
              stocks: []
            });
          }
          const sec = map.get(sectorCode);
          const consecutive = num(st.consecutive) || 1;
          sec.stocks.push({
            code: st.code,
            name: st.name,
            price: st.price,
            sealTime: st.sealTime,
            turnover: st.turnover,
            boardText: consecutive <= 1 ? '首板' : `${consecutive}连板`,
            boardCount: consecutive,
            concepts: st.concepts,
            sealAmount: st.sealAmount,
            floatCap: st.floatCap,
            turnoverRate: null,
            totalCap: st.totalCap,
            theme: st.reason,
            reason: st.reason,
            isFirst: consecutive <= 1
          });
          sec.count = Math.max(sec.count, num(st.sectorLimitCount), sec.stocks.length);
        }
      }
      const sectors = [...map.values()].sort((a, b) => b.count - a.count);
      return {
        date: d,
        isRealtime: true,
        summary: {
          date: d,
          up: num(mood.up),
          down: num(mood.down),
          limitUp: num(mood.limitUp),
          limitDown: num(mood.limitDown),
          ratio: undefined,
          prevRatio: rise.yesterdayLimitPerformance
        },
        sectors: index > 0 ? [] : sectors,
        index
      };
    });
  }
  return cached(`sectorRanking:${d}:${index}`, 8000, async () => {
    const r = await kpl('hq', {
      a: 'GetPlateInfo_w38', st: '100', c: 'DailyLimitResumption',
      Index: str(index), Day: d
    }, { query: false });
    const n = r.nums || {};
    return {
      date: r.date || d,
      summary: {
        date: r.date || d,
        up: num(n.SZJS), down: num(n.XDJS),
        limitUp: num(n.ZT), limitDown: num(n.DT),
        ratio: round(n.ZBL, 2), prevRatio: round(n.yestRase, 2)
      },
      sectors: (r.list || []).map(sec => ({
        code: str(sec.ZSCode),
        name: str(sec.ZSName),
        count: num(sec.num),
        stocks: (sec.StockList || []).filter(a => Array.isArray(a) && a.length >= 19).map(a => ({
          code: str(a[0]),
          name: str(a[1]),
          price: num(a[4]),
          sealTime: fmtApiTime(a[6]),
          turnover: num(a[8]),
          boardText: str(a[9]),
          boardCount: num(a[10]),
          concepts: str(a[11]),
          sealAmount: num(a[12]),
          floatCap: num(a[13]),
          turnoverRate: num(a[14]),
          totalCap: num(a[15]),
          theme: str(a[16]),
          reason: str(a[17]),
          flag: num(a[18]),
          isFirst: /首板/.test(str(a[9]))
        }))
      })),
      index
    };
  });
}

async function getSectorStrength({ code, date }) {
  const d = date || today();
  return cached(`strength:${code}:${d}`, 15000, async () => {
    const isRealtime = d === today();
    const r = await kpl(isRealtime ? 'hq' : 'his', {
      a: 'GetPlate_Info_QJ', c: 'ZhiShuRanking', Date: d, PlateID: String(code)
    }, { query: false });
    const list = r.List || [];
    return {
      code: String(code),
      date: r.Date || d,
      time: fmtApiTime(r.Time),
      strength: list.length >= 2 ? num(list[1]) : null,
      minDay: str(r.MinDay || r.Min || ''),
      max: str(r.Max || ''),
      min: str(r.Min || ''),
      raw: list,
      isRealtime
    };
  });
}

async function getSectorStrengthHistory({ code, startDate, endDate }) {
  const dates = dateRange(startDate, endDate).slice(-120);
  const rows = await mapLimit(dates, 4, async d => {
    try {
      const r = await getSectorStrength({ code, date: d });
      return { date: r.date || d, strength: r.strength, time: r.time, success: r.strength !== null };
    } catch (err) {
      return { date: d, strength: null, time: '', success: false };
    }
  });
  const unique = new Map();
  for (const row of rows) {
    if (row.success && !unique.has(row.date)) unique.set(row.date, row);
  }
  const history = [...unique.values()].sort((a, b) => a.date.localeCompare(b.date));
  return { code: String(code), rows: history, allRows: rows };
}

async function getSectorCapital({ code, date }) {
  const d = date || '';
  return cached(`capital:${code}:${d}`, 5000, async () => {
    const r = await kpl(d ? 'his' : 'hq', {
      a: 'GetPanKou', c: 'ZhiShuL2Data', StockID: String(code), Day: d
    }, { query: false });
    const a = r.pankou || [];
    const turnover = num(a[0]);
    const mainNet = num(a[3]);
    const floatCap = num(a[9]);
    return {
      code: str(r.code || code),
      date: d || today(),
      turnover,
      changePct: num(a[1]),
      extra: num(a[2]),
      mainNet,
      mainSell: num(a[4]),
      netAmount: num(a[5]),
      up: num(a[6]), down: num(a[7]), flat: num(a[8]),
      floatCap, totalCap: num(a[10]),
      strength: num(a[11]),
      turnoverRate: num(a[11]),
      turnoverRateCalc: floatCap > 0 ? round(turnover / floatCap * 100, 2) : 0,
      mainNetPct: turnover > 0 ? round(mainNet / turnover * 100, 2) : 0,
      raw: a
    };
  });
}

async function getSectorIntraday({ code, date }) {
  const d = date || '';
  return cached(`sectorIntraday:${code}:${d}`, 5000, async () => {
    const r = await kpl(d ? 'his' : 'hq', {
      a: 'GetTrendIncremental', c: 'ZhiShuL2Data',
      StockID: String(code), Day: d
    }, { query: false, device: FIXED_DEVICE });
    const points = (r.trend || []).map(parseTrendPoint).filter(Boolean);
    const o = ohlc(points);
    return {
      code: str(r.code || code),
      date: fmtDay(r.day || d || today()),
      preclose: num(r.preclose_px),
      ...o,
      points
    };
  });
}

async function getSectorVolume({ code, date }) {
  const d = date || '';
  return cached(`sectorVolume:${code}:${d}`, 5000, async () => {
    const r = await kpl(d ? 'his' : 'hq', {
      a: 'GetVolTurIncremental', c: 'ZhiShuL2Data',
      StockID: String(code), Day: d
    }, { query: false, device: FIXED_DEVICE });
    return {
      code: str(r.code || code),
      date: fmtDay(r.day || d || today()),
      points: (r.volumeturnover || []).filter(a => Array.isArray(a) && a.length >= 3).map(a => ({
        time: str(a[0]), volume: num(a[1]), turnover: num(a[2]), flag: num(a[3])
      }))
    };
  });
}

async function getSonPlateInfo({ code, date } = {}) {
  const c = String(code || '').trim();
  const d = date || today();
  if (!c) throw new Error('缺少板块代码');
  return cached(`sonPlateInfo:${c}:${d}`, 30000, async () => {
    const r = await kpl('apphq', {
      a: 'SonPlate_Info', c: 'ZhiShuRanking', PlateID: c,
      Date: d, IsShow: '1', Token: TOKEN, UserID: USER_ID
    }, { query: false });
    const items = (r.List || []).filter(Array.isArray).map(a => ({
      code: str(a[0]), name: str(a[1]), strength: num(a[2])
    })).filter(x => x.code && x.name);
    return { code: c, date: d, items };
  });
}

async function getSectorTags({ code } = {}) {
  const c = String(code || '').trim();
  if (!c) throw new Error('缺少板块代码');
  return cached(`sectorTags:${c}`, 60000, async () => {
    const r = await kpl('apphq', {
      a: 'GetGPCPHBTS_Tag', c: 'ZhiShuRanking', PlateID: c
    }, { query: false });
    const items = (r.List || []).filter(x => x && typeof x === 'object').map(x => ({
      id: str(x.TSZB),
      name: str(x.TSZB_N),
      order: num(x.TSZB_Order),
      type: str(x.TSZB_Type),
      open: num(x.IsOpen),
      isNew: num(x.TSZB_New),
      filedType: str(x.Filed_Type)
    })).filter(x => x.id && x.name && x.open === 1);
    return { code: c, items };
  });
}

async function getSectorBoomReasons({ code } = {}) {
  const c = String(code || '').trim();
  if (!c) throw new Error('缺少板块代码');
  return cached(`sectorBoomReasons:${c}`, 120000, async () => {
    const r = await kpl('his', {
      a: 'GetDayBaseFaceListZDEvnArt', c: 'ZhiShuKLine', StockID: c,
      Index: '0', st: '20', Type: '0', IsBoom: '0',
      Token: TOKEN, UserID: USER_ID, Red: '0', apiv: 'w47'
    }, { query: false });
    const rows = (r.List || []).filter(x => x && typeof x === 'object').map(x => ({
      id: num(x.ID), title: str(x.Title), reason: str(x.BoomReason),
      isBoom: num(x.IsBoom), date: str(x.Date), ztNum: num(x.ZTNum),
      strength: num(x.QD), leaders: str(x.LZInfo), leadersChange: str(x.LZInfo_ZF)
    })).filter(x => x.date || x.title || x.reason).sort((a, b) => b.date.localeCompare(a.date));
    return { code: c, count: rows.length, rows };
  });
}

async function getSectorConstituents({ code, date, order = 1, all = false, tag = '' }) {
  const d = date || today();
  const tagId = String(tag || '').replace(/\D/g, '');
  const key = `constituents:${code}:${d}:${order}:${all}:${tagId}`;
  return cached(key, 30000, async () => {
    const pageSize = all ? 1000 : 30;
    const baseParams = {
      a: 'ZhiShuStockList_W8', c: 'ZhiShuRanking',
      Order: str(order), TSZB: '0', st: String(pageSize), old: '1', IsZZ: '0',
      Token: TOKEN, Type: tagId || '6', IsKZZType: '0', UserID: USER_ID,
      PlateID: String(code), TSZB_Type: '0', filterType: '0'
    };
    const pageParams = (queryDate, index) => ({ ...baseParams, Date: queryDate, Index: str(index) });
    const mapStock = a => ({
      code: str(a[0]), name: str(a[1]),
      concepts: str(a[4]), price: num(a[5]), changePct: num(a[6]),
      turnover: num(a[7]), turnoverRate: num(a[8]), floatCap: num(a[10]),
      mainBuy: num(a[11]), mainSell: num(a[12]), mainNet: num(a[13]),
      buyRatio: num(a[14]), sellRatio: num(a[15]), netRatio: num(a[16]),
      volumeRatio: num(a[21]), recentChange: num(a[33]), limitCount: num(a[40]),
      actualTurnover: num(a[53]),
      popularity: num(a[58]), popularityChange: num(a[59]),
      boardText: str(a[23]), leader: str(a[24])
    });

    // 当天成分股：实时接口使用 RStart/REnd，不带 Date；盘中不能传今天的历史日期。
    if (d === today()) {
      const baseEnd = nowHHMM();
      const ends = [baseEnd, shiftHHMM(baseEnd, -5), shiftHHMM(baseEnd, -10)];
      const baseMinutes = Number(baseEnd.slice(0, 2)) * 60 + Number(baseEnd.slice(2));
      // 午休/下午刚开盘时，实时数据只更新到 11:30；补上 1130，避免回退到昨日。
      if (baseMinutes > 690 && baseMinutes < 900) ends.push('1130');
      const uniqueEnds = [...new Set(ends)];
      for (const end of uniqueEnds) {
        try {
          const rtParams = {
            ...baseParams,
            Type: tagId || '-4', Index: '0', RStart: '0925', REnd: end
          };
          delete rtParams.Date;
          const rt = await kpl('apphwshhq', rtParams, { query: false });
          const rows = (rt.list || []).map(mapStock);
          if (rows.length) {
            return {
              code: String(code), date: today(), requestedDate: d,
              isFallback: false, isRealtime: true, constituentRealtime: true,
              updateTime: str(rt.Max || ''),
              stocks: rows, coreStocks: rt.Stocks || [],
              coreCount: (rt.Stocks || []).length,
              totalCount: Math.max(num(rt.Count), rows.length),
              pages: 1
            };
          }
        } catch (_) {}
      }
    }

    let queryDate = d;
    let first = null;
    let lastErr = null;
    try {
      first = await kpl('his', pageParams(queryDate, 0), { query: false });
    } catch (err) {
      lastErr = err;
    }
    const isEmpty = !first || !Array.isArray(first.list) || !first.list.length;
    if (d === today() && isEmpty) {
      let candidate = previousWeekday(d);
      for (let i = 0; i < 5; i += 1) {
        try {
          const prev = await kpl('his', pageParams(candidate, 0), { query: false });
          if (Array.isArray(prev.list) && prev.list.length) {
            first = prev;
            queryDate = candidate;
            break;
          }
        } catch (nextErr) {
          lastErr = nextErr;
        }
        candidate = previousWeekday(candidate);
      }
    }
    if (!first) throw lastErr || new Error('板块成分股加载失败');

    const coreStocks = first.Stocks || [];
    const count = num(first.Count);
    const rows = (first.list || []).map(mapStock);
    if (!all) {
      return {
        code: String(code), date: queryDate, requestedDate: d, isFallback: queryDate !== d,
        updateTime: '',
        stocks: rows, coreStocks, coreCount: coreStocks.length, totalCount: Math.max(count, rows.length), pages: 1
      };
    }
    const seen = new Set(rows.map(x => x.code));
    let page = 1;
    let pages = 1;
    while (page < 30) {
      const r = await kpl('his', pageParams(queryDate, page * pageSize), { query: false });
      const list = (r.list || []).map(mapStock);
      if (!list.length) break;
      for (const item of list) {
        if (!seen.has(item.code)) { seen.add(item.code); rows.push(item); }
      }
      pages = page + 1;
      if (list.length < pageSize) break;
      page += 1;
      await new Promise(res => setTimeout(res, 250));
    }
    return {
      code: String(code), date: queryDate, requestedDate: d, isFallback: queryDate !== d,
      updateTime: '',
      stocks: rows, coreStocks,
      coreCount: coreStocks.length,
      totalCount: Math.max(count, rows.length),
      pages
    };
  });
}

async function getSectorHotStocks({ code, date, tag = '' }) {
  const d = date || today();
  const tagId = String(tag || '').replace(/\D/g, '');
  return cached(`sectorHotStocks:${code}:${d}:${tagId}`, 10000, async () => {
    const [cons, hot, strength, tags, sub] = await Promise.all([
      getSectorConstituents({ code, date: d, order: 1, all: true, tag: tagId }),
      getKplHotRank({ type: '1', limit: 50 }).catch(err => ({ items: [], error: err.message })),
      getSectorStrength({ code, date: d }).catch(err => ({ strength: null, date: d, time: '', error: err.message })),
      getSectorTags({ code }).catch(err => ({ items: [], error: err.message })),
      getSonPlateInfo({ code, date: d }).catch(err => ({ items: [], error: err.message }))
    ]);
    const hotMap = new Map((hot.items || []).map(x => [x.code, x]));
    const stocks = (cons.stocks || []).map(stock => {
      const h = hotMap.get(stock.code);
      return {
        ...stock,
        hotRank: h ? h.rank : null,
        hotRankChange: h ? h.rankChange : null,
        isNewHot: h ? h.isNew : 0,
        hot: !!h
      };
    });
    if (!tagId) {
      stocks.sort((a, b) => {
        const chg = (Number(b.changePct) || 0) - (Number(a.changePct) || 0);
        if (chg !== 0) return chg;
        const ar = a.hotRank == null ? Number.MAX_SAFE_INTEGER : a.hotRank;
        const br = b.hotRank == null ? Number.MAX_SAFE_INTEGER : b.hotRank;
        return ar - br;
      });
    }
    return {
      code: String(code),
      date: d,
      constituentDate: cons.date || d,
      constituentTime: cons.updateTime || '',
      constituentFallback: !!cons.isFallback,
      total: cons.totalCount || stocks.length,
      hotCount: stocks.filter(x => x.hot).length,
      hotDate: hot.date || '',
      hotTime: hot.time || '',
      hotAvailable: (hot.items || []).length > 0,
      sectorStrength: strength.strength,
      strengthDate: strength.date || '',
      strengthTime: strength.time || '',
      tag: tagId,
      tags: tags.items || [],
      subSectors: sub.items || [],
      stocks
    };
  });
}

async function getSectorBidding({ date }) {
  const d = date || '';
  return cached(`bidding:${d}`, 10000, async () => {
    const r = await kpl(d ? 'his' : 'hq', {
      a: 'GetBKJJ_W36', c: 'StockBidYiDong',
      Token: TOKEN, UserID: USER_ID,
      ...(d ? { Day: d } : {})
    }, { query: false });
    const mapList = list => (list || []).filter(a => Array.isArray(a)).map(a => ({
      code: str(a[0]), name: str(a[1]),
      volumeRatio: num(a[2]), anomalyAmount: num(a[3]),
      strength: num(a[4]), mainNet: num(a[5])
    }));
    const list1 = mapList(r.List1), list2 = mapList(r.List2), list3 = mapList(r.List3);
    return {
      date: fmtDay(r.Day || d || today()), isRealtime: !d,
      list1, list2, list3,
      total: list1.length + list2.length + list3.length
    };
  });
}

/* ============================== 连板梯队 ============================== */

async function getMarketLadder({ date }) {
  const d = date || '';
  const realtime = !d || d === today();
  const key = `marketLadder:${realtime ? 'rt' : d}`;
  return cached(key, 5000, async () => {
    if (realtime) {
      const r = await getRealtimeAllBoards();
      const ladderMap = new Map();
      for (const group of r.groups || []) {
        for (const stock of group.items || []) {
          const days = Number(stock.consecutive) || group.type || 1;
          if (!ladderMap.has(days)) ladderMap.set(days, []);
          ladderMap.get(days).push({
            code: stock.code,
            name: stock.name,
            tips: stock.reason || stock.concepts || '',
            consecutiveDays: days
          });
        }
      }
      const ladder = [...ladderMap.entries()]
        .sort((a, b) => b[0] - a[0])
        .map(([days, stocks]) => ({ days, stocks }));
      const total = ladder.reduce((sum, x) => sum + x.stocks.length, 0);
      return {
        date: today(),
        realtime: true,
        stale: false,
        ladder,
        broken: [],
        height: [],
        stats: {
          total,
          maxConsecutive: ladder.length ? ladder[0].days : 0,
          distribution: Object.fromEntries(ladder.map(x => [x.days, x.stocks.length]))
        }
      };
    }
    const r = await kpl('his', {
      a: 'GetYTFP_SCTD', c: 'FuPanLa', Date: d
    }, { query: false });
    const ladderMap = new Map();
    const broken = [], height = [];
    for (const group of r.List || []) {
      const tip = group.Tip === undefined || group.Tip === null || group.Tip === '' ? '1' : String(group.Tip);
      const stocks = (group.Stocks || []).map(st => ({
        code: str(st.StockID), name: str(st.Name), tips: str(st.Tips)
      }));
      if (tip === '0') {
        broken.push(...stocks.map(s => ({ ...s, consecutiveDays: parseBoardTips(s.tips), isBroken: true })));
      } else if (tip === '9') {
        height.push(...stocks.map(s => ({ ...s, consecutiveDays: 0, isHeightMark: true })));
      } else {
        const days = Number(tip) || 1;
        if (!ladderMap.has(days)) ladderMap.set(days, []);
        ladderMap.get(days).push(...stocks.map(s => ({ ...s, consecutiveDays: days })));
      }
    }
    const ladder = [...ladderMap.entries()]
      .sort((a, b) => b[0] - a[0])
      .map(([days, stocks]) => ({ days, stocks }));
    const total = ladder.reduce((sum, x) => sum + x.stocks.length, 0);
    const resultDate = fmtDay(r.Date || d || today());
    return {
      date: resultDate,
      realtime: false,
      stale: false,
      ladder,
      broken,
      height,
      stats: {
        total,
        maxConsecutive: ladder.length ? ladder[0].days : 0,
        distribution: Object.fromEntries(ladder.map(x => [x.days, x.stocks.length]))
      }
    };
  });
}

async function getSectorLadder({ date }) {
  const d = date || '';
  const realtime = !d || d === today();
  return cached(`sectorLadder:${realtime ? 'rt' : d}`, 5000, async () => {
    if (realtime) {
      const sr = await getSectorRanking({ date: today(), index: 0 });
      const sectors = (sr.sectors || []).map(sec => ({
        code: sec.code,
        name: sec.name,
        count: sec.count,
        reason: '',
        broken: [],
        height: [],
        stocks: (sec.stocks || []).map(stock => ({
          code: stock.code,
          name: stock.name,
          tips: stock.boardText || '',
          consecutiveDays: stock.boardCount || 1
        }))
      }));
      sectors.sort((a, b) => b.count - a.count);
      return { date: sr.summary?.date || today(), realtime: true, stale: false, sectors };
    }
    const r = await kpl('his', {
      a: 'GetYTFP_BKHX', c: 'FuPanLa', Date: d
    }, { query: false });
    const sectors = [];
    for (const sec of r.List || []) {
      const stocks = [], broken = [], height = [];
      for (const td of sec.TD || []) {
        const type = td.TDType === undefined || td.TDType === null || td.TDType === '' ? '1' : String(td.TDType);
        for (const st of td.Stock || []) {
          const item = { code: str(st.StockID), name: str(st.StockName), tips: str(st.Tips) };
          if (type === '0') {
            broken.push({ ...item, consecutiveDays: parseBoardTips(item.tips), isBroken: true });
          } else if (type === '9') {
            height.push({ ...item, consecutiveDays: 0, isHeightMark: true });
          } else {
            stocks.push({ ...item, consecutiveDays: Number(type) || 1 });
          }
        }
      }
      if (stocks.length || broken.length || height.length) {
        sectors.push({
          code: str(sec.ZSCode), name: str(sec.ZSName),
          count: num(sec.Count) || stocks.length,
          stocks, broken, height, reason: str(sec.Reason)
        });
      }
    }
    sectors.sort((a, b) => b.count - a.count);
    const resultDate = fmtDay(r.Date || d || today());
    return { date: resultDate, realtime, stale: realtime && resultDate !== today(), sectors };
  });
}

async function getConsecutiveLimitUp({ date, maxPid = 20, full = false }) {
  const d = date || today();
  if (d === today()) {
    return cached(`consecutive:${d}:rt`, 5000, async () => {
      const r = await getRealtimeAllBoards();
      const map = new Map();
      for (const group of r.groups || []) {
        for (const stock of group.items || []) {
          const days = Number(stock.consecutive) || group.type || 1;
          if (!map.has(days)) map.set(days, []);
          map.get(days).push({
            code: stock.code, name: stock.name,
            consecutiveDays: days,
            theme: stock.reason || '',
            concepts: stock.concepts || ''
          });
        }
      }
      const ladder = [...map.entries()].sort((a, b) => b[0] - a[0])
        .map(([days, stocks]) => ({ days, stocks }));
      const max = ladder.length ? ladder[0] : { days: 0, stocks: [] };
      const conceptsOf = stock => String(stock.concepts || '').replace(/\//g, '、').split('、').map(s => s.trim()).filter(Boolean);
      const maxConcepts = [];
      const seen = new Set();
      for (const stock of max.stocks) {
        for (const c of conceptsOf(stock)) {
          if (!seen.has(c)) { seen.add(c); maxConcepts.push(c); }
        }
      }
      return {
        date: d,
        isRealtime: true,
        maxConsecutive: max.days,
        maxConsecutiveStocks: max.stocks.map(s => s.name).join('/'),
        maxConsecutiveConcepts: maxConcepts.join('、'),
        ladder
      };
    });
  }
  return cached(`consecutive:${d}:${maxPid}:${full}`, 20000, async () => {
    const maxPidLimit = Math.min(20, Number(maxPid) || 20);
    let pidTypes = [];
    if (!full) {
      try {
        const ml = await getMarketLadder({ date: d });
        pidTypes = ml.ladder.map(x => x.days).filter(x => x >= 2 && x <= maxPidLimit);
      } catch (_) {}
    }
    if (!pidTypes.length) {
      for (let p = maxPidLimit; p >= 2; p -= 1) pidTypes.push(p);
    }
    pidTypes = [...new Set(pidTypes)].sort((a, b) => b - a);
    const results = await mapLimit(pidTypes, 5, async pid => {
      try {
        const r = await kpl('his', {
          Order: '0', a: 'DailyLimitPerformance', st: '2000', c: 'HisHomeDingPan',
          Index: '0', PidType: str(pid), Type: '4', Day: d
        }, { query: false });
        const arr = (r.info && r.info[0]) || [];
        const stocks = arr.filter(a => Array.isArray(a) && a.length >= 23).map(a => ({
          code: str(a[0]), name: str(a[1]),
          consecutiveDays: num(a[15]) || pid,
          theme: str(a[5]), concepts: str(a[12])
        }));
        return { days: pid, stocks };
      } catch (_) {
        return { days: pid, stocks: [] };
      }
    });
    const ladder = results.filter(x => x.stocks.length).sort((a, b) => b.days - a.days);
    const max = ladder.length ? ladder[0] : { days: 0, stocks: [] };
    const conceptsOf = stock => String(stock.concepts || '').replace(/\//g, '、').split('、').map(s => s.trim()).filter(Boolean);
    const maxConcepts = [];
    const seen = new Set();
    for (const stock of max.stocks) {
      for (const c of conceptsOf(stock)) {
        if (!seen.has(c)) { seen.add(c); maxConcepts.push(c); }
      }
    }
    return {
      date: d,
      maxConsecutive: max.days,
      maxConsecutiveStocks: max.stocks.map(s => s.name).join('/'),
      maxConsecutiveConcepts: maxConcepts.join('、'),
      ladder
    };
  });
}

async function getBrokenLimitUp({ date }) {
  const d = date || today();
  return cached(`broken:${d}`, 15000, async () => {
    const r = await kpl('his', {
      Order: '1', a: 'HisDaBanList', st: '30', c: 'HisHomeDingPan',
      Index: '0', Is_st: '1', PidType: '2', Type: '4',
      FilterMotherboard: '0', Filter: '0', FilterTIB: '0', Day: d, FilterGem: '0'
    }, { query: false, timeout: 60000 });
    return {
      date: d,
      items: (r.list || []).filter(a => Array.isArray(a) && a.length >= 16).map(a => ({
        code: str(a[0]), name: str(a[1]),
        changePct: num(a[4]),
        limitUpTime: fmtApiTime(a[6]), openTime: fmtApiTime(a[7]),
        yesterdayBoardText: str(a[9]), yesterdayConsecutive: num(a[10]),
        sector: str(a[11]), mainNet: num(a[12]),
        turnover: num(a[13]), turnoverRate: num(a[14]),
        floatCap: str(a[15])
      }))
    };
  });
}

/* ============================== 实时盘面 ============================== */

async function getRealtimeMood() {
  return cached('realtimeMood', 3000, async () => {
    const r = await kpl('hq', { a: 'MoodNumCount', c: 'MarketMood' }, { query: false });
    const l = r.list || {};
    return {
      up: num(l.SZJS), down: num(l.XDJS),
      limitUp: num(l.ZTJS), limitDown: num(l.DTJS),
      floatTurnover: num(l.qscln), prevTurnover: num(l.q_zrcs),
      ratio: num(l.bl), color: num(l.color)
    };
  });
}

async function getRealtimeLimit() {
  return cached('realtimeLimit', 3000, async () => {
    const r = await kpl('hq', { a: 'MarketStockZDNum', c: 'HomeDingPan' }, { query: false });
    return {
      actualLimitUp: num(r.actual_limit_up), actualLimitDown: num(r.actual_limit_down),
      limitUp: num(r.limit_up), limitDown: num(r.limit_down)
    };
  });
}

function mapBoardStock(a, boardType) {
  return {
    code: str(a[0]), name: str(a[1]),
    sealTime: fmtApiTime(a[4]),
    reason: str(a[5]),
    turnover: num(a[6]), floatCap: num(a[7]),
    mainBuy: num(a[8]), mainSell: num(a[9]), mainNet: num(a[10]),
    sealAmount: num(a[11]), concepts: str(a[12]), totalCap: num(a[13]),
    amplitude: num(a[14]), consecutive: num(a[15]),
    changePct: num(a[17]),
    sectorCode: str(a[19]), sectorLimitCount: num(a[20]),
    price: num(a[21]), limitPct: num(a[22]),
    boardType
  };
}

async function getRealtimeBoardStocks({ type = 1 }) {
  const boardType = Number(type) || 1;
  return cached(`board:${boardType}`, 3000, async () => {
    const r = await kpl('hq', {
      Order: '0', a: 'DailyLimitPerformance', st: '2000', c: 'HomeDingPan',
      Index: '0', PidType: str(boardType), Type: '4'
    }, { query: false });
    const list = (r.info && r.info[0]) || [];
    return {
      type: boardType,
      date: str(r.info && r.info[1] || today()),
      items: list.filter(a => Array.isArray(a) && a.length >= 23).map(a => mapBoardStock(a, boardType))
    };
  });
}

async function getRealtimeAllBoards() {
  return cached('allBoards', 3000, async () => {
    const groups = await mapLimit([1, 2, 3, 4, 5], 3, async type => {
      try { return await getRealtimeBoardStocks({ type }); }
      catch (_) { return { type, items: [], date: today() }; }
    });
    const total = groups.reduce((sum, g) => sum + g.items.length, 0);
    const first = groups.find(g => g.type === 1)?.items.length || 0;
    return {
      groups,
      statistics: {
        total,
        firstBoard: first,
        consecutiveRate: total > 0 ? round((total - first) / total * 100, 2) : 0
      }
    };
  });
}

async function getRealtimeIndexTrend({ stockId = '801900', time = '15:00' }) {
  return cached(`indexTrend:${stockId}:${time}`, 3000, async () => {
    const r = await kpl('hq', {
      a: 'GetTrendIncremental', c: 'ZhiShuL2Data', StockID: stockId, Time: time, Day: ''
    }, { query: false });
    const trend = (r.trend || []).filter(a => Array.isArray(a) && a.length >= 2);
    const last = trend[trend.length - 1];
    const preclose = num(r.preclose_px);
    const price = last ? num(last[1]) : num(r.lprice);
    const changePct = preclose > 0 ? round((price - preclose) / preclose * 100, 2) : 0;
    return {
      stockId, date: fmtDay(r.day || today()), time,
      value: changePct, changePct, price, preclose,
      points: trend.map(parseTrendPoint).filter(Boolean)
    };
  });
}

async function getRealtimeIndexList({ stockIds } = {}) {
  const ids = Array.isArray(stockIds) && stockIds.length
    ? stockIds
    : ['SH000001', 'SZ399001', 'SZ399006', 'SH000688', 'SH000300'];
  return cached(`indexList:${ids.join(',')}`, 3000, async () => {
    const r = await kpl('hq', {
      a: 'RefreshStockList', c: 'UserSelectStock',
      Token: '', UserID: '', StockIDList: ids.join(',')
    }, { query: false });
    return {
      items: (r.StockList || []).map(x => ({
        code: str(x.StockID), name: str(x.prod_name),
        price: num(x.last_px), changePct: pctNum(x.increase_rate),
        change: num(x.increase_amount), turnover: num(x.turnover)
      }))
    };
  });
}

async function getRealtimeSharp() {
  return cached('realtimeSharp', 3000, async () => {
    const r = await kpl('hq', {
      Order: '0', a: 'SharpWithdrawalList', st: '20', c: 'HomeDingPan', Index: '0', Type: '5'
    }, { query: false });
    return {
      date: str(r.date || today()), count: num(r.num),
      items: (r.info || []).filter(a => Array.isArray(a) && a.length >= 7).map(a => ({
        code: str(a[0]), name: str(a[1]), boardType: str(a[2]), tag: str(a[3]),
        price: num(a[4]), changePct: num(a[5]), pullbackPct: num(a[6])
      }))
    };
  });
}

async function getRiseFall() {
  return cached('riseFall', 3000, async () => {
    const r = await kpl('his', { a: 'RiseFallAnalysis', st: '250', c: 'HisHomeDingPan', Index: '0' }, { query: false });
    const a = (r.info && r.info[0]) || [];
    const [limitTrend, brokenTrend] = await Promise.allSettled([
      getRealtimeIndexTrend({ stockId: '801900', time: '15:00' }),
      getRealtimeIndexTrend({ stockId: '801903', time: '15:00' })
    ]);
    const yesterdayLimit = limitTrend.status === 'fulfilled' ? limitTrend.value : null;
    const yesterdayBroken = brokenTrend.status === 'fulfilled' ? brokenTrend.value : null;
    const mood = await getRealtimeMood().catch(() => ({}));
    return {
      date: today(),
      yesterdayDate: str(a[6] || ''),
      isRealtime: true,
      limitUp: num(mood.limitUp),
      limitDown: num(mood.limitDown),
      broken: num(a[2]),
      blown: num(a[3]),
      blownRate: num(a[4]),
      yesterdayLimitPerformance: yesterdayLimit ? yesterdayLimit.changePct : null,
      yesterdayBrokenPerformance: yesterdayBroken ? yesterdayBroken.changePct : null,
      note: '涨停/跌停为今日实时；炸板/破板及炸板率为上一交易日收盘数据。'
    };
  });
}

/* ============================== 分时 / 大单 ============================== */

async function getStockIntraday({ code, date }) {
  const c = String(code || '').trim();
  const d = date || '';
  const key = `stockIntraday:${c}:${d || 'rt'}`;
  return cached(key, 5000, async () => {
    let r;
    let realtime = false;
    let mainFlow = true;
    if (isIndexCode(c)) {
      if (d) {
        r = await kpl('his', {
          a: 'GetStockTrend', c: 'StockL2History', StockID: c,
          UserID: '0', Token: '0', Day: compactDate(d)
        }, { query: false, device: FIXED_DEVICE });
      } else {
        r = await kpl('hq', {
          a: 'GetZstrend', c: 'StockL2Data', StockID: c,
          UserID: '0', Token: '0'
        }, { query: false, device: FIXED_DEVICE });
        realtime = true;
      }
      mainFlow = false;
    } else if (d) {
      r = await kpl('his', {
        a: 'GetStockTrend', c: 'StockL2History', StockID: c,
        UserID: '0', Token: '0', Day: compactDate(d)
      }, { query: false, device: FIXED_DEVICE });
    } else {
      try {
        r = await kpl('hq', {
          a: 'GetZstrend', c: 'StockL2Data', StockID: c,
          UserID: '0', Token: '0'
        }, { query: false, device: FIXED_DEVICE });
        realtime = true;
        mainFlow = false;
      } catch (_) {
        r = await kpl('his', {
          a: 'GetStockTrend', c: 'StockL2History', StockID: c,
          UserID: '0', Token: '0'
        }, { query: false, device: FIXED_DEVICE });
      }
    }
    const rawTrend = r.trend || [];
    const points = rawTrend.map(item => {
      if (!Array.isArray(item) || item.length < 4) return null;
      if (item.length >= 7 && !isIndexCode(c)) {
        return {
          time: str(item[0]), price: num(item[1]), avg: num(item[2]),
          volume: num(item[3]), turnover: num(item[4]), mainNet: num(item[5]), flag: num(item[6])
        };
      }
      return {
        time: str(item[0]), price: num(item[1]), avg: num(item[2]),
        volume: num(item[3]), turnover: 0, mainNet: 0, flag: num(item[4])
      };
    }).filter(p => p && p.price > 0);
    const o = ohlc(points);
    const preclose = num(r.preclose_px);
    const mainIn = points.reduce((s, p) => s + (p.mainNet > 0 ? p.mainNet : 0), 0);
    const mainOut = points.reduce((s, p) => s + (p.mainNet < 0 ? p.mainNet : 0), 0);
    return {
      code: str(r.code || c), date: fmtDay(r.day || d || today()),
      realtime, mainFlowAvailable: mainFlow && points.some(p => p.mainNet !== 0),
      preclose, ...o,
      changePct: preclose > 0 ? round((o.close - preclose) / preclose * 100, 2) : num(r.px_change_rate),
      totalTurnover: num(r.total_turnover),
      totalMainInflow: mainIn,
      totalMainOutflow: mainOut,
      points
    };
  });
}

async function getStockBigOrder({ code, date }) {
  const c = String(code || '').trim();
  const d = date || '';
  return cached(`bigOrder:${c}:${d || 'rt'}`, 5000, async () => {
    const r = await kpl(d ? 'his' : 'hq', d ? {
      a: 'GetMainMonitor_Trend_w30', c: 'StockL2History', Money: '0', Date: d,
      IsBS: '0', StockID: c, Token: TOKEN, UserID: USER_ID
    } : {
      a: 'GetMainMonitor_Trend_w30', c: 'StockL2Data', Money: '2',
      IsBS: '0', StockID: c, Token: TOKEN, UserID: USER_ID
    }, { query: false, device: FIXED_DEVICE });
    return {
      code: c, date: fmtDay(r.date || d || today()),
      buyTotal: num(r.ZJB), sellTotal: num(r.ZJS), netTotal: num(r.ZJB) + num(r.ZJS),
      points: (r.trend || []).filter(a => Array.isArray(a) && a.length >= 13).map(a => ({
        time: str(a[0]),
        bigOrderNet: num(a[2]),
        buy: num(a[3]), sell: num(a[4]),
        buyOrders: num(a[5]), sellOrders: num(a[6]),
        activeBuy: num(a[9]), passiveBuy: num(a[10]),
        activeSell: num(a[11]), passiveSell: num(a[12])
      }))
    };
  });
}

async function getStockLimitGene({ code } = {}) {
  const c = String(code || '').trim();
  if (!c) throw new Error('缺少股票代码');
  return cached(`stockLimitGene:${c}`, 60000, async () => {
    let r;
    let source = 'GetZhangTingGene';
    try {
      r = await kpl('hq', {
        a: 'GetZhangTingGene', c: 'StockL2Data', StockID: c,
        PhoneOSNew: '1', VerSion: '5.21.0.0', apiv: 'w42'
      }, { query: false, device: FIXED_DEVICE });
    } catch (err) {
      try {
        const fallback = await kpl('hq', {
          a: 'GetStockPanKou_Narrow', c: 'StockL2Data', StockID: c,
          State: '1', Red: '0', PhoneOSNew: '1', VerSion: '6.2.20.2', apiv: 'w47'
        }, { query: false, device: FIXED_DEVICE });
        if (!Array.isArray(fallback.YJJY) || fallback.YJJY.length < 6) throw err;
        r = { ...fallback, List: fallback.YJJY };
        source = 'GetStockPanKou_Narrow.YJJY';
      } catch (_) {
        throw err;
      }
    }
    const list = Array.isArray(r.List) ? r.List : [];
    if (list.length < 6) throw new Error('涨停基因数据为空');
    const vals = list.slice(0, 6).map(v => num(v));
    return {
      code: c,
      source,
      limitUpCount: vals[0],
      premium5Count: vals[1],
      nextRedRate: vals[2],
      firstSealRate: vals[3],
      firstBreakRate: vals[4],
      consecutiveRate: vals[5],
      hasSamples: vals.some(v => v > 0)
    };
  });
}

async function getIndexIntraday({ code, date }) {
  const c = String(code || 'SH000001').trim();
  const d = date || '';
  return cached(`indexIntraday:${c}:${d || 'rt'}`, 5000, async () => {
    let r;
    if (d) {
      r = await kpl('his', {
        a: 'GetStockTrend', c: 'StockL2History', StockID: c,
        UserID: USER_ID, Token: TOKEN, Day: compactDate(d)
      }, { query: false, device: FIXED_DEVICE });
    } else {
      r = await kpl('hq', {
        a: 'GetStockTrendIncremental', c: 'StockL2Data', Type: '1',
        StockID: c, Token: TOKEN, UserID: USER_ID
      }, { query: false, device: FIXED_DEVICE });
    }
    const points = (r.trend || []).map(item => {
      if (!Array.isArray(item) || item.length < 4) return null;
      return { time: str(item[0]), price: num(item[1]), avg: num(item[2]), volume: num(item[3]), flag: num(item[4]) };
    }).filter(p => p && p.price > 0);
    const o = ohlc(points);
    let preclose = num(r.preclose_px);
    if (!preclose && points.length) preclose = points[0].price;
    return {
      code: str(r.code || c), name: str(r.Name || c), date: fmtDay(r.day || d || today()),
      preclose, ...o,
      changePct: preclose > 0 ? round((o.close - preclose) / preclose * 100, 2) : num(r.px_change_rate),
      totalTurnover: num(r.total_turnover),
      points: points.map(p => ({ ...p, pct: preclose > 0 ? round((p.price - preclose) / preclose * 100, 2) : 0 }))
    };
  });
}

async function getStockAuction({ code }) {
  const c = String(code || '').trim();
  return cached(`auction:${c}`, 10000, async () => {
    const secid = inferSecid(c);
    const r = await em('em', '/api/qt/stock/details/get', {
      fields1: 'f1,f2,f3,f4', fields2: 'f51,f52,f53,f54,f55',
      mpi: 1000, ut: 'fa5fd1943c7b386f172d6893dbfba10b',
      fltt: 2, pos: '-0', secid, wbp2u: '|0|0|0|web', _: Date.now()
    });
    const d = r.data || {};
    let details = d.details;
    const points = [];
    const push = arr => {
      if (!Array.isArray(arr) || arr.length < 3) return;
      const time = str(arr[0]);
      if (time < '09:15:00' || time > '09:25:00') return;
      points.push({ time, price: num(arr[1]), volume: num(arr[2]), amount: num(arr[3]), side: str(arr[4]) });
    };
    if (typeof details === 'string') {
      for (const row of details.split(';')) push(row.split(','));
    } else if (Array.isArray(details)) {
      details.forEach(push);
    }
    return {
      code: secid, name: str(d.name || c), date: today(),
      preClose: num(d.preClose || d.prePrice),
      points,
      note: '东方财富分时明细仅返回最近交易日数据，历史日期仅作标注。'
    };
  });
}

/* ============================== 龙虎榜 / ETF / 资讯 ============================== */

async function getLhbList({ date, index = 0, pageSize = 500 }) {
  const d = date || today();
  return cached(`lhb:${d}:${index}:${pageSize}`, 15000, async () => {
    const r = await kpl('lhb', {
      a: 'GetStockList', st: str(pageSize), c: 'LongHuBang', Token: TOKEN,
      Time: d, Index: str(index), Type: '2', UserID: USER_ID
    }, { query: false, device: FIXED_DEVICE });
    return {
      date: str(r.Time || d),
      items: (r.list || []).map(x => ({
        code: str(x.ID), name: str(x.Name),
        changePct: pctNum(x.IncreaseAmount),
        reasonType: str(x.D3),
        buyAmount: num(x.BuyIn), joinNum: num(x.JoinNum),
        turnover: num(x.Turnover), floatCap: num(x.CircPrice),
        amplitude: num(x.Amplitude), turnoverRatio: num(x.TurnoverRatio),
        totalCap: num(x.Capitalization)
      }))
    };
  });
}

async function getLhbDetail({ code, date }) {
  const d = date || today();
  return cached(`lhbDetail:${code}:${d}`, 20000, async () => {
    const r = await kpl('lhb', {
      c: 'Stock', a: 'GetNewOneStockInfo', Type: '0', Time: d,
      StockID: str(code), UserID: USER_ID, Token: TOKEN
    }, { query: true, device: FIXED_DEVICE });
    const mapSeat = x => ({
      id: str(x.ID), name: str(x.Name),
      buy: num(x.Buy), sell: num(x.Sell), rank: num(x.PX),
      groupId: str(x.GroupID)
    });
    return {
      code: str(code), name: str(r.Name), date: str(r.Time || d),
      price: num(r.CurPrice), changePct: num(r.QuoteChange),
      turnoverRatio: num(r.TurnoverRatio), circulation: num(r.Circulation),
      buyIn: num(r.BuyIn), turnover: num(r.Turnover),
      moreTurnover: num(r.MoreTurnover),
      onListCount: num(r.ToBusinessCount), onListStart: num(r.lbStart),
      onTimeList: r.OnTimeList || [],
      groups: (r.List || []).map(g => ({
        upReason: str(g.UpReason),
        buyTotal: num(g.BuyTotal), sellTotal: num(g.SellTotal),
        buyList: (g.BuyList || []).map(mapSeat),
        sellList: (g.SellList || []).map(mapSeat)
      }))
    };
  });
}

async function getEtfRanking({ date, order = 1, index = 0 }) {
  const d = date || '';
  return cached(`etf:${d}:${order}:${index}`, 10000, async () => {
    const r = await kpl('hq', {
      Order: str(order), a: 'ETFStockRanking', st: '30', c: 'NewStockRanking',
      Filtration: '0', Token: TOKEN, Index: str(index), PidType: '0',
      Type: '1', UserID: USER_ID, ...(d ? { Date: d } : {})
    }, { query: false });
    const map = a => ({
      code: str(a[0]), name: str(a[1]), price: num(a[2]), changePct: num(a[3]),
      turnover: num(a[4]), volumeRatio: num(a[5]),
      prevAmountChange: num(a[6]), prevShareChange: num(a[7]), prevChangeRatio: num(a[8]),
      week: num(a[9]), month: num(a[10]), month3: num(a[11]), month6: num(a[12]),
      totalCap: num(a[13]), ytd: num(a[19])
    });
    return {
      date: d || today(), isRealtime: !d,
      items: (r.info || []).map(map),
      totalCount: num(r.Count),
      pageCount: (r.info || []).length
    };
  });
}

async function getAllEtfRanking({ date, order = 1, maxPages = 30 }) {
  const d = date || '';
  return cached(`etfAll:${d}:${order}:${maxPages}`, 20000, async () => {
    const all = [];
    const seen = new Set();
    let pages = 0;
    for (let page = 0; page < Math.min(30, maxPages); page += 1) {
      const r = await getEtfRanking({ date: d, order, index: page * 30 });
      if (!r.items.length) break;
      for (const item of r.items) {
        if (!seen.has(item.code)) { seen.add(item.code); all.push(item); }
      }
      pages = page + 1;
      if (r.items.length < 30) break;
      await new Promise(res => setTimeout(res, 300));
    }
    return { date: d || today(), isRealtime: !d, items: all, totalCount: all.length, pages };
  });
}

async function getPlateNews({ plateId, index = 0, pageSize = 30 }) {
  return cached(`news:${plateId}:${index}:${pageSize}`, 15000, async () => {
    const r = await kpl('article', {
      a: 'GetPlateNewsList', st: str(pageSize), c: 'APPComplexData',
      Index: str(index), PlateID: str(plateId)
    }, { query: false });
    return {
      plateId: str(plateId),
      items: (r.List || []).map(x => {
        const t = num(x.Time);
        const date = t ? new Date(t * 1000) : null;
        return {
          id: str(x.ID), title: str(x.Title), content: str(x.Content),
          time: t,
          datetime: date ? `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())} ${pad2(date.getHours())}:${pad2(date.getMinutes())}` : '',
          type: num(x.Type), typeName: num(x.Type) === 1 ? '快讯' : '新闻'
        };
      })
    };
  });
}

/* ============================== 东方财富 K线 / 分时 / 行情 ============================== */

function parseTencentQuoteFields(a, sd) {
  if (!Array.isArray(a) || a.length < 50) throw new Error('腾讯行情字段不足');
  const price = num(a[3]), preClose = num(a[4]), open = num(a[5]);
  const high = num(a[33]), low = num(a[34]);
  const volume = num(a[36]) || num(a[6]);
  const amountWan = num(a[37]);
  const floatCapYi = num(a[44]);
  const totalCapYi = num(a[45]);
  return {
    secid: sd, code: str(a[2]), name: str(a[1]),
    price, changePct: num(a[32]), change: num(a[31]),
    open, high, low, preClose,
    volume, amount: amountWan * 10000,
    turnoverRate: num(a[38]), volumeRatio: num(a[49]),
    amplitude: num(a[43]),
    totalCap: totalCapYi * 1e8, floatCap: floatCapYi * 1e8,
    totalShares: 0, floatShares: 0,
    pe: num(a[39]), pb: num(a[46]), bps: 0,
    avgPrice: num(a[51]), limitUp: num(a[47]), limitDown: num(a[48]),
    industry: '', region: '', concepts: [], source: 'tencent'
  };
}

async function getTencentProxyQuote(secid) {
  const sd = inferSecid(secid);
  const code = tencentCode(sd);
  const params = { code, ktype: 'day', limit: '1' };
  if (!isIndexCode(sd)) params.fqtype = 'qfq';
  const url = `${TENCENT_PROXY}/cgi/cgi-bin/stockinfoquery/kline/app/get?${new URLSearchParams(params).toString()}`;
  const r = await fetchJson(url, { timeout: 12000 });
  if (Number(r.code) !== 0) throw new Error(r.message || r.msg || '腾讯行情请求失败');
  const fields = r.data && r.data.qt && r.data.qt.fields;
  return parseTencentQuoteFields(fields, sd);
}

async function getTencentQuote(secid) {
  const sd = inferSecid(secid);
  const code = tencentCode(sd);
  const text = await fetchTextRaw(`https://qt.gtimg.cn/q=${code}`, { timeout: 12000, encoding: 'gbk' });
  const m = text.match(/="([^"]*)"/);
  if (!m) throw new Error('腾讯行情返回格式异常');
  return parseTencentQuoteFields(m[1].split('~'), sd);
}

async function getTencentQuotes(secids) {
  const list = (Array.isArray(secids) ? secids : String(secids || '').split(',')).map(inferSecid).filter(Boolean);
  const items = [];
  for (const sd of list) {
    try { items.push(await getTencentQuote(sd)); } catch (_) {}
  }
  return { items };
}

async function getTencentKline(secid, period, fq, bars, end) {
  const sd = inferSecid(secid);
  const code = tencentCode(sd);
  const count = Math.max(1, Math.min(1999, Number(bars) || 120));
  const fqq = fq === 'hfq' ? 'hfq' : fq === 'none' ? '' : 'qfq';
  let rows = [], name = '';
  if (['day', 'week', 'month', 'year'].includes(period)) {
    const endParam = end ? fmtDay(end) : '';
    const url = `https://web.ifzq.gtimg.cn/appstock/app/fqkline/get?${new URLSearchParams({
      param: `${code},${period},,${endParam},${count},${fqq}`
    }).toString()}`;
    const r = await fetchJson(url, { timeout: 15000 });
    if (Number(r.code) !== 0 || !r.data || !r.data[code]) throw new Error(r.msg || '腾讯K线请求失败');
    const node = r.data[code];
    name = node.qt && node.qt[code] ? str(node.qt[code][1]) : '';
    rows = node[`${fqq}${period}`] || node[period] || [];
  } else if (['1m', '5m', '15m', '30m', '60m', '120m'].includes(period)) {
    const ktype = `m${period.replace('m', '')}`;
    const url = `https://ifzq.gtimg.cn/appstock/app/kline/mkline?${new URLSearchParams({
      param: `${code},${ktype},,${count}`
    }).toString()}`;
    const r = await fetchJson(url, { timeout: 15000 });
    if (Number(r.code) !== 0 || !r.data || !r.data[code]) throw new Error(r.msg || '腾讯分钟K线请求失败');
    const node = r.data[code];
    name = node.qt && node.qt[code] ? str(node.qt[code][1]) : '';
    rows = node[ktype] || [];
  } else {
    throw new Error(`腾讯K线不支持周期 ${period}`);
  }
  let prevClose = 0;
  const out = [];
  for (const row of rows) {
    if (!Array.isArray(row) || row.length < 6) continue;
    let date = str(row[0]);
    if (/^\d{12}$/.test(date)) date = `${date.slice(0, 4)}-${date.slice(4, 6)}-${date.slice(6, 8)} ${date.slice(8, 10)}:${date.slice(10, 12)}`;
    const open = num(row[1]), close = num(row[2]), high = num(row[3]), low = num(row[4]), volume = num(row[5]);
    if (![open, close, high, low].every(Number.isFinite)) continue;
    const changePct = prevClose > 0 ? round((close - prevClose) / prevClose * 100, 2) : num(row[7]);
    prevClose = close;
    out.push({ date, open, close, high, low, volume, amount: 0, changePct });
  }
  if (!out.length) throw new Error('腾讯K线未返回数据');
  return { secid: sd, code, name, decimal: 2, period, fq, bars: out, source: 'tencent' };
}

async function getTencentRealtimeTrends(secid, ndays = 1) {
  const sd = inferSecid(secid);
  const code = tencentCode(sd);
  const path = Number(ndays) === 5 ? 'day/query' : 'minute/query';
  const attempts = TENCENT_IFZQ_HOSTS.map(async base => {
    const url = `${base}/appstock/app/${path}?${new URLSearchParams({ code, _: Date.now() }).toString()}`;
    const candidate = await fetchJson(url, { timeout: 10000 });
    if (Number(candidate.code) !== 0 || !candidate.data || !candidate.data[code]) {
      throw new Error(candidate.msg || '腾讯分时请求失败');
    }
    return candidate;
  });
  let r;
  try {
    r = await Promise.any(attempts);
  } catch (_) {
    throw new Error('腾讯分时请求失败');
  }
  const node = r.data[code];
  const preClose = node.qt && node.qt[code] ? num(node.qt[code][4]) : 0;
  const groups = [];
  if (Array.isArray(node.data)) {
    // 腾讯 day/query 按“最新日期在前”返回，统一按日期升序拼接。
    const days = [...node.data].sort((a, b) => str(a && a.date).localeCompare(str(b && b.date)));
    for (const day of days) {
      if (day && Array.isArray(day.data)) groups.push({ date: str(day.date), list: day.data });
    }
  } else if (node.data && Array.isArray(node.data.data)) {
    groups.push({ date: str(node.data.date), list: node.data.data });
  }
  const points = [];
  for (const group of groups) {
    let date = group.date;
    if (/^\d{8}$/.test(date)) date = `${date.slice(0, 4)}-${date.slice(4, 6)}-${date.slice(6, 8)}`;
    let prevVolume = 0, prevAmount = 0;
    for (const item of group.list) {
      const a = String(item).trim().split(/\s+/);
      if (a.length < 3) continue;
      const t = a[0];
      const time = /^\d{4}$/.test(t) ? `${t.slice(0, 2)}:${t.slice(2)}` : t;
      if (/^[01]\./.test(sd) && time > '15:00') continue;
      const price = num(a[1]);
      const cumVolume = num(a[2]);
      const cumAmount = num(a[3]);
      if (!price) continue;
      const volume = Math.max(0, cumVolume - prevVolume);
      const amount = Math.max(0, cumAmount - prevAmount);
      const avg = isIndexCode(sd) ? price : (cumVolume > 0 ? cumAmount / (cumVolume * 100) : price);
      points.push({
        date, datetime: `${date} ${time}`, time, price,
        avg: Number.isFinite(avg) && avg > 0 ? avg : price,
        volume, turnover: amount, mainNet: 0, flag: 0
      });
      prevVolume = cumVolume; prevAmount = cumAmount;
    }
  }
  if (!points.length) throw new Error('腾讯分时未返回数据');
  return { secid: sd, code, name: node.qt && node.qt[code] ? str(node.qt[code][1]) : '', date: points[points.length - 1].date, days: Number(ndays) === 5 ? 5 : 1, preClose, points, source: 'tencent' };
}

const KLINE_PERIODS = {
  '1m': 1, '5m': 5, '15m': 15, '30m': 30, '60m': 60, '120m': 120,
  day: 101, week: 102, month: 103, quarter: 104, year: 106
};

const TENCENT_KLINE_PERIODS = {
  '1m': 'm1', '5m': 'm5', '15m': 'm15', '30m': 'm30', '60m': 'm60', '120m': 'm120',
  day: 'day', week: 'week', month: 'month', year: 'year'
};

function fmtTencentKlineDate(raw) {
  const v = str(raw);
  if (/^\d{12}$/.test(v)) return `${v.slice(0, 4)}-${v.slice(4, 6)}-${v.slice(6, 8)} ${v.slice(8, 10)}:${v.slice(10, 12)}`;
  if (/^\d{8}$/.test(v)) return `${v.slice(0, 4)}-${v.slice(4, 6)}-${v.slice(6, 8)}`;
  return v;
}

async function getTencentProxyKline(secid, period, fq, bars, end) {
  const sd = inferSecid(secid);
  const isQuarter = period === 'quarter';
  const ktype = isQuarter ? 'month' : TENCENT_KLINE_PERIODS[period];
  if (!ktype) throw new Error(`腾讯行情不支持周期 ${period}`);
  const code = tencentCode(sd);
  const limit = isQuarter
    ? Math.min(2000, Math.max(12, (Number(bars) || 120) * 3 + 3))
    : Math.max(1, Math.min(2000, Number(bars) || 120));
  const params = { code, ktype, limit: String(limit) };
  if (fq !== 'none') params.fqtype = fq === 'hfq' ? 'hfq' : 'qfq';
  if (end) params.toDate = fmtDay(end);
  const url = `${TENCENT_PROXY}/cgi/cgi-bin/stockinfoquery/kline/app/get?${new URLSearchParams(params).toString()}`;
  const r = await fetchJson(url, { timeout: 15000 });
  if (Number(r.code) !== 0) throw new Error(r.message || r.msg || '腾讯K线请求失败');
  const nodes = r.data && r.data.nodes;
  if (!Array.isArray(nodes) || !nodes.length) throw new Error('腾讯K线未返回数据');
  const minute = ktype.startsWith('m');
  let prevClose = 0;
  const out = [];
  for (const node of nodes) {
    const open = num(node.open), close = num(node.last), high = num(node.high), low = num(node.low);
    if (![open, close, high, low].every(Number.isFinite)) continue;
    const rawVolume = num(node.volume);
    const volume = minute ? rawVolume : round(rawVolume / 100, 2);
    const changePct = prevClose > 0 ? round((close - prevClose) / prevClose * 100, 2) : 0;
    prevClose = close;
    out.push({
      date: fmtTencentKlineDate(node.date),
      open, close, high, low, volume,
      amount: num(node.amount), changePct
    });
  }
  if (isQuarter) {
    const quarters = [];
    for (const bar of out) {
      const month = Number(bar.date.slice(5, 7));
      if (!month) continue;
      const qKey = `${bar.date.slice(0, 4)}-Q${Math.ceil(month / 3)}`;
      const last = quarters[quarters.length - 1];
      if (!last || last.key !== qKey) {
        quarters.push({ key: qKey, date: bar.date, open: bar.open, close: bar.close, high: bar.high, low: bar.low, volume: bar.volume, amount: bar.amount });
      } else {
        last.date = bar.date;
        last.close = bar.close;
        last.high = Math.max(last.high, bar.high);
        last.low = Math.min(last.low, bar.low);
        last.volume += bar.volume;
        last.amount += bar.amount;
      }
    }
    out.length = 0;
    let prevQuarter = 0;
    for (const q of quarters) {
      const changePct = prevQuarter > 0 ? round((q.close - prevQuarter) / prevQuarter * 100, 2) : 0;
      prevQuarter = q.close;
      out.push({
        date: q.date, open: q.open, close: q.close, high: q.high, low: q.low,
        volume: round(q.volume, 2), amount: q.amount, changePct
      });
    }
  }
  if (!out.length) throw new Error('腾讯K线未返回有效数据');
  const fields = r.data.qt && r.data.qt.fields;
  const resultBars = isQuarter ? out.slice(-Math.max(1, Math.min(2000, Number(bars) || 120))) : out;
  return {
    secid: sd, code: str(r.data.stockCode || code),
    name: Array.isArray(fields) ? str(fields[1]) : '',
    decimal: 2, period, fq, bars: resultBars, source: 'tencent'
  };
}

function hhmmMinutes(value) {
  const m = /^(\d{2}):(\d{2})$/.exec(String(value || ''));
  return m ? Number(m[1]) * 60 + Number(m[2]) : NaN;
}

async function getTencentHistoryKline(secid, period, fq, bars, end) {
  const interval = { '1m': 1, '5m': 5, '15m': 15, '30m': 30, '60m': 60, '120m': 120 }[period];
  if (!interval) throw new Error(`腾讯历史分钟K线不支持周期 ${period}`);
  const sd = inferSecid(secid);
  const data = await getTencentHistoryMinute(sd, end);
  const points = data.points || [];
  if (!points.length) throw new Error('腾讯历史分钟数据为空');
  const out = [];
  if (interval === 1) {
    for (const p of points) {
      out.push({
        date: p.datetime,
        open: p.price, close: p.price, high: p.price, low: p.price,
        volume: num(p.volume), amount: num(p.turnover), changePct: 0
      });
    }
  } else {
    const groups = new Map();
    for (const p of points) {
      const minutes = hhmmMinutes(p.time);
      if (!Number.isFinite(minutes)) continue;
      const session = minutes <= 690 ? 'am' : 'pm';
      const start = session === 'am' ? 570 : 780;
      // 腾讯分钟K线按区间结束时间标注（09:35/11:30/13:05/15:00）。
      const bucket = Math.max(0, Math.ceil((minutes - start) / interval) - 1);
      const key = `${p.date}|${session}|${bucket}`;
      let bar = groups.get(key);
      if (!bar) {
        bar = {
          date: p.datetime, open: p.price, close: p.price, high: p.price, low: p.price,
          volume: num(p.volume), amount: num(p.turnover)
        };
        groups.set(key, bar);
      } else {
        bar.date = p.datetime;
        bar.close = p.price;
        bar.high = Math.max(bar.high, p.price);
        bar.low = Math.min(bar.low, p.price);
        bar.volume += num(p.volume);
        bar.amount += num(p.turnover);
      }
    }
    for (const bar of groups.values()) out.push({ ...bar, changePct: 0 });
  }
  if (!out.length) throw new Error('腾讯历史分钟K线为空');
  let prev = 0;
  for (const bar of out) {
    bar.changePct = prev > 0 ? round((bar.close - prev) / prev * 100, 2) : 0;
    prev = bar.close;
  }
  const limit = Math.max(1, Math.min(2000, Number(bars) || 120));
  return {
    secid: sd, code: data.code || '', name: '', decimal: 2,
    period, fq, bars: out.slice(-limit), source: 'tencent'
  };
}

async function getKline({ secid, period = 'day', fq = 'qfq', bars = 1999, end }) {
  const sd = inferSecid(secid);
  const klt = KLINE_PERIODS[period] || 101;
  const fqt = fq === 'none' ? 0 : fq === 'hfq' ? 2 : 1;
  const e = end ? compactDate(end) : '';
  const key = `kline:${sd}:${period}:${fq}:${bars}:${e}`;
  return cached(key, 5000, async () => {
    const minute = ['1m', '5m', '15m', '30m', '60m', '120m'].includes(period);
    // 腾讯分钟K线接口的 toDate 不生效；历史分钟K线改由腾讯历史分时聚合。
    const historyMinute = minute && !!e;
    const eastmoney = async () => {
      const params = {
        secid: sd, klt, fqt, iscca: 1,
        fields1: 'f1,f2,f3,f4,f5',
        fields2: 'f51,f52,f53,f54,f55,f56,f57,f59',
        ut: 'f057cbcbce2a86e2866ab8877db1d059',
        forcect: 1, lmt: Math.max(1, Math.min(1999, Number(bars) || 1999))
      };
      if (e) params.end = e;
      const r = await em('emhis', '/api/qt/stock/kline/get', params);
      const d = r.data || {};
      const barsOut = (d.klines || []).map(line => {
        const a = String(line).split(',');
        if (a.length < 8) return null;
        return {
          date: a[0], open: num(a[1]), close: num(a[2]), high: num(a[3]),
          low: num(a[4]), volume: num(a[5]), amount: num(a[6]), changePct: num(a[7])
        };
      }).filter(Boolean);
      if (!barsOut.length) throw new Error('东方财富K线未返回数据');
      return {
        secid: sd, code: str(d.code), name: str(d.name), decimal: num(d.decimal, 2),
        period, fq, bars: barsOut, source: 'eastmoney'
      };
    };
    if (historyMinute) {
      try { return await getTencentHistoryKline(sd, period, fq, bars, end); } catch (_) {}
    }
    if (!historyMinute) {
      try { return await getTencentProxyKline(sd, period, fq, bars, end); } catch (_) {}
    }
    try {
      return await eastmoney();
    } catch (err) {
      if (!historyMinute) {
        try { return await getTencentKline(sd, period, fq, bars, end); } catch (_) {}
      }
      throw err;
    }
  });
}

async function getTrends({ secid, ndays = 1, date }) {
  const sd = inferSecid(secid);
  const days = Number(ndays) === 5 ? 5 : 1;
  const d = date || '';
  const key = `trends:${sd}:${days}:${d}`;
  return cached(key, 4000, async () => {
    if (d) {
      try {
        const tencent = await getTencentHistoryMinute(sd, d);
        return { ...tencent, name: tencent.name || '', days: 1 };
      } catch (err) {
        const code = sd.startsWith('1.') ? `SH${sd.slice(2)}` : sd.startsWith('0.') ? `SZ${sd.slice(2)}` : sd;
        const kplData = isIndexCode(code)
          ? await getIndexIntraday({ code, date: d })
          : await getStockIntraday({ code, date: d });
        return {
          secid: sd, code, name: '', date: d, days: 1,
          preClose: kplData.preclose || 0,
          points: kplData.points || [], source: 'kpl',
          fallbackError: err.message
        };
      }
    }
    // 腾讯自选股网关为主源；东财作为第二源。
    try { return await getTencentRealtimeTrends(sd, days); } catch (_) {}
    const params = {
      secid: sd,
      fields1: 'f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13,f14',
      fields2: 'f51,f53,f56,f58',
      iscr: 0, iscca: 0, ndays: days
    };
    if (days === 5) params.fields1 += ',f17';
    let r;
    try {
      try {
        r = await em(days === 5 ? 'emhis' : 'emdelay', '/api/qt/stock/trends2/get', params, { timeout: 15000 });
      } catch (err) {
        r = await em('emhis', '/api/qt/stock/trends2/get', params, { timeout: 15000 });
      }
    } catch (err) {
      throw new Error(`腾讯分时不可用，东方财富分时也失败：${err.message}`);
    }
    const dd = r.data || {};
    const points = (dd.trends || []).map(line => {
      const a = String(line).split(',');
      if (a.length < 4) return null;
      const [dt, price, volume, avg] = a;
      const time = dt.includes(' ') ? dt.split(' ')[1] : dt;
      const day = dt.includes(' ') ? dt.split(' ')[0] : '';
      return { datetime: dt, date: day, time, price: num(price), volume: num(volume), avg: num(avg) };
    }).filter(p => p && p.price > 0);
    if (!points.length) throw new Error('东方财富分时未返回数据');
    return {
      secid: sd, code: str(dd.code), name: str(dd.name),
      date: d || today(), days,
      preClose: num(dd.preClose || dd.prePrice),
      points, source: 'eastmoney'
    };
  });
}

async function getQuote({ secid }) {
  const sd = inferSecid(secid);
  return cached(`quote:${sd}`, 3000, async () => {
    try { return await getTencentProxyQuote(sd); } catch (_) {}
    try { return await getTencentQuote(sd); } catch (_) {}
    try {
      const r = await em('em', '/api/qt/stock/get', {
        secid: sd,
        fields: [
          'f43', 'f44', 'f45', 'f46', 'f47', 'f48', 'f50', 'f51', 'f52', 'f57', 'f58', 'f60',
          'f71', 'f84', 'f85', 'f92', 'f116', 'f117', 'f127', 'f128', 'f129', 'f162', 'f167',
          'f168', 'f169', 'f170', 'f171'
        ].join(','),
        fltt: 2, invt: 2
      });
      const d = r.data || {};
      if (d.f43 !== undefined) {
        return {
          secid: sd, code: str(d.f57), name: str(d.f58),
          price: num(d.f43), changePct: num(d.f170), change: num(d.f169),
          open: num(d.f46), high: num(d.f44), low: num(d.f45), preClose: num(d.f60),
          volume: num(d.f47), amount: num(d.f48),
          turnoverRate: num(d.f168), volumeRatio: num(d.f50), amplitude: num(d.f171),
          totalCap: num(d.f116), floatCap: num(d.f117),
          totalShares: num(d.f84), floatShares: num(d.f85),
          pe: num(d.f162), pb: num(d.f167), bps: num(d.f92),
          avgPrice: num(d.f71), limitUp: num(d.f51), limitDown: num(d.f52),
          industry: str(d.f127), region: str(d.f128),
          concepts: str(d.f129) ? str(d.f129).split(/[,，|｜]/).map(s => s.trim()).filter(Boolean) : [],
          source: 'eastmoney'
        };
      }
    } catch (_) {}
    throw new Error('腾讯与东方财富行情均不可用');
  });
}

async function getQuotes({ secids }) {
  const list = (Array.isArray(secids) ? secids : String(secids || '').split(',')).map(inferSecid).filter(Boolean);
  return cached(`quotes:${list.join(',')}`, 3000, async () => {
    if (!list.length) return { items: [] };
    try {
      const r = await em('em', '/api/qt/ulist.np/get', {
        fltt: 2, fields: 'f12,f13,f14,f2,f3,f6,f20,f25,f124', secids: list.join(',')
      });
      const items = (r.data && r.data.diff || []).map(x => ({
        code: str(x.f12), market: num(x.f13), secid: `${num(x.f13)}.${str(x.f12)}`,
        name: str(x.f14), price: num(x.f2), changePct: num(x.f3),
        volume: num(x.f6), totalCap: num(x.f20), ytd: num(x.f25)
      }));
      if (items.length) return { items };
    } catch (_) {}
    return getTencentQuotes(list);
  });
}

async function searchStock({ keyword }) {
  const kw = String(keyword || '').trim();
  if (!kw) return { items: [] };
  return cached(`search:${kw}`, 60000, async () => {
    const r = await em('search', '/api/suggest/get', {
      input: kw, type: 14, token: 'D43BF722C8E33BDC906FB84D85E326E8', count: 10
    });
    const data = r.QuotationCodeTable && r.QuotationCodeTable.Data || [];
    return {
      items: data.map(x => ({
        code: str(x.Code), name: str(x.Name),
        market: str(x.MktNum), secid: str(x.QuoteID),
        typeName: str(x.SecurityTypeName)
      }))
    };
  });
}


/* ============================== 开盘啦 · 精选板块 ============================== */

const FEATURED_TYPES = {
  '7': '精选板块',
  '4': '行业板块',
  '6': '地区板块'
};

function parseFeaturedRow(row) {
  return {
    code: str(row[0]),
    name: str(row[1]),
    strength: num(row[2]),
    changePct: num(row[3]),
    changeSpeed: num(row[4]),
    amount: num(row[5]),
    netInflow: num(row[6]),
    mainBuy: num(row[7]),
    mainSell: num(row[8]),
    volumeRatio: num(row[9]),
    floatCap: num(row[10]),
    avgChange: num(row[11]),
    bigOrderNet: num(row[12]),
    totalCap: num(row[13]),
    institutionNet: num(row[14]),
    pe: num(row[15]),
    peNext: num(row[16]),
    strength2: num(row[17]),
    changePct2: num(row[18])
  };
}

async function getFeaturedSectors({ date, zsType = '7', index = 0, pageSize = 50, all = false } = {}) {
  const d = date || today();
  const type = FEATURED_TYPES[String(zsType)] ? String(zsType) : '7';
  const size = Math.max(1, Math.min(50, Number(pageSize) || 50));
  const start = Math.max(0, Number(index) || 0);
  const key = `featured:${d}:${type}:${start}:${size}:${all}`;
  return cached(key, d === today() ? 5000 : 30000, async () => {
    const typeParam = type === '7' ? '1' : '2';
    const fetchPage = async (date, idx) => kph(date === today() ? 'realtime' : 'history', {
      a: 'RealRankingInfo', c: 'ZhiShuRanking', Order: '1',
      st: String(size), Index: String(idx), Date: date,
      Type: typeParam, ZSType: type
    });
    let effectiveDate = d;
    let first = await fetchPage(effectiveDate, start);
    let items = (first.list || []).map(parseFeaturedRow).filter(x => x.code);
    let isFallback = false;
    let preMarket = false;
    if (d === today()) {
      const noFlow = items.length > 0 && items.every(x => x.amount === 0 && x.netInflow === 0);
      preMarket = !items.length || noFlow;
      if (preMarket) {
        const prev = previousWeekday(d);
        try {
          const prevFirst = await fetchPage(prev, start);
          const prevItems = (prevFirst.list || []).map(parseFeaturedRow).filter(x => x.code);
          if (prevItems.length) {
            effectiveDate = prev;
            first = prevFirst;
            items = prevItems;
            isFallback = true;
          }
        } catch (_) {}
      }
    }
    let total = Math.max(num(first.Count), items.length);
    let pages = 1;
    if (all) {
      let idx = start;
      while (pages < 20) {
        idx += size;
        const r = await fetchPage(effectiveDate, idx);
        const batch = (r.list || []).map(parseFeaturedRow).filter(x => x.code);
        if (!batch.length) break;
        items = items.concat(batch);
        pages += 1;
        if (batch.length < size) break;
        await new Promise(res => setTimeout(res, 160));
      }
      total = Math.max(total, items.length);
    }
    const subSectors = (first.list_soninfo || []).map(parseFeaturedRow).filter(x => x.code);
    return {
      date: effectiveDate,
      requestedDate: d,
      isFallback,
      preMarket,
      zsType: type,
      zsName: FEATURED_TYPES[type],
      typeParam,
      time: fmtApiTime(first.Time),
      title: Array.isArray(first.Title) ? first.Title : [],
      count: total,
      page: start,
      pageSize: size,
      pages,
      parentCodes: (first["list_son"] || []).map(str),
      items,
      subSectors
    };
  });
}

/* ============================== 组合 / 补充接口 ============================== */

async function getSectorMainline({ date, days = 10, topN = 10, zsType = '7' } = {}) {
  const end = date || today();
  const count = Math.max(3, Math.min(15, Number(days) || 10));
  const size = Math.max(3, Math.min(20, Number(topN) || 10));
  const type = FEATURED_TYPES[String(zsType)] ? String(zsType) : '7';
  return cached(`sectorMainline:${end}:${type}:${count}:${size}`, 60000, async () => {
    const collected = [];
    const seenDates = new Set();
    let cursor = end;
    let guard = 0;
    while (collected.length < count && guard < count * 4) {
      const weekday = new Date(`${cursor}T12:00:00`).getDay();
      if (weekday === 0 || weekday === 6) {
        cursor = addDays(cursor, -1);
        guard += 1;
        continue;
      }
      try {
        const data = await getFeaturedSectors({
          date: cursor, zsType: type, pageSize: 50, all: false
        });
        const actualDate = data.date || cursor;
        const items = data.items || [];
        if (items.length && !seenDates.has(actualDate)) {
          const rows = [...items]
            .filter(x => x.code && Number.isFinite(Number(x.strength)))
            .sort((a, b) => Number(b.strength) - Number(a.strength))
            .slice(0, size)
            .map((x, i) => ({
              rank: i + 1,
              code: x.code,
              name: x.name,
              strength: Number(x.strength) || 0,
              changePct: Number(x.changePct) || 0,
              changeSpeed: Number(x.changeSpeed) || 0,
              amount: Number(x.amount) || 0,
              netInflow: Number(x.netInflow) || 0
            }));
          if (rows.length) {
            collected.push({
              date: actualDate,
              requestedDate: cursor,
              time: data.time || '',
              isFallback: !!data.isFallback,
              rows
            });
            seenDates.add(actualDate);
          }
        }
      } catch (_) {}
      cursor = previousWeekday(cursor);
      guard += 1;
    }
    collected.sort((a, b) => a.date.localeCompare(b.date));

    const byCode = new Map();
    for (const day of collected) {
      for (const row of day.rows) {
        let item = byCode.get(row.code);
        if (!item) {
          item = {
            code: row.code,
            name: row.name,
            appearDays: 0,
            totalStrength: 0,
            bestRank: null,
            latest: null,
            days: []
          };
          byCode.set(row.code, item);
        }
        item.name = row.name || item.name;
        item.appearDays += 1;
        item.totalStrength += row.strength;
        item.bestRank = item.bestRank == null ? row.rank : Math.min(item.bestRank, row.rank);
        item.latest = {
          date: day.date,
          rank: row.rank,
          strength: row.strength,
          changePct: row.changePct
        };
        item.days.push({
          date: day.date,
          rank: row.rank,
          strength: row.strength,
          changePct: row.changePct
        });
      }
    }
    const mainlines = [...byCode.values()].map(item => ({
      ...item,
      avgStrength: item.appearDays ? item.totalStrength / item.appearDays : 0
    })).sort((a, b) =>
      b.appearDays - a.appearDays ||
      b.avgStrength - a.avgStrength ||
      (a.bestRank == null ? 999 : a.bestRank) - (b.bestRank == null ? 999 : b.bestRank)
    ).slice(0, 12);

    return {
      date: end,
      zsType: type,
      zsName: FEATURED_TYPES[type],
      days: collected,
      count: collected.length,
      topN: size,
      mainlines
    };
  });
}

async function getSectorStrengthNDays({ endDate, numDays = 7 }) {
  const end = endDate || today();
  const target = Math.max(1, Math.min(15, Number(numDays) || 7));
  return cached(`strengthNDays:${end}:${target}`, 60000, async () => {
    const rows = [];
    const seenDates = new Set();
    let tradingDays = 0;
    for (let i = 0; i < target * 3 && tradingDays < target; i += 1) {
      const date = addDays(end, -i);
      const weekday = new Date(`${date}T12:00:00`).getDay();
      if (weekday === 0 || weekday === 6) continue;
      try {
        const data = await getSectorRanking({ date, index: 0 });
        if (!data.sectors.length) continue;
        const actualDate = data.date || date;
        if (seenDates.has(actualDate)) continue;
        seenDates.add(actualDate);
        tradingDays += 1;
        for (const sec of data.sectors) {
          rows.push({
            date: actualDate, code: sec.code, name: sec.name, count: sec.count,
            stocks: sec.stocks.map(x => x.code)
          });
        }
      } catch (_) {}
      await new Promise(res => setTimeout(res, 180));
    }
    return { endDate: end, numDays: target, tradingDays, rows };
  });
}

async function getMultipleSectorStrength({ codes, date }) {
  const list = (Array.isArray(codes) ? codes : String(codes || '').split(','))
    .map(x => String(x).trim()).filter(Boolean);
  const d = date || today();
  const items = await mapLimit(list, 4, async code => {
    try {
      const r = await getSectorStrength({ code, date: d });
      return { ...r, success: r.strength !== null };
    } catch (err) {
      return { code, date: d, strength: null, success: false, error: err.message };
    }
  });
  return { date: d, items };
}

async function getBoardStocksCount({ type = 1 }) {
  const r = await getRealtimeBoardStocks({ type });
  return { type: r.type, date: r.date, count: r.items.length, items: r.items };
}

async function getPlateNewsAll({ plateId, maxPages = 3, pageSize = 30 }) {
  const pages = Math.max(1, Math.min(10, Number(maxPages) || 3));
  const size = Math.max(1, Math.min(100, Number(pageSize) || 30));
  const items = [];
  for (let page = 0; page < pages; page += 1) {
    const r = await getPlateNews({ plateId, index: page * size, pageSize: size });
    if (!r.items.length) break;
    items.push(...r.items);
    await new Promise(res => setTimeout(res, 180));
  }
  return { plateId: String(plateId), items, total: items.length, pages };
}

const DEFAULT_SENTIMENT_STOCKS = [
  '002112', '603667', '600550', '601179', '600089', '600879', '603986',
  '002156', '002202', '002050', '002865', '002413', '002716', '000559',
  '000981', '002131', '603938', '603650', '000547', '600362', '600266',
  '600410', '002195', '603000', '001255', '000681', '002465'
];

async function getSentimentIndicator({ plateId = '801225', stocks } = {}) {
  const list = Array.isArray(stocks) && stocks.length ? stocks : DEFAULT_SENTIMENT_STOCKS;
  return cached(`sentimentIndicator:${plateId}:${list.join(',')}`, 8000, async () => {
    const r = await kpl('hq', {
      a: 'PlateIntroduction_Info', c: 'ZhiShuRanking',
      Stocks: list.join(','), PlateID: String(plateId)
    }, { query: false });
    const items = (r.List || []).filter(Array.isArray).map(x => ({
      code: str(x[0]), name: str(x[1]), extra: x[2], tag: str(x[3])
    })).filter(x => x.code);
    const codes = items.length ? items.map(x => x.code) : list;
    return {
      date: today(), plateId: String(plateId),
      bullishCodes: codes.slice(0, 3),
      bearishCodes: codes.slice(-3),
      allStocks: codes,
      items
    };
  });
}

async function getKplHotRank({ type = '1', limit = 50 } = {}) {
  const t = String(type) === '2' ? '2' : '1';
  const size = Math.max(1, Math.min(50, Number(limit) || 50));
  return cached(`kplHot:${t}:${size}`, 3000, async () => {
    let r = null;
    let lastErr = null;
    for (const host of ['apphq', 'hq', 'apphwshhq']) {
      try {
        const candidate = await kpl(host, {
          Order: '1', a: 'GetHotPHB', st: String(size),
          apiv: 'w29', Type: t, c: 'StockBidYiDong'
        }, { query: false });
        if (Array.isArray(candidate.List) && candidate.List.length) { r = candidate; break; }
        r = candidate;
      } catch (err) {
        lastErr = err;
      }
    }
    if (!r) throw lastErr || new Error('开盘啦人气榜请求失败');
    const items = (r.List || []).filter(Array.isArray).map((a, i) => {
      const rank = num(a[4]) || i + 1;
      const isNew = num(a[5]);
      if (t === '2') {
        return {
          code: str(a[0]), name: str(a[1]), changePct: num(a[2]),
          heat: num(a[3]), rank, rankChange: null, isNew,
          concepts: [], popularity: isNew ? '新进' : ''
        };
      }
      return {
        code: str(a[0]), name: str(a[1]), changePct: num(a[2]),
        rank, rankChange: num(a[3]), isNew, heat: null,
        concepts: [], popularity: ''
      };
    });
    return {
      source: 'kpl', type: t,
      date: fmtDay(r.Day || today()),
      time: fmtApiTime(r.Time),
      state: num(r.State),
      items, total: items.length
    };
  });
}

async function getStockLimitReasons({ codes = [] } = {}) {
  const list = [...new Set((Array.isArray(codes) ? codes : String(codes || '').split(','))
    .map(x => String(x).trim()).filter(Boolean))].slice(0, 50);
  return cached(`stockLimitReasons:${list.join(',')}`, 30000, async () => {
    const items = await mapLimit(list, 6, async code => {
      try {
        const r = await kpl('his', {
          a: 'GetDayZhangTing', st: '25', c: 'HisLimitResumption',
          StockID: code, Index: '0', Token: TOKEN, UserID: USER_ID, Red: '0', apiv: 'w47'
        }, { query: false });
        const rows = (r.List || []).filter(x => x && x.Date).sort((a, b) => str(b.Date).localeCompare(str(a.Date)));
        const latest = rows[0] || {};
        return {
          code, date: str(latest.Date), reason: str(latest.Reason),
          summary: str(latest.GNSM), tag: str(latest.SCLT)
        };
      } catch (err) {
        return { code, date: '', reason: '', summary: '', tag: '', error: err.message };
      }
    });
    return { items };
  });
}

async function getStockConcepts({ codes = [] } = {}) {
  const list = [...new Set((Array.isArray(codes) ? codes : String(codes || '').split(','))
    .map(x => String(x).trim()).filter(Boolean))].slice(0, 50);
  return cached(`stockConcepts:${list.join(',')}`, 30000, async () => {
    const items = await mapLimit(list, 6, async code => {
      try {
        const r = await kpl('apphwshhq', {
          a: 'GetStockIDPlate', apiv: 'w43', Type: '2',
          c: 'StockL2Data', StockID: code, UserID: USER_ID, Token: TOKEN
        }, { query: false });
        return {
          code,
          concepts: (r.ListJX || []).filter(Array.isArray).map(x => ({
            code: str(x[0]), name: str(x[1]), changePct: num(x[2])
          })).filter(x => x.name)
        };
      } catch (err) {
        return { code, concepts: [], error: err.message };
      }
    });
    return { items };
  });
}

async function getMarketCapacity({ date } = {}) {
  const d = date || today();
  const load = async queryDate => {
    const r = await kpl('his', {
      a: 'MarketCapacity', c: 'HisHomeDingPan', Type: '0', Date: queryDate,
      Token: TOKEN, UserID: USER_ID, Red: '0', apiv: 'w47'
    }, { query: false, timeout: 8000 });
    const info = (r && r.info) || {};
    const turnover = num(info.last) * 10000;
    const prevTurnover = num(info.s_zrcs) * 10000;
    const points = (info.trends || []).filter(Array.isArray).map(a => ({
      time: str(a[0]),
      turnover: num(a[1]) * 10000,
      prevTurnover: num(a[2]) * 10000,
      referenceTurnover: num(a[3]) * 10000,
      changeRate: num(a[4]),
      summary: str(a[5]),
      flag: num(a[6]),
      flag2: num(a[7])
    })).filter(p => p.time);
    if (!turnover) throw new Error('开盘啦大盘量能为空');
    return {
      date: queryDate,
      requestedDate: d,
      isFallback: queryDate !== d,
      time: fmtApiTime(info.time),
      turnover,
      prevTurnover,
      prevSameTurnover: num(info.s_zrtj) * 10000,
      referenceTurnover: num(info.s3_zrtj) * 10000,
      change: turnover - prevTurnover,
      changeRate: num(info.csbl),
      summary: str(info.yclnstr),
      volumeText: str(info.ycln),
      points,
      source: 'kpl'
    };
  };
  return cached(`marketCapacity:${d}`, 8000, async () => {
    try {
      return await load(d);
    } catch (err) {
      let candidate = previousWeekday(d);
      for (let i = 0; i < 2; i += 1) {
        try {
          return await load(candidate);
        } catch (_) {
          candidate = previousWeekday(candidate);
        }
      }
      throw err;
    }
  });
}

async function getMarketCapacityKLine({ date, days = 10 } = {}) {
  const d = date || today();
  const limit = Math.max(1, Math.min(30, Number(days) || 10));
  return cached(`marketCapacityKLine:${d}:${limit}`, 300000, async () => {
    const r = await kpl('his', {
      a: 'MarketCapacityKLine', c: 'HisHomeDingPan', Date: d,
      Token: TOKEN, UserID: USER_ID, Red: '0', apiv: 'w47'
    }, { query: false, timeout: 8000 });
    const rows = (r.info || []).filter(x => x && typeof x === 'object').map(x => ({
      date: str(x.Date),
      turnover: num(x.lastPoint) * 10000
    })).filter(x => x.date && x.turnover > 0).sort((a, b) => a.date.localeCompare(b.date));
    return { date: d, rows: rows.slice(-limit) };
  });
}

async function getMarketVolumeHistory({ type = '4', days = 10 } = {}) {
  const t = ['0', '1', '2', '3', '4', '5'].includes(String(type)) ? String(type) : '4';
  const limit = Math.max(1, Math.min(20, Number(days) || 10));
  return cached(`marketVolumeHistory:${t}:${limit}`, 300000, async () => {
    const r = await kpl('his', {
      a: 'MarketSCLNKLine', c: 'HisHomeDingPan', Type: t,
      Token: TOKEN, UserID: USER_ID, Red: '0', apiv: 'w47'
    }, { query: false });
    const rows = (r.info || []).filter(x => x && typeof x === 'object').map(x => ({
      date: str(x.Date),
      turnover: num(x.lastPoint) * 10000
    })).filter(x => x.date && x.turnover > 0).sort((a, b) => a.date.localeCompare(b.date));
    return { type: t, rows: rows.slice(-limit) };
  });
}

async function getMarketVolume() {
  return cached('marketVolume', 8000, async () => {
    const url = 'https://dq.10jqka.com.cn/fuyao/market_analysis_api/chart/v1/get_chart_data?chart_key=turnover_minute';
    const r = await fetchJson(url, { timeout: 15000 });
    if (Number(r.status_code) !== 0 || !r.data || !r.data.charts) throw new Error(r.status_msg || '同花顺量能预测请求失败');
    const charts = r.data.charts;
    const header = {};
    for (const item of charts.header || []) {
      if (item && item.key) header[item.key] = num(item.val);
    }
    const points = (charts.point_list || []).filter(Array.isArray).map(a => {
      const ts = num(a[0]);
      const d = ts ? new Date(ts) : null;
      return {
        time: d ? `${pad2(d.getHours())}:${pad2(d.getMinutes())}` : '',
        turnover: num(a[1]),
        prevTurnover: num(a[2]),
        change: num(a[3])
      };
    }).filter(p => p.time);
    const last = points[points.length - 1];
    return {
      date: today(),
      time: last ? last.time : '',
      turnover: header.turnover || (last ? last.turnover : 0),
      prevTurnover: header.turnover_pre || 0,
      change: header.turnover_change || 0,
      predictTurnover: header.predict_turnover || 0,
      predictChangeRate: header.predict_turnover_change_rate || 0,
      points,
      source: 'ths'
    };
  });
}

async function getThsHotRank({ type = 'hour', limit = 50 } = {}) {
  const t = type === 'day' ? 'day' : 'hour';
  const size = Math.max(1, Math.min(100, Number(limit) || 50));
  return cached(`thsHot:${t}:${size}`, 10000, async () => {
    const url = `https://dq.10jqka.com.cn/fuyao/hot_list_data/out/hot_list/v1/stock?${new URLSearchParams({
      stock_type: 'a', type: t, list_type: 'normal', limit: String(size)
    }).toString()}`;
    const r = await fetchJson(url, { timeout: 15000 });
    if (Number(r.status_code) !== 0) throw new Error(r.status_msg || '同花顺热榜请求失败');
    return {
      type: t,
      items: ((r.data && r.data.stock_list) || []).map(x => ({
        order: num(x.order), code: str(x.code), name: str(x.name),
        market: num(x.market), rate: str(x.rate),
        changePct: num(x.rise_and_fall), rankChange: num(x.hot_rank_chg),
        concepts: x.tag && Array.isArray(x.tag.concept_tag) ? x.tag.concept_tag : [],
        popularity: x.tag ? str(x.tag.popularity_tag) : '',
        analyse: str(x.analyse)
      }))
    };
  });
}

/* ============================== 通用接口 ============================== */

async function rawKpl({ host = 'his', params = {}, query = true }) {
  return kpl(host, params, { query });
}

const handlers = {
  daily: getDailyData,
  dailyRange: getDailyRange,
  sentiment: getMarketSentiment,
  marketIndex: getMarketIndex,
  ladderSummary: getLadderSummary,
  sharpWithdrawal: getSharpWithdrawal,
  newHigh: getNewHigh,
  sectorRanking: getSectorRanking,
  featuredSectors: getFeaturedSectors,
  sectorMainline: getSectorMainline,
  sectorStrength: getSectorStrength,
  sectorStrengthHistory: getSectorStrengthHistory,
  sectorCapital: getSectorCapital,
  sectorIntraday: getSectorIntraday,
  sectorVolume: getSectorVolume,
  sectorConstituents: getSectorConstituents,
  sectorHotStocks: getSectorHotStocks,
  sonPlateInfo: getSonPlateInfo,
  sectorTags: getSectorTags,
  sectorBoomReasons: getSectorBoomReasons,
  sectorBidding: getSectorBidding,
  marketLadder: getMarketLadder,
  sectorLadder: getSectorLadder,
  consecutive: getConsecutiveLimitUp,
  brokenLimitUp: getBrokenLimitUp,
  realtimeMood: getRealtimeMood,
  realtimeLimit: getRealtimeLimit,
  realtimeBoards: getRealtimeBoardStocks,
  realtimeAllBoards: getRealtimeAllBoards,
  realtimeIndexTrend: getRealtimeIndexTrend,
  realtimeIndexList: getRealtimeIndexList,
  realtimeSharp: getRealtimeSharp,
  riseFall: getRiseFall,
  stockIntraday: getStockIntraday,
  stockBigOrder: getStockBigOrder,
  stockLimitGene: getStockLimitGene,
  indexIntraday: getIndexIntraday,
  stockAuction: getStockAuction,
  lhbList: getLhbList,
  lhbDetail: getLhbDetail,
  etfRanking: getEtfRanking,
  allEtfRanking: getAllEtfRanking,
  plateNews: getPlateNews,
  kline: getKline,
  trends: getTrends,
  quote: getQuote,
  quotes: getQuotes,
  search: searchStock,
  sectorStrengthNDays: getSectorStrengthNDays,
  multipleSectorStrength: getMultipleSectorStrength,
  boardStocksCount: getBoardStocksCount,
  plateNewsAll: getPlateNewsAll,
  sentimentIndicator: getSentimentIndicator,
  kplHotRank: getKplHotRank,
  stockConcepts: getStockConcepts,
  stockLimitReasons: getStockLimitReasons,
  marketVolume: getMarketVolume,
  marketVolumeHistory: getMarketVolumeHistory,
  marketCapacity: getMarketCapacity,
  marketCapacityHistory: getMarketCapacityKLine,
  thsHotRank: getThsHotRank,
  rawKpl,
  clearCache: async () => { cacheStore.clear(); return { ok: true }; },
  health: async () => ({ ok: true, time: Date.now(), today: today() })
};

browser.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.type !== 'api') return false;
  const fn = handlers[msg.action];
  if (!fn) {
    sendResponse({ ok: false, error: `未知接口: ${msg.action}` });
    return false;
  }
  Promise.resolve()
    .then(() => fn(msg.params || {}))
    .then(data => sendResponse({ ok: true, data }))
    .catch(err => sendResponse({ ok: false, error: err && err.message ? err.message : String(err) }));
  return true;
});

/* ============================== 独立窗口 ============================== */

const DASHBOARD_WINDOW_KEY = 'kpl.dashboardWindowId';
let dashboardWindowId = null;
let dashboardOpening = null;

function dashboardWindowStore() {
  return browser.storage.session || browser.storage.local;
}

async function getStoredDashboardWindowId() {
  try {
    const data = await dashboardWindowStore().get(DASHBOARD_WINDOW_KEY);
    const id = Number(data && data[DASHBOARD_WINDOW_KEY]);
    return Number.isInteger(id) && id > 0 ? id : null;
  } catch (_) {
    return null;
  }
}

async function storeDashboardWindowId(id) {
  try {
    if (id) await dashboardWindowStore().set({ [DASHBOARD_WINDOW_KEY]: id });
    else await dashboardWindowStore().remove(DASHBOARD_WINDOW_KEY);
  } catch (_) {}
}

async function openDashboardWindow() {
  if (dashboardOpening) return dashboardOpening;
  dashboardOpening = (async () => {
    const url = browser.runtime.getURL('dashboard.html');
    const savedId = dashboardWindowId || await getStoredDashboardWindowId();
    if (savedId && browser.windows && browser.windows.get) {
      try {
        const win = await browser.windows.get(savedId);
        if (win && win.id) {
          await browser.windows.update(savedId, win.state === 'minimized'
            ? { focused: true, state: 'normal' }
            : { focused: true });
          dashboardWindowId = savedId;
          await storeDashboardWindowId(savedId);
          return savedId;
        }
      } catch (_) {}
    }
    if (!browser.windows || !browser.windows.create) {
      const tab = await browser.tabs.create({ url });
      return tab && tab.windowId ? tab.windowId : null;
    }
    try {
      const win = await browser.windows.create({
        url, type: 'popup', width: 1280, height: 900
      });
      if (win && win.id) {
        dashboardWindowId = win.id;
        await storeDashboardWindowId(win.id);
        return win.id;
      }
    } catch (_) {}
    try {
      const tab = await browser.tabs.create({ url });
      return tab && tab.windowId ? tab.windowId : null;
    } catch (_) {
      return null;
    }
  })().finally(() => { dashboardOpening = null; });
  return dashboardOpening;
}

if (browser.windows && browser.windows.onRemoved) {
  browser.windows.onRemoved.addListener(id => {
    if (dashboardWindowId === id) dashboardWindowId = null;
    getStoredDashboardWindowId().then(saved => {
      if (saved === id) storeDashboardWindowId(null);
    });
  });
}

/* 工具栏默认打开 action popup（dashboard.html）；该弹窗在点击外部时自动关闭。
 * 独立窗口通过工具栏图标右键菜单启动。 */
const OPEN_WINDOW_MENU_ID = 'kpl-open-window';

async function setupDashboardContextMenu() {
  if (!browser.contextMenus) return;
  try {
    await browser.contextMenus.removeAll();
    await browser.contextMenus.create({
      id: OPEN_WINDOW_MENU_ID,
      title: '独立窗口启动盯盘',
      contexts: ['action']
    });
  } catch (_) {}
}

if (browser.contextMenus && browser.contextMenus.onClicked) {
  browser.contextMenus.onClicked.addListener(info => {
    if (info && info.menuItemId === OPEN_WINDOW_MENU_ID) {
      openDashboardWindow().catch(() => {});
    }
  });
}
browser.runtime.onInstalled.addListener(setupDashboardContextMenu);
if (browser.runtime.onStartup) browser.runtime.onStartup.addListener(setupDashboardContextMenu);
setupDashboardContextMenu();
