# 开盘啦盯盘助手（Firefox 扩展）

一个基于 [jinhao2003/kaipanla-crawler](https://github.com/jinhao2003/kaipanla-crawler) 所整理的开盘啦 App 接口，并参考爱盯盘插件的界面配色、K 线/分时参数实现的 Firefox 盯盘面板。

所有数据请求都在扩展后台发出，面板只负责展示；不注入任何网页、不读取浏览记录、不上传数据。

> 数据仅供学习研究，不构成任何投资建议。请合理控制请求频率。

---

## 功能

### 热门（首页）
- **主线追踪**：最近两周精选板块强度矩阵，左侧为最新日期，一天一列、每日按强度从高到低排列；点击任意板块会在其他日期列中高亮同一板块，并给出按出现天数和平均强度排序的主线候选。
- **精选板块**：开盘啦「精选板块 / 行业板块 / 地区板块」排行，展示**板块强度**、涨跌幅、涨速、成交额、主力净额、主买/主卖、量比、流通/总市值、平均涨幅与细分板块。默认首页；点击任意板块进入「板块个股」，**默认按今日涨幅排序，可切换人气排序或开盘啦标签排序**（机构增仓、低 PE、高股息等）；板块个股页同时展示 `SonPlate_Info` 细分板块及强度、成分股 `list[58]` 人气值。当天个股使用实时成分股接口（RStart/REnd），盘前才回退上一交易日；午休期间显示上午数据并标注“更新至 11:30”。成分股表格默认只显示 9 个核心字段，更多字段通过表格上方的复选框开启，选择保存在本机。
- **人气排行榜**：开盘啦人气榜 / 最强风口（`GetHotPHB`），并补充同花顺小时榜 / 日榜；完整榜单含排名变化、热度值、人气标签与概念。开盘啦榜单会通过 `GetStockIDPlate` 为每只个股补充相关概念，并对涨停个股调用 `GetDayZhangTing` 补充涨停原因，以灰色小字显示在股票名称下方；涨停原因会标注对应日期，避免把历史原因误认为当日原因。

### 盘面
- **市场总览**：上证指数、两市成交额、涨跌停、涨跌家数、涨跌比、昨日涨停/炸板表现、连板高度、热点板块；**大盘量能预测**同时接入同花顺 `turnover_minute` 和开盘啦 `MarketCapacity`，展示当前成交额、预测全天成交额、较昨日变动、开盘啦量能校验，以及 `MarketCapacityKLine` 近 10 日量能对比。
- **市场情绪**：0–100 情绪温度评分与冰点/修复/升温/高潮/分歧/退潮阶段；涨跌家数、涨跌停、连板高度、两市成交额、昨日涨停表现、炸板率/封板率、大幅回撤、多空风向标、领涨板块；支持近 10 日情绪温度趋势图。
- **涨跌统计**：单日涨停/跌停/实际涨跌停、上涨/下跌/平盘、连板率、破板率、昨日表现、大幅回撤、百日新高；支持按交易日区间循环统计。当天历史日线尚未生成时自动改用实时接口汇总。
- **连板梯队**：全市场梯队（首板至 N 板）、板块梯队、反包板、打开高度、连板详情（股票/题材/概念）、历史炸板。
- **涨停原因**：按涨停原因聚合板块，展开查看个股价格、连板、概念、封单额、主力净额、成交额、换手、流通市值、涨停原因。
- **板块行情**：板块资金盘口、板块强度、强度历史、N 日板块强度、板块分时、成交量/成交额、成分股（支持全部翻页）、**爆发原因历史**、竞价异动。

### 行情
- **个股行情**：实时快照、分时、五日、1/5/15/30/60/120 分钟 K 线、日/周/月/季/年 K 线，前复权/后复权/不复权。
- **涨停基因**：个股页新增「涨停基因」页签，展示历史涨停次数、5% 溢价次数、次日红盘率、首板封板率/破板率、连板率；数据为历史聚合，不是当日预测，全 0 表示暂无涨停样本。
- **开盘啦分时**：实时/历史分钟数据，历史数据含主力净流入字段时展示。
- **主力大单**：大单买入/卖出/净额、逐分钟大单明细。
- **集合竞价**：09:15–09:25 逐笔（东方财富分时明细）。
- **指数行情**：上证、深证、创业板、科创 50、沪深 300、上证 50 的分时/K 线与开盘啦指数分时。
- **异动监控**：全部涨停板、分类型涨停板、实时大幅回撤、涨跌分析、历史炸板、板块竞价异动、多空风向标、同花顺热榜。

### 数据
- **龙虎榜**：每日上榜个股、买卖席位、上榜原因、买卖总额。
- **ETF 排行**：涨幅排序、成交额/规模、近 1 周/1 月/3 月/6 月/今年以来收益，支持加载全部。
- **板块资讯**：按板块代码读取新闻/快讯，支持加载更多。
- **接口目录**：列出 37 个开盘啦原始接口、组合接口以及腾讯/东方财富 K 线/分时/行情接口，可直接编辑 JSON 参数并查看调用结果。

### 体验
- 界面参考爱盯盘：**窄图标导航 + 顶部模块页签**、轻量白色面板、紧凑表格和紫色强调色；支持**浅色 / 深色 / 灰色**三种主题，A 股红涨绿跌。
- 顶栏“🎨 主题与外观”可调：**透明度、色彩度、亮度**，设置保存在本机。
- 全局面板：日期选择、手动刷新、10/30/60 秒自动刷新。
- 默认点击浏览器工具栏的扩展图标，会在图标下方打开 **action popup**，点击窗口外部会自动隐藏；右键工具栏图标选择「独立窗口启动盯盘」，可打开独立的 1280×900 盯盘窗口，再次选择会聚焦已打开窗口。
- 点击股票代码/名称直接跳转个股；点击板块名直接进入板块行情。个股页提供「返回上一页」按钮，可回到精选板块、板块个股、人气榜等来源页面。
- K 线和分时图使用原生 Canvas 绘制，无外部图表库；支持十字光标和悬浮提示。
- 响应式布局，窄屏下侧栏自动收起。

---

## 主题与外观（参考爱盯盘）
- 打开顶栏 **🎨** 按钮 → “主题与外观”
- **主题**：浅色 / 深色 / 灰色
- **透明度**：10%–100%，控制卡片和面板的玻璃透明度，文字保持可读
- **色彩度**：0%–100%，参考爱盯盘，100% 全彩、0% 灰度
- **亮度**：70%–130%，整体调亮/调暗
- 设置写入 `localStorage`，下次打开自动恢复；“恢复默认”回到浅色、100%、100%、100%。

## 安装（Firefox）

### 临时载入（开发/自用）
1. 打开 Firefox，地址栏输入 `about:debugging#/runtime/this-firefox`。
2. 点击 **“临时载入附加组件”**。
3. 选择本目录下的 `manifest.json`。
4. 点击工具栏上的扩展图标，或打开 `about:addons` → 本扩展 → 选项，即可打开完整面板。

> 临时载入的扩展在 Firefox 重启后会失效，需要重新载入。若需长期使用，可将目录打包为 zip/xpi 并通过 AMO 签名，或在 Firefox Developer Edition / Nightly 中关闭签名强制后安装。

### 打包
```bash
cd kaipanla-extension
zip -r ../kaipanla-extension.zip . -x '*.DS_Store'
```
（本机没有 `zip` 命令时可用 Python：）
```bash
python3 -m zipfile -c ../kaipanla-extension.zip .
```

---

## 目录结构

```
kaipanla-extension/
├── manifest.json          # Firefox MV3 清单
├── background.js          # 开盘啦/腾讯（主）/东方财富（备用）/同花顺接口封装与消息路由
├── dashboard.html         # 完整面板入口
├── style.css              # 爱盯盘风格浅色/深色主题与盘面样式
├── js/
│   ├── core.js            # API 消息、格式化、表格、抽屉、Toast
│   ├── charts.js          # Canvas 分时/K线/折线图
│   ├── views-market.js    # 总览、涨跌统计、连板、涨停原因、板块
│   ├── views-stock.js     # 个股、指数
│   ├── views-extra.js     # 异动、龙虎榜、ETF、资讯、接口目录
│   ├── views-featured.js  # 精选板块、人气排行榜
│   ├── views-sentiment.js # 市场情绪温度、周期与趋势
│   ├── theme.js           # 首帧主题应用
│   └── main.js            # 导航、主题切换、日期、自动刷新、启动
├── icons/
│   ├── icon.svg
│   ├── icon-16.png
│   ├── icon-32.png
│   ├── icon-48.png
│   └── icon-128.png
└── README.md
```

---

## 接口覆盖

> 完整的 66 个 KPL-post 接口、50 个 LowellLee/kpl 接口、本扩展补充接口与第三方数据源汇总见 [`KPL_API_REFERENCE.md`](KPL_API_REFERENCE.md)。

### 开盘啦原始 a/c 接口

| # | 接口 | 用途 | 本扩展动作 |
|---|---|---|---|
| 1 | `HisZhangFuDetail / HisHomeDingPan` | 历史涨跌统计 | `daily` / `sentiment` |
| 2 | `GetZsReal / StockL2History` | 大盘指数 | `marketIndex` |
| 3 | `ZhangTingExpression / HisHomeDingPan` | 连板结构统计 | `ladderSummary` |
| 4 | `SharpWithdrawal / HisHomeDingPan` | 大幅回撤 | `sharpWithdrawal` |
| 5 | `GetDayNewHigh_W28 / StockNewHigh` | 百日新高 | `newHigh` |
| 6 | `GetPlateInfo_w38 / DailyLimitResumption` | 涨停原因板块 | `sectorRanking` |
| 7 | `DailyLimitPerformance / HisHomeDingPan` | 连板详情 / 实时涨停板 | `consecutive` / `realtimeBoards` |
| 8 | `GetYTFP_BKHX / FuPanLa` | 板块连板梯队 | `sectorLadder` |
| 9 | `GetYTFP_SCTD / FuPanLa` | 全市场连板梯队 | `marketLadder` |
| 10 | `HisDaBanList / HisHomeDingPan` | 历史炸板 | `brokenLimitUp` |
| 11 | `GetPanKou / ZhiShuL2Data` | 板块资金盘口 | `sectorCapital` |
| 12 | `MoodNumCount / MarketMood` | 实时市场情绪 | `realtimeMood` |
| 13 | `MarketStockZDNum / HomeDingPan` | 实际涨跌停 | `realtimeLimit` |
| 14 | `DailyLimitPerformance / HomeDingPan` | 实时涨停板 | `realtimeBoards` / `realtimeAllBoards` |
| 15 | `GetTrendIncremental / ZhiShuL2Data` | 指数/板块分时 | `sectorIntraday` / `realtimeIndexTrend` |
| 16 | `RefreshStockList / UserSelectStock` | 实时指数列表 | `realtimeIndexList` |
| 17 | `SharpWithdrawalList / HomeDingPan` | 实时大幅回撤 | `realtimeSharp` |
| 18 | `RiseFallAnalysis / HisHomeDingPan` | 涨跌分析 | `riseFall` |
| 19 | `GetVolTurIncremental / ZhiShuL2Data` | 板块成交量/额 | `sectorVolume` |
| 20 | `GetStockTrend / StockL2History` | 个股/指数历史分时 | `stockIntraday` / `indexIntraday` |
| 21 | `GetZstrend / StockL2Data` | 个股实时分时 | `stockIntraday` |
| 22 | `GetMainMonitor_Trend_w30` | 主力大单 | `stockBigOrder` |
| 23 | `GetStockTrendIncremental / StockL2Data` | 指数实时分时 | `indexIntraday` |
| 24 | `GetPlateNewsList / APPComplexData` | 板块新闻 | `plateNews` / `plateNewsAll` |
| 25 | `GetPlate_Info_QJ / ZhiShuRanking` | 板块强度 | `sectorStrength` / `sectorStrengthHistory` |
| 26 | `GetStockList / LongHuBang` | 龙虎榜列表 | `lhbList` |
| 27 | `GetNewOneStockInfo / Stock` | 龙虎榜个股详情 | `lhbDetail` |
| 28 | `ZhiShuStockList_W8 / ZhiShuRanking` | 板块成分股 | `sectorConstituents` |
| 29 | `GetBKJJ_W36 / StockBidYiDong` | 板块竞价异动 | `sectorBidding` |
| 30 | `ETFStockRanking / NewStockRanking` | ETF 排行 | `etfRanking` / `allEtfRanking` |
| 31 | `GetZhangTingGene / StockL2Data` | 个股涨停基因 | `stockLimitGene` |
| 32 | `MarketCapacity / HisHomeDingPan` | 大盘量能 | `marketCapacity` |
| 33 | `MarketCapacityKLine / HisHomeDingPan` | 大盘量能历史 | `marketCapacityHistory` |
| 34 | `SonPlate_Info / ZhiShuRanking` | 板块细分方向 | `sectorHotStocks` |
| 35 | `GetGPCPHBTS_Tag / ZhiShuRanking` | 板块标签排序 | `sectorHotStocks` |
| 36 | `GetDayBaseFaceListZDEvnArt / ZhiShuKLine` | 板块爆发原因 | `sectorBoomReasons` |
| 37 | `RealRankingInfo × 最近 10 个交易日` | 主线追踪组合 | `sectorMainline` |

### 开盘啦精选板块（开盘红）
- 实时：`https://apphwshhq.longhuvip.com`（主）/ `https://apphwshhq.kaipanhong.com`（备）
- 历史：`https://apphis.longhuvip.com`（主）/ `https://apphis.kaipanhong.com`（备）
- 自动容错：优先使用 longhuvip 域名，失败后切换 kaipanhong；盘前无资金数据时自动回退上一交易日。
- `a=RealRankingInfo`、`c=ZhiShuRanking`
- `ZSType=7` 精选板块 / `4` 行业板块 / `6` 地区板块
- `Type=1`（精选）/ `2`（行业、地区），`Order=1`，`st=50`，`Index` 分页，`Date=YYYY-MM-DD`
- 返回：板块代码、名称、**强度**、涨跌幅、涨速、成交额、主力净额、主买、主卖、量比、流通值、平均涨幅、300 万大单净额、总市值、机构增仓、今/明 PE、强度2、涨幅2、细分板块。

### 精选板块 / 成分股字段
- **强度**是板块级指标：`RealRankingInfo` 返回数组的 `list[2]`（`list[17]` 为重复强度字段）。
- 个股接口 `ZhiShuStockList_W8` 没有独立的“个股强度”字段；界面显示的强度是所属板块的强度。
- 个股常用字段：代码、名称、概念标签、现价、涨跌幅、成交额、换手率、流通市值、主力买入/卖出/净额、主买/主卖/净额占比、量比、连板标签、龙头标签、近期涨幅、近期涨停次数、实际换手率、**人气值 `list[58]`、人气排名变化 `list[59]`**。人气值覆盖全部成分股，与 Top 50 人气榜不是同一字段。
- 页面右上角“字段说明”可查看完整字段位置与含义。

### 开盘啦人气榜
- 实时：`apphq.longhuvip.com`（主），失败自动切换 `apphwhq` / `apphwshhq`
- `a=GetHotPHB`、`c=StockBidYiDong`、`Order=1`、`st=50`、`apiv=w29`
- `Type=1` 人气榜（排名、排名变化）；`Type=2` 最强风口（热度值、人气榜排名、新进标记）
- 盘中实时榜，最多 50 名；开盘啦接口不可用时自动切换同花顺小时榜。

### 当天实时数据说明
- **板块个股 / 成分股**：当天走 `apphwshhq.longhuvip.com` 的 `ZhiShuStockList_W8` 实时接口，传 `RStart=0925`、`REnd=当前北京时间`、`Type=-4`，不带 `Date`；因此涨幅、现价、成交额、主力净额都是今天的实时数据。午休时自动使用 `REnd=1130`，避免回退到昨日。页面默认按涨幅排序，可切换按人气排序。
- **连板梯队 / 连板详情**：当天由实时涨停板 `DailyLimitPerformance` 构建，不再使用昨日梯队。
- **涨停原因 / 板块梯队**：当天由实时涨停板按板块聚合；历史日期仍走历史接口。
- **涨跌分析**：涨停/跌停为今日实时；炸板/破板列表和炸板率仍为上一交易日收盘数据（开盘啦实时接口暂不提供这两项列表）。
- **反包板 / 打开高度**：实时接口不提供列表，当天显示为空；历史日期仍可查看。

### 组合/补充接口
- `dailyRange`：单日完整数据按交易日循环，支持区间统计。
- `sectorStrengthNDays`：N 日板块强度（按交易日循环 `GetPlateInfo_w38`）。
- `multipleSectorStrength`：批量板块强度。
- `boardStocksCount`：涨停板数量与列表。
- `sentimentIndicator`：`PlateIntroduction_Info / ZhiShuRanking` 多空风向标。
- `featuredSectors`：开盘啦精选/行业/地区板块排行（`RealRankingInfo / ZhiShuRanking`）。
- `kplHotRank`：开盘啦人气榜 / 最强风口（`GetHotPHB / StockBidYiDong`，`Type=1/2`，实时最高 50 名）。
- `stockConcepts`：为开盘啦人气榜个股补充 `GetStockIDPlate` 相关概念，最多 50 只。
- `sectorHotStocks`：板块全部成分股 + 开盘啦人气榜，默认按涨幅排序，可切换人气排序；今日成分接口盘中未更新时自动使用上一交易日。
- `marketVolume`：同花顺大盘量能预测（`dq.10jqka.com.cn/fuyao/market_analysis_api/chart/v1/get_chart_data?chart_key=turnover_minute`）。
- `marketVolumeHistory`：开盘啦历史量能趋势（`MarketSCLNKLine / HisHomeDingPan`，Type=4 沪深京）。
- `stockLimitReasons`：按需补充人气榜涨停个股的最近涨停原因（`GetDayZhangTing / HisLimitResumption`）。
- `thsHotRank`：同花顺热榜 JSON（作为人气榜补充，替代上游 Selenium 抓取方式）。
- `sectorConstituents(all=true)`、`allEtfRanking`、`plateNewsAll`：自动翻页。

### K 线 / 分时（腾讯主源，参考爱盯盘）
- 腾讯自选股网关 K 线：`https://proxy.finance.qq.com/cgi/cgi-bin/stockinfoquery/kline/app/get`
  - `code=sh600519&ktype=day|m5|...&limit=...&fqtype=qfq|hfq|&toDate=YYYY-MM-DD`
  - `ktype`：`m1/m5/m15/m30/m60/m120/day/week/month/year`；季 K 由月 K 聚合
  - 日/周/月/年成交量按“手”换算；分钟 K 线保持接口原始口径
  - 腾讯分钟 K 线的 `toDate` 不生效，历史分钟 K 线由腾讯历史分时聚合
- 腾讯实时分时：`https://proxy.finance.qq.com/ifzqgtimg/appstock/app/minute/query`
  - 五日分时：`.../appstock/app/day/query`
  - 失败时回退 `https://web.ifzq.gtimg.cn`
- 历史分时：`proxy.finance.qq.com/cgi/cgi-bin/generalminute/history/minute`
  - `date=YYYYMMDD&stockCode=sh600519&sign=md5(date=...&stockCode=...)`
  - 与爱盯盘一致，用于个股/指数历史分时。
- 实时快照：读取腾讯 K 线响应中的 `qt.fields`；失败时回退 `qt.gtimg.cn`。
- 东方财富仅作备用：`push2his` K 线、`push2delay/push2his` 分时、`push2` 快照；历史分时再回退开盘啦历史分时。

---

## 权限说明

| 权限 | 用途 |
|---|---|
| `storage` | 保存最近使用的股票/板块代码、当前页面和自动刷新设置。仅保存在本机。 |
| `contextMenus` | 工具栏图标右键菜单，用于启动独立窗口。 |
| `webRequest` / `webRequestBlocking` | 在请求发出前注入接口要求的移动端 `User-Agent`（浏览器 `fetch` 不允许直接设置该请求头）。 |
| `*://*.longhuvip.com/*` | 开盘啦 App 接口（apphis/apphwhq/apparticle/applhb）。 |
| `*://*.eastmoney.com/*` | 东方财富备用 K 线、分时、快照、搜索。 |
| `*://proxy.finance.qq.com/*` | 腾讯自选股网关 K 线、实时/历史分时、快照（主源，与爱盯盘一致）。 |
| `*://dq.10jqka.com.cn/*` | 同花顺热榜补充数据。 |
| `*://*.kaipanhong.com/*` | 开盘啦精选板块排行（apphwshhq / apphis）。 |
| `*://apphq.longhuvip.com/*`（已含在 `*.longhuvip.com`） | 开盘啦人气榜 `GetHotPHB`。 |

扩展不申请 `tabs`、`cookies`、`history`、`downloads` 等权限，不读取网页内容，不修改页面；`webRequest` 仅用于给上述接口注入请求头。

---

## User-Agent 处理

开盘啦、开盘红、东方财富、腾讯、同花顺的部分接口会校验客户端 `User-Agent`。浏览器的 `fetch` 无法直接设置 `User-Agent`，因此扩展使用 `webRequest.onBeforeSendHeaders` 在请求发出前注入：

- 开盘啦接口：`Dalvik/2.1.0 (Linux; U; Android 9; SHARK PRS-A0 Build/PQ3A.190605.01141736)`
- 开盘啦文章/龙虎榜：`Dalvik/2.1.0 (Linux; U; Android 9; 23116PN5BC Build/PQ3A.190605.01141736)`
- 开盘红精选板块：`Dalvik/2.1.0 (Linux; U; Android 12; 2206123SC Build/c069a49.2)`
- 东方财富/腾讯/同花顺：桌面 Chrome UA，并附带对应 `Referer`

如果重新载入扩展时 Firefox 提示新增权限，请允许 `webRequest` / `webRequestBlocking`，否则请求头不会被改写。

## 已知限制

1. **非交易日 / 当天日线未生成**：多数开盘啦历史接口对非交易日返回 `1020 参数出错`；当天历史日线通常要收盘后才生成，本扩展在“涨跌统计”今天的日期下会自动使用实时接口汇总，不再报 1020。历史日期请选择最近交易日。
2. **盘中“实时”梯队**：`GetYTFP_SCTD` / `GetYTFP_BKHX` 在盘中可能返回上一交易日或最近完成日的梯队，面板会显示接口返回日期，并标注“最新”。实时涨停板请使用“异动监控 → 涨停板”。
3. **`get_abnormal_stocks`**：上游 README 提到该方法，但当前仓库源码（5,061 行版本）中并未包含对应实现；本扩展用“实时大幅回撤 / 涨跌分析 / 竞价异动 / 同花顺热榜”覆盖异动监控。
4. **同花顺热榜**：上游用 Selenium 抓取页面；浏览器扩展无法运行 Selenium，因此改用同花顺公开热榜 JSON（小时/日热度）。
5. **历史分时**：优先使用腾讯历史分时；若失败则回退到开盘啦历史分时。部分个股的历史接口只返回 5 字段，不含主力净流入，面板会标注“该接口无主力字段”。
6. **接口字段语义**：开盘啦部分数组字段含义随版本变化（例如板块盘口第 12 个字段在实测中是板块强度而非换手率）。面板对不确定字段会使用“扩展字段/原始字段”标注。
7. **请求频率**：扩展内置了缓存（实时 3–5 秒、历史 8–60 秒）和少量并发控制；请勿把自动刷新设置得过短，避免对上游造成压力。
8. **跨域与网络**：请求由扩展后台发出，依赖 `host_permissions`；若公司网络/代理拦截 longhuvip/eastmoney，会显示网络错误。

---

## 开发与调试

- 后台接口封装集中在 `background.js` 的 `handlers` 对象，页面通过：
  ```js
  browser.runtime.sendMessage({ type: 'api', action: 'daily', params: { date: '2026-11-02' } })
  ```
  调用。
- 新增接口：在 `background.js` 实现 `async function myAction(params)`，加入 `handlers`，再在 `js/views-*.js` 中渲染即可。
- 接口目录页可以直接编辑参数并查看调用结果 JSON，适合调试字段。
- 修改后在 `about:debugging` 中点击“重新载入”即可生效。

---

## 数据来源与致谢

- 开盘啦 App 接口与字段整理：[jinhao2003/kaipanla-crawler](https://github.com/jinhao2003/kaipanla-crawler)（MIT License）。
- K 线/分时参数参考：爱盯盘 Firefox 扩展（仅参考其公开请求参数与字段映射，未复制其业务代码）。
- 行情数据：开盘啦、东方财富、腾讯证券、同花顺。所有数据版权归原数据提供方所有。

## License

本扩展代码以 MIT License 发布；上游接口与数据版权归各自权利人所有。使用前请自行确认数据提供方的服务条款。
