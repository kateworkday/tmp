# 开盘啦（KPL）接口总览

> 整理日期：2026-11-11  
> 来源：[`zensu357/KPL-post`](https://github.com/zensu357/KPL-post)（66 个抓包接口）、[`LowellLee/kpl`](https://github.com/LowellLee/kpl)（50 个去重 KPL 接口）、[`Rainynitesky/kaipanla-data-parser`](https://github.com/Rainynitesky/kaipanla-data-parser)、[`67snow/webstock`](https://github.com/67snow/webstock)、[`ken196502/kaipanla`](https://github.com/ken196502/kaipanla)、本扩展源码与实测接口。  
> 前两个仓库合并相同 `a/c` 后为 **92 个 KPL 组合**；加上本扩展额外补充接口，共 **110 行**。另有本轮新增调研/接入接口，见“本轮新增接入”。另附第三方行情源。

## 域名与公共参数

| 域名 | 用途 |
|---|---|
| `apphis.longhuvip.com` | 历史行情、历史分时、复盘、涨停原因、历史量能 |
| `apphq.longhuvip.com` | 实时行情、人气榜、竞价、短线精灵 |
| `apphwhq.longhuvip.com` | 实时行情、情绪、竞价、板块 |
| `apphwshhq.longhuvip.com` | 精选板块、板块成分股、实时涨停 |
| `applhb.longhuvip.com` | 龙虎榜、题材、股东、订阅 |
| `apparticle.longhuvip.com` | 新闻、公告、研报、F10、商品现货 |
| `apppage.longhuvip.com` | H5 页面/接口 Referer |
| `apphwshhq.kaipanhong.com` | 开盘红精选板块备用 |
| `apphis.kaipanhong.com` | 开盘红历史备用 |

公共参数通常包含：`PhoneOSNew=1`、`DeviceID`、`VerSion`、`Token`、`UserID`、`apiv`、`Red`。不同接口的 `apiv` 版本不完全一致，需以抓包值为准。

## 统计

| 项目 | 数量 |
|---|---:|
| KPL-post 抓包接口 | 66 |
| LowellLee/kpl 去重 KPL 接口 | 50 |
| 两仓库合并去重后的 KPL a/c | 92 |
| 本扩展额外补充接口 | 18 |
| 总表行数 | 110 |
| 本扩展已接入 | 约 37 行 + 本轮新增 5 个动作 |

## 全部 KPL 接口

### 市场情绪

| 接口 | a | c | 域名 | 关键参数 | 来源 | 本扩展动作 |
|---|---|---|---|---|---|---|
| 实时涨跌家数 / 涨跌停家数 | `MoodNumCount` | `MarketMood` | `apphwhq.longhuvip.com`, `apphwshhq.longhuvip.com` | — | KPL-post / LowellLee / 本扩展 | realtimeMood |
| 市场情绪历史 / 情绪强度 | `ChangeStatistics` | `HisHomeDingPan` | `apphis.longhuvip.com` | Index=0, st=100 | KPL-post / LowellLee | — |
| 市场情绪权重表现 | `WeightPerformanceList` | `HomeDingPan` | `apphwhq.longhuvip.com` | Type=2, Index=0, st=20, Order=1 | KPL-post | — |
| 实时大幅回撤 | `SharpWithdrawalList` | `HomeDingPan` | `apphwhq.longhuvip.com` | Type=5, Index=0, st=20, Order=1 | KPL-post / 本扩展 | realtimeSharp |
| 今日涨停破板率 | `ZhangTingPoBan` | `HomeDingPan` | `apphwhq.longhuvip.com` | — | KPL-post | — |
| 历史涨停破板率 | `ZhangTingPoBan` | `HisHomeDingPan` | `apphis.longhuvip.com` | — | KPL-post | — |
| 指数 / 板块分时 | `GetTrendIncremental` | `ZhiShuL2Data` | `apphwhq.longhuvip.com` | StockID=801900 | KPL-post / 本扩展 | realtimeIndexTrend / sectorIntraday |
| 指数 / 板块成交量 | `GetVolTurIncremental` | `ZhiShuL2Data` | `apphwhq.longhuvip.com` | StockID=801900 | KPL-post / 本扩展 | sectorVolume |
| 市场赚钱效应 | `GetMoneyDate` | `Emotion` | `apphis.longhuvip.com` | st=30, index=0 | KPL-post | — |
| 赚钱效应展开 | `GetMoneyDetail` | `Emotion` | `apphis.longhuvip.com` | Day=2026-07-21 | KPL-post | — |
| 今日涨跌 / 破板率 | `RiseFallAnalysis` | `HomeDingPan` | `apphwshhq.longhuvip.com` | — | LowellLee | — |
| 历史涨跌 / 破板率 | `RiseFallAnalysis` | `HisHomeDingPan` | `apphis.longhuvip.com` | Index=0, st=250 | LowellLee / 本扩展 | riseFall |
| 情绪值 / 连板高度 | `ChangeStatistics` | `HomeDingPan` | `apphq.longhuvip.com` | st=10 | LowellLee | — |
| 历史涨跌统计 | `HisZhangFuDetail` | `HisHomeDingPan` | `apphis.longhuvip.com` | — | 本扩展 | daily / sentiment |
| 实时涨跌停统计 | `MarketStockZDNum` | `HomeDingPan` | `apphwhq.longhuvip.com` | — | 本扩展 | realtimeLimit |
| 历史指数行情 | `GetZsReal` | `StockL2History` | `apphis.longhuvip.com` | — | 本扩展 | marketIndex |
| 指数实时列表 | `RefreshStockList` | `UserSelectStock` | `apphwhq.longhuvip.com` | — | 本扩展 | realtimeIndexList |
| 历史大幅回撤 | `SharpWithdrawal` | `HisHomeDingPan` | `apphis.longhuvip.com` | — | 本扩展 | sharpWithdrawal |

### 市场情绪 / 量能

| 接口 | a | c | 域名 | 关键参数 | 来源 | 本扩展动作 |
|---|---|---|---|---|---|---|
| 历史量能趋势（Type 0-5） | `MarketSCLNKLine` | `HisHomeDingPan` | `apphis.longhuvip.com` | Type=3 | KPL-post / 本扩展 | marketVolumeHistory |

### 复盘 / 涨停

| 接口 | a | c | 域名 | 关键参数 | 来源 | 本扩展动作 |
|---|---|---|---|---|---|---|
| 复盘啦盘面亮点 | `GetPMSL_PMLD` | `FuPanLa` | `apphwhq.longhuvip.com` | Index=0, st=30 | KPL-post | — |
| 复盘啦大幅回撤 / 大面股 | `GetPMSL_KQXY` | `FuPanLa` | `apphwhq.longhuvip.com`, `apphis.longhuvip.com` | Date=2024-03-29, Index=0, st=20 | KPL-post / LowellLee | — |
| 复盘啦涨停天梯 | `GetZhangTingTianTi_W47` | `FuPanLa` | `apphwhq.longhuvip.com` | — | KPL-post | — |
| 复盘啦龙虎榜动向 | `GetYTFP_LHBDX` | `FuPanLa` | `apphwhq.longhuvip.com` | — | KPL-post | — |
| 复盘啦涨停原因 | `GetPlateInfo_w38` | `HisLimitResumption` | `apphis.longhuvip.com` | Date=2026-07-20, Index=0, st=100 | KPL-post | — |
| 涨停原因搜索 | `ZTFPSearch_W15` | `HisLimitResumption` | `apphis.longhuvip.com` | Index=0, st=10 | KPL-post | — |
| 个股历史涨停原因 | `GetDayZhangTing` | `HisLimitResumption` | `apphis.longhuvip.com` | StockID=000725, Index=0, st=25 | KPL-post / 本扩展 | stockLimitReasons |
| 涨停复盘 / 板块涨停原因 | `GetPlateInfo_w38` | `DailyLimitResumption` | `apphwshhq.longhuvip.com` | Index=0, st=1000 | LowellLee / 本扩展 | sectorRanking |
| 当天 / 历史涨停原因（K线） | `GetKLineZhangTing` | `StockLineData` | `apphq.longhuvip.com`, `apphis.longhuvip.com` | StockID=000001 | LowellLee | — |

### 涨停 / 连板

| 接口 | a | c | 域名 | 关键参数 | 来源 | 本扩展动作 |
|---|---|---|---|---|---|---|
| 实时涨停板 / 连板梯队 | `DailyLimitPerformance` | `HomeDingPan` | `apphwhq.longhuvip.com` | Type=4, Index=0, st=2000, PidType=1, Order=0 | LowellLee / 本扩展 | realtimeBoards |
| 历史涨停板 / 连板梯队 | `DailyLimitPerformance` | `HisHomeDingPan` | `apphis.longhuvip.com` | Type=4, Day=2024-10-15, Index=0, st=1000, PidType=1 | LowellLee / 本扩展 | consecutive |
| 未涨停板 / 连板梯队 | `DailyLimitPerformance2` | `HomeDingPan` | `apphwhq.longhuvip.com` | Type=5, Index=0, st=2000, PidType=1, Order=1 | LowellLee | — |
| 历史未涨停 / 连板梯队 | `DailyLimitPerformance2` | `HisHomeDingPan` | `apphis.longhuvip.com` | Type=5, Day=2025-09-01, Index=0, st=1000, PidType=1 | LowellLee | — |
| 涨停结构统计 | `ZhangTingExpression` | `HisHomeDingPan` | `apphis.longhuvip.com` | — | 本扩展 | ladderSummary |
| 历史炸板 | `HisDaBanList` | `HisHomeDingPan` | `apphis.longhuvip.com` | — | 本扩展 | brokenLimitUp |
| 全市场梯队 | `GetYTFP_SCTD` | `FuPanLa` | `apphis.longhuvip.com` | — | 本扩展 | marketLadder |
| 板块梯队 | `GetYTFP_BKHX` | `FuPanLa` | `apphis.longhuvip.com` | — | 本扩展 | sectorLadder |

### 板块 / 精选

| 接口 | a | c | 域名 | 关键参数 | 来源 | 本扩展动作 |
|---|---|---|---|---|---|---|
| 板块强度 / 昨日表现 / 板块内涨停 | `GetPlate_Info_QJ` | `ZhiShuRanking` | `apphwshhq.longhuvip.com`, `apphwhq.longhuvip.com` | PlateID=801900 | LowellLee / 本扩展 | sectorStrength |
| 精选 / 行业 / 地区板块 | `RealRankingInfo` | `ZhiShuRanking` | `apphq.longhuvip.com`, `apphis.longhuvip.com`, `apphwshhq.longhuvip.com` | Type=1, ZSType=7, Date=2025-06-13, Index=0, st=60 | LowellLee / 本扩展 | featuredSectors |
| 板块成分股 | `ZhiShuStockList_W8` | `ZhiShuRanking` | `apphwshhq.longhuvip.com`, `apphis.longhuvip.com` | Type=1, Date=2025-06-13, Index=0, st=60, RStart=0925 | LowellLee / 本扩展 | sectorConstituents |
| 板块资金盘口 | `GetPanKou` | `ZhiShuL2Data` | `apphwhq.longhuvip.com` | — | 本扩展 | sectorCapital |
| 多空风向标 | `PlateIntroduction_Info` | `ZhiShuRanking` | `apphwhq.longhuvip.com` | — | 本扩展 | sentimentIndicator |

> `ZhiShuStockList_W8` 的 `list[58]` 是**人气值**，`list[59]` 是**人气排名变化**，覆盖板块全部成分股。它与 `GetHotPHB` 的 Top 50 人气排名/热度值不是同一字段。

### 板块 / 竞价

| 接口 | a | c | 域名 | 关键参数 | 来源 | 本扩展动作 |
|---|---|---|---|---|---|---|
| 板块竞价异动 | `GetBKJJ_W36` | `StockBidYiDong` | `apphwhq.longhuvip.com` | — | LowellLee / 本扩展 | sectorBidding |
| 异动板块个股 | `GetBKJJBL` | `StockBidYiDong` | `apphwhq.longhuvip.com` | Type=1, StockID=801519, Index=0, st=20, filter=1 | LowellLee | — |

### 个股 / 行情

| 接口 | a | c | 域名 | 关键参数 | 来源 | 本扩展动作 |
|---|---|---|---|---|---|---|
| 个股溢价基因 / 窄盘口 | `GetStockPanKou_Narrow` | `StockL2Data` | `apphwhq.longhuvip.com` | StockID=603118, State=1 | KPL-post | — |
| 个股消息速递 | `MessageBarInfo` | `StockMessageBar` | `apphwhq.longhuvip.com` | StockID=000725 | KPL-post | — |
| 个股盯盘实时数据 | `StockDPRealData` | `StockYiDongKanPan` | `apphwhq.longhuvip.com` | StockID=000725 | KPL-post | — |
| 个股日 K 线 | `GetKLineDay_W14` | `StockLineData` | `apphis.longhuvip.com` | Type=d, StockID=302132, Index=0, st=111 | LowellLee | — |
| 个股实时分时 / 涨幅 | `GetStockTrendIncremental` | `StockL2Data` | `apphwhq.longhuvip.com` | Type=1, StockID=002278 | LowellLee / 本扩展 | indexIntraday（指数） |
| 个股盘口五档 | `GetStockPanKou` | `StockL2Data` | `apphwhq.longhuvip.com` | StockID=000001 | LowellLee | — |
| 大单委托 | `GetWeiTuo_W14` | `StockL2Data` | `apphq.longhuvip.com` | Type=2, StockID=000001, st=3000, Tur=30, Vol=500 | LowellLee | — |
| 个股相关概念板块 | `GetStockIDPlate` | `StockL2Data` | `apphwshhq.longhuvip.com` | Type=2, StockID=002931 | LowellLee / 本扩展 | stockConcepts |
| 个股历史分时 | `GetStockTrend` | `StockL2History` | `apphis.longhuvip.com` | — | 本扩展 | stockIntraday / indexIntraday |
| 个股实时分时 | `GetZstrend` | `StockL2Data` | `apphwhq.longhuvip.com` | — | 本扩展 | stockIntraday |

### 个股 / F10

| 接口 | a | c | 域名 | 关键参数 | 来源 | 本扩展动作 |
|---|---|---|---|---|---|---|
| F10 概念题材 | `GetConceptJXBKw23` | `StockF10Basic` | `apparticle.longhuvip.com` | StockID=000725 | KPL-post | — |
| F10 公司资料 | `GetCompanyInfo` | `StockF10Basic` | `apparticle.longhuvip.com` | StockID=000725 | KPL-post | — |
| F10 股本股东 | `GetGuDong` | `YiDianCangWei` | `apphis.longhuvip.com` | Type=2, StockID=000725 | KPL-post | — |
| F10 估值分析 | `GetValuation` | `StockF10Basic` | `apparticle.longhuvip.com` | StockID=000725, key=PE, year=1 | KPL-post | — |
| F10 财务主要指标 | `GetMainIndicators` | `StockF10Basic` | `apparticle.longhuvip.com` | Type=0, StockID=000725 | KPL-post | — |

### 个股 / 竞价

| 接口 | a | c | 域名 | 关键参数 | 来源 | 本扩展动作 |
|---|---|---|---|---|---|---|
| 竞价涨停委买额 | `MorningBiddingList` | `HomeDingPan` | `apphwhq.longhuvip.com` | Type=4, Index=0, st=60, PidType=0, Order=1 | LowellLee | — |
| 历史竞价委买 | `MorningBiddingList` | `HisHomeDingPan` | `apphis.longhuvip.com` | Type=4, Date=2025-06-19, Index=0, st=20, PidType=0 | LowellLee | — |
| 个股竞价分时 | `GetStockBid` | `StockL2Data` | `apphwhq.longhuvip.com` | StockID=000785 | LowellLee | — |

### 个股 / 大单

| 接口 | a | c | 域名 | 关键参数 | 来源 | 本扩展动作 |
|---|---|---|---|---|---|---|
| 大单成交 | `GetMainMonitor_w30` | `StockYiDongKanPan` | `apphq.longhuvip.com` | StockID=600126, Index=0, st=20, Money=2, Order=0 | LowellLee | — |
| 分时大单区间统计 | `StockChouMaByTimeNew_W5` | `StockYiDongKanPan` | `apphwhq.longhuvip.com` | StockID=300322 | LowellLee | — |
| 历史分时大单 | `GetStockChouMa_New` | `StockL2History` | `apphis.longhuvip.com` | Type=1, StockID=002265, Day=20250717 | LowellLee | — |
| 个股大单净额 | `GetStockDaDanTrendIncremental` | `StockL2Data` | `apphwhq.longhuvip.com` | StockID=300322 | LowellLee | — |
| 主力大单 | `GetMainMonitor_Trend_w30` | `StockL2History` | `apphis.longhuvip.com` | — | 本扩展 | stockBigOrder |
| 主力大单实时 | `GetMainMonitor_Trend_w30` | `StockL2Data` | `apphwhq.longhuvip.com` | — | 本扩展 | stockBigOrder |

### 个股 / 涨停

| 接口 | a | c | 域名 | 关键参数 | 来源 | 本扩展动作 |
|---|---|---|---|---|---|---|
| 涨停基因 | `GetZhangTingGene` | `StockL2Data` | `apphwhq.longhuvip.com` | StockID=001330 | LowellLee | stockLimitGene |

返回 `List[6]`：历史涨停次数、5% 溢价次数、次日红盘率、首板封板率、首板破板率、连板率。`GetStockPanKou_Narrow` 的 `YJJY` 是同一组数据，扩展在主接口失败时会自动用它兜底。

### 个股 / 异动

| 接口 | a | c | 域名 | 关键参数 | 来源 | 本扩展动作 |
|---|---|---|---|---|---|---|
| 偏离值异动 | `GetPianLiZhi_Index` | `StockBidYiDong` | `apphwshhq.longhuvip.com` | — | LowellLee | — |

### 龙虎榜

| 接口 | a | c | 域名 | 关键参数 | 来源 | 本扩展动作 |
|---|---|---|---|---|---|---|
| 龙虎榜股票列表 | `GetStockList` | `LongHuBang` | `applhb.longhuvip.com` | Type=2, Index=0, st=500 | KPL-post / 本扩展 | lhbList |
| 龙虎榜订阅 | `GetDay` | `UserBusiness` | `applhb.longhuvip.com` | — | KPL-post | — |
| 龙虎榜个股详情 | `GetNewOneStockInfo` | `Stock` | `applhb.longhuvip.com` | — | 本扩展 | lhbDetail |

### 机构 / 资金

| 接口 | a | c | 域名 | 关键参数 | 来源 | 本扩展动作 |
|---|---|---|---|---|---|---|
| 机构增仓列表 | `GGList_JGCC` | `ZhuLiChiCang` | `apphis.longhuvip.com` | Type=1, Date=2026-06-30, Index=0, st=30, IsBX=1 | KPL-post / LowellLee | — |
| 机构增仓板块个股 | `GGList_JGCC_Plate_Stocks` | `ZhuLiChiCang` | `apphis.longhuvip.com` | Type=1, IndexID=801001, Date=2025-12-31, Index=0, st=20 | LowellLee | — |
| 北向机构增仓 | `GGList_BXZJ` | `ZhuLiChiCang` | `apphis.longhuvip.com` | Type=1, Date=2025-12-31, Index=0, st=20, Order=1 | LowellLee | — |
| 北向机构增仓个股 | `GGList_BXZJ_Stocks` | `ZhuLiChiCang` | `apphis.longhuvip.com` | Type=1, IndexID=801660, Date=2025-12-31, Index=0, st=20 | LowellLee | — |

### 股东 / 机构

| 接口 | a | c | 域名 | 关键参数 | 来源 | 本扩展动作 |
|---|---|---|---|---|---|---|
| 股东人数变化 | `GuDongRenShu` | `YiDianCangWei` | `applhb.longhuvip.com` | Index=0, st=50, ShowDate=0, IsNew=0, EndDate=2026-04-15 | LowellLee | — |
| 股东追踪（追股东） | `JGStockListox` | `JGTracking` | `applhb.longhuvip.com` | Type=1, st=46, index=0, OrderType=0, JGID=5 | LowellLee | — |
| 股东追踪（追个股） | `GetJGNameID` | `JGTracking` | `applhb.longhuvip.com` | StockID=002600, Day=2026-03-27, IsPer=1 | LowellLee | — |

### 题材 / 复盘

| 接口 | a | c | 域名 | 关键参数 | 来源 | 本扩展动作 |
|---|---|---|---|---|---|---|
| 明天炒什么列表 | `InfoList` | `Topic` | `applhb.longhuvip.com` | Index=0, st=10 | KPL-post / LowellLee | — |
| 明天炒什么搜索 | `SearchTopic` | `Topic` | `applhb.longhuvip.com` | KeyWord=kimi | KPL-post | — |
| 题材库搜索 | `InfoSearch` | `Theme` | `applhb.longhuvip.com` | — | KPL-post | — |
| 题材库 / 明天炒什么文章 | `InfoGet` | `Theme` | `applhb.longhuvip.com` | ID=397 | KPL-post | — |
| 明天炒什么利好个股 | `InfoZS` | `Topic` | `applhb.longhuvip.com` | ID=2160, ZS=801660 | LowellLee | — |
| 明天炒什么文章内容 | `InfoGet` | `Topic` | `applhb.longhuvip.com` | ID=2160 | LowellLee | — |

### 新闻 / 快讯

| 接口 | a | c | 域名 | 关键参数 | 来源 | 本扩展动作 |
|---|---|---|---|---|---|---|
| 快讯头条 | `GetTopList` | `PCNewsFlash` | `apparticle.longhuvip.com` | Index=0, st=1 | KPL-post / LowellLee | — |

### 新闻 / 公告

| 接口 | a | c | 域名 | 关键参数 | 来源 | 本扩展动作 |
|---|---|---|---|---|---|---|
| 快讯列表（重要/全部/AI解读） | `GetList` | `PCNewsFlash` | `apparticle.longhuvip.com` | Type=1, Index=0, st=20 | KPL-post / LowellLee | — |
| 股票新闻 / 公告 / 研报 | `GetList` | `CompanyNotice` | `apphis.longhuvip.com` | Type=1, StockID=000725, Index=0, st=34 | KPL-post | — |
| 新闻内容详情 | `GetContentNew` | `CompanyNotice` | `apphis.longhuvip.com` | Type=1 | KPL-post | — |
| 公告内容详情 | `GGDetail` | `AnnouncementList` | `apphis.longhuvip.com` | — | KPL-post | — |
| 板块新闻 | `GetPlateNewsList` | `APPComplexData` | `apparticle.longhuvip.com` | — | 本扩展 | plateNews |

### 商品现货

| 接口 | a | c | 域名 | 关键参数 | 来源 | 本扩展动作 |
|---|---|---|---|---|---|---|
| 商品现货涨价榜 | `GetInfo` | `ForumsMsgJX` | `apparticle.longhuvip.com` | — | KPL-post | — |
| 商品现货分类 | `XianHuo_Group` | `XianHuoData` | `apphwhq.longhuvip.com` | Type=1, Index=0, st=10, DStart=2026-07-21, DEnd=2026-07-21 | KPL-post | — |
| 商品现货精选 | `AllXianHuo` | `XianHuoData` | `apphwhq.longhuvip.com` | Type=2, Index=0, st=11, DStart=2026-07-21, DEnd=2026-07-21 | KPL-post | — |

### 全球行情

| 接口 | a | c | 域名 | 关键参数 | 来源 | 本扩展动作 |
|---|---|---|---|---|---|---|
| 全球行情 | `GlobalCommon` | `GlobalIndex` | `apphwhq.longhuvip.com`, `apphq.longhuvip.com` | View=1,2,3,4,5,6 | KPL-post / LowellLee | — |
| 全球指数列表 | `AllGlobaIndex` | `GlobalIndex` | `apphwhq.longhuvip.com` | — | KPL-post | — |

### 互动易

| 接口 | a | c | 域名 | 关键参数 | 来源 | 本扩展动作 |
|---|---|---|---|---|---|---|
| 互动易热搜排行 | `GetHotSearch` | `InteractData` | `apparticle.longhuvip.com` | Type=1 | KPL-post | — |
| 互动易搜索 | `GetSearchData` | `InteractData` | `apparticle.longhuvip.com` | Type=0, Index=0, st=15 | KPL-post | — |

### 百日新高

| 接口 | a | c | 域名 | 关键参数 | 来源 | 本扩展动作 |
|---|---|---|---|---|---|---|
| 百日新高饼图 | `GroupCount_w28` | `StockNewHigh` | `apphwhq.longhuvip.com`, `apphwshhq.longhuvip.com` | Type=0_0_0_0_0 | KPL-post / LowellLee | — |
| 百日新高按板块 / 个股 | `GroupStock_W28` | `StockNewHigh` | `apphwhq.longhuvip.com` | Type=0_0_0_0_0, Index=0, st=15, OrderType=2, IsAll=1 | KPL-post | — |
| 百日新高趋势 | `GetDayNewHigh_W28` | `StockNewHigh` | `apphis.longhuvip.com` | Type=0_0_0_0_0, Index=0, st=360, GroupID=ALL | KPL-post / 本扩展 | newHigh |

### 区间统计

| 接口 | a | c | 域名 | 关键参数 | 来源 | 本扩展动作 |
|---|---|---|---|---|---|---|
| 板块区间统计 | `GetInterviewsByDateZS` | `StockLineData` | `apphwshhq.longhuvip.com` | Type=1, Index=0, st=30, DStart=2025-08-18, DEnd=2026-05-13 | LowellLee | — |
| 个股区间统计 | `GetInterviewsByDateStock` | `StockLineData` | `apphwshhq.longhuvip.com` | Type=2, Index=0, st=30, DStart=2025-08-12, DEnd=2025-08-19 | LowellLee | — |

### 大盘直播

| 接口 | a | c | 域名 | 关键参数 | 来源 | 本扩展动作 |
|---|---|---|---|---|---|---|
| 大盘直播 | `ZhiBoContent` | `ConceptionPoint` | `apphwhq.longhuvip.com` | index=0 | KPL-post | — |
| 大盘直播图标注 | `GetPoint` | `ConceptionPoint` | `apphwhq.longhuvip.com` | — | KPL-post | — |
| 历史大盘直播 | `ZhiBoContent` | `HisConceptionPoint` | `apphis.longhuvip.com` | Date=YYYY-MM-DD, st=0, index=0 | LowellLee | — |

### 短线精灵

| 接口 | a | c | 域名 | 关键参数 | 来源 | 本扩展动作 |
|---|---|---|---|---|---|---|
| 短线精灵 | `Radar` | `HomeDingPan` | `apphq.longhuvip.com` | Index=0, st=100 | LowellLee | — |

### 热门 / 情绪

| 接口 | a | c | 域名 | 关键参数 | 来源 | 本扩展动作 |
|---|---|---|---|---|---|---|
| 最强风口 | `GetFengKListBest` | `StockFengKData` | `apphwhq.longhuvip.com` | — | KPL-post | — |
| 人气榜 / 最强风口 | `GetHotPHB` | `StockBidYiDong` | `apphq.longhuvip.com` | Type=1, st=50, Order=1 | LowellLee / 本扩展 | kplHotRank |

### ETF

| 接口 | a | c | 域名 | 关键参数 | 来源 | 本扩展动作 |
|---|---|---|---|---|---|---|
| ETF 排行 | `ETFStockRanking` | `NewStockRanking` | `apphwhq.longhuvip.com` | — | 本扩展 | etfRanking / allEtfRanking |

### 本轮新增接入（2026-11-11）

| 接口 | a | c | 域名 | 关键参数 | 来源 | 本扩展动作 |
|---|---|---|---|---|---|---|
| 大盘量能 | `MarketCapacity` | `HisHomeDingPan` | `apphis.longhuvip.com` | Type=0, Date=YYYY-MM-DD | 67snow/webstock | marketCapacity |
| 大盘量能历史 | `MarketCapacityKLine` | `HisHomeDingPan` | `apphis.longhuvip.com` | Date=YYYY-MM-DD | ken196502/kaipanla | marketCapacityHistory |
| 板块细分方向 | `SonPlate_Info` | `ZhiShuRanking` | `apphq.longhuvip.com` | PlateID=801004, Date=YYYY-MM-DD, IsShow=1 | Rainynitesky/kaipanla-data-parser | sectorHotStocks（subSectors） |
| 板块排序标签 | `GetGPCPHBTS_Tag` | `ZhiShuRanking` | `apphq.longhuvip.com` | PlateID=803041 | Rainynitesky/kaipanla-data-parser | sectorHotStocks（tags） |
| 板块爆发原因 | `GetDayBaseFaceListZDEvnArt` | `ZhiShuKLine` | `apphis.longhuvip.com` | StockID=801004, Index=0, st=20, Type=0, IsBoom=0 | Rainynitesky/kaipanla-data-parser | sectorBoomReasons |

说明：`GetGPCPHBTS_Tag` 返回的 `TSZB` 值可作为 `ZhiShuStockList_W8` 的 `Type` 参数使用；当前界面将其作为板块个股的标签排序。标签是否适用于某个板块、是否返回非空结果，需要在运行时判断。

## 第三方数据源（非 longhuvip）

LowellLee/kpl 还引用了以下非开盘啦域名，仅作为补充参考：

| 域名 | 接口 | 用途 |
|---|---|---|
| `flash-api.xuangubao.com.cn` | `/api/pool/detail?pool_name=limit_up` | 涨停池实时/历史 |
| `flash-api.xuangubao.com.cn` | `/api/pool/detail?pool_name=limit_up_broken` | 炸板池 |
| `flash-api.xuangubao.com.cn` | `/api/pool/detail?pool_name=limit_down` | 跌停池 |
| `flash-api.xuangubao.com.cn` | `/api/pool/detail?pool_name=yesterday_limit_up` | 昨日涨停 |
| `flash-api.xuangubao.com.cn` | `/api/market_indicator/line?fields=...` | 涨跌家数/涨跌停/炸板/市场温度曲线 |
| `api.fupanwang.com` | `/kpl/zhibo` | 大盘直播 |

## 接入建议

- 主线追踪是组合视图：按最近 10 个交易日循环调用 `RealRankingInfo / ZhiShuRanking`，每日按 `strength` 取 Top N，再按板块代码汇总出现天数、平均强度和最佳排名。
- 已有插件覆盖的核心接口保留，不必重复接入。
- LowellLee 的 `GetKLineDay_W14`、`GetKLineZhangTing`、`GetStockBid`、`GetWeiTuo_W14`、`Radar`、`DailyLimitPerformance2` 目前未接入，可作为后续扩展。
- KPL-post 的 F10、新闻公告、全球行情、商品现货、机构增仓、股东追踪等属于独立模块，当前插件未覆盖。
- 个股 K 线当前使用腾讯/东方财富，不在 KPL 接口覆盖内；如需完全使用开盘啦 K 线，可再评估 `GetKLineDay_W14`。
- `GetDayZhangTing` 的 `Day` 参数不严格过滤日期，展示时必须使用返回的 `Date` 校验。
